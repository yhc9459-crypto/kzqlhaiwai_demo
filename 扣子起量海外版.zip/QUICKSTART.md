# 🚀 快速开始指南

## 模板简介

这是一个企业级的素材推送管理系统模板，包含完整的UI和业务逻辑。

## 核心功能

✅ 素材包管理（8种筛选 + 4列排序）  
✅ 素材库（视频/图片/H5 双标签页）  
✅ 推送任务（本人/全部任务）  
✅ 数据看板（效果分析）

## 技术栈

- React 18 + TypeScript
- Tailwind CSS 4.x
- Radix UI
- date-fns + lucide-react

## 核心页面

### 1. 素材包管理 (MaterialPackagePage.tsx)
当前截图显示的页面，包含：
- 筛选区：素材包名称、编号、产品、制作类型、创建人、关联创意人、创建时间
- 表格：缩略图、编号、名称、产品、类型、素材数量、创建人、投放数据
- 功能：创建素材包、点击查看详情、排序、分页

### 2. 素材库 (MaterialLibraryPage.tsx)
- 双标签页：本人素材 / 全部素材
- 支持视频库、图片库、H5页面三种类型
- 显示质量分、花费、CTR、ROI

### 3. 推送任务 (MyTasksPage.tsx / AllTasksPage.tsx)
- 本人任务 / 全部任务
- 任务状态跟踪
- 成功/失败数统计

## 主要文件

```
/src/app/
├── App.tsx                          # 主应用（路由）
├── components/
│   ├── MaterialPackagePage.tsx     # 素材包列表（当前页面）
│   ├── MaterialLibraryPage.tsx     # 素材库
│   ├── MyTasksPage.tsx             # 本人任务
│   ├── Header.tsx                  # 顶栏
│   ├── Sidebar.tsx                 # 侧栏
│   └── ui/                         # 基础组件
├── lib/
│   └── mockData.ts                 # Mock数据
└── types/
    └── material.ts                 # 类型定义
```

## 快速修改

### 1. 修改产品列表
编辑 `/src/app/lib/mockData.ts`:
```typescript
export const products = ['产品A', '产品B', '产品C'];
```

### 2. 添加新筛选项
在对应页面（如MaterialPackagePage.tsx）中：
```typescript
const [newFilter, setNewFilter] = useState('');
// 添加UI和筛选逻辑
```

### 3. 修改主题色
编辑 `/src/styles/theme.css`:
```css
@theme {
  --color-primary: #2563eb;
}
```

## 数据结构

### MaterialPackage (素材包)
```typescript
{
  id: string;
  packageNumber: string;      // MP-20260120-0001
  packageName: string;        // Bingo Bonus 新年活动素材包
  product: string;            // Bingo Bonus
  productionType: '0-1制作' | '1-N制作';
  videoCount: number;
  imageCount: number;
  html5Count: number;
  creatorName: string;
  creativePerson: string;
  createdAt: string;
  cost: number;               // 花费
  ctr: number;                // 点击率
  roi: number;                // ROI
}
```

## 关键功能实现

### 筛选功能
```typescript
const filteredPackages = mockPackages.filter(pkg => {
  if (appliedFilters.packageNameQuery) {
    if (!pkg.packageName.includes(appliedFilters.packageNameQuery)) 
      return false;
  }
  // ... 其他筛选条件
  return true;
});
```

### 排序功能
```typescript
const [costSort, setCostSort] = useState<'asc' | 'desc' | null>(null);

if (costSort) {
  result.sort((a, b) => 
    costSort === 'asc' ? a.cost - b.cost : b.cost - a.cost
  );
}
```

### 分页功能
```typescript
const currentPage = 1;
const itemsPerPage = 10;
const paginatedPackages = filteredPackages.slice(
  (currentPage - 1) * itemsPerPage,
  currentPage * itemsPerPage
);
```

## 常用组件

### Table
```tsx
<Table>
  <TableHeader>
    <TableRow>
      <TableHead>列名</TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    {data.map(item => (
      <TableRow key={item.id}>
        <TableCell>{item.value}</TableCell>
      </TableRow>
    ))}
  </TableBody>
</Table>
```

### Select
```tsx
<Select value={value} onValueChange={setValue}>
  <SelectTrigger>
    <SelectValue placeholder="请选择" />
  </SelectTrigger>
  <SelectContent>
    <SelectItem value="option1">选项1</SelectItem>
  </SelectContent>
</Select>
```

### Calendar
```tsx
<Popover>
  <PopoverTrigger asChild>
    <Button>{date ? format(date, 'yyyy-MM-dd') : '选择日期'}</Button>
  </PopoverTrigger>
  <PopoverContent>
    <Calendar
      mode="single"
      selected={date}
      onSelect={setDate}
      locale={zhCN}
    />
  </PopoverContent>
</Popover>
```

## 注意事项

1. **权限**: 素材包只显示本人创建，素材库有本人/全部双标签
2. **Mock数据**: 当前使用静态Mock数据，实际项目需要接入API
3. **路由**: 使用state管理页面切换，可改为React Router
4. **类型安全**: 所有组件都有完整的TypeScript类型定义

## 下一步

1. 查看完整文档: [TEMPLATE_README.md](./TEMPLATE_README.md)
2. 查看系统设计: [SYSTEM_OVERVIEW_V2.md](./SYSTEM_OVERVIEW_V2.md)
3. 修改Mock数据: `/src/app/lib/mockData.ts`
4. 自定义主题: `/src/styles/theme.css`

## 版本信息

- **模板版本**: V115
- **React**: 18.3.1
- **Tailwind CSS**: 4.1.12
- **TypeScript**: ✅

---

享受开发！ 🎉
