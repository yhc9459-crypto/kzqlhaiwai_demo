// Test imports to verify everything loads correctly
import { MaterialLibraryPage } from './src/app/components/MaterialLibraryPage';
import { mockMaterials } from './src/app/lib/mockData';
import { getMaterialTypeName } from './src/app/lib/xmpService';

console.log('All imports successful');
console.log('Mock materials count:', mockMaterials.length);
console.log('Material type name:', getMaterialTypeName('video'));
