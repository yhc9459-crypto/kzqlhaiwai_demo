
  # 扣子起量海外版

  This is a code bundle for 扣子起量海外版. The original project is available at https://www.figma.com/design/c1xe16oHVLcOy2zsSjM3ud/%E6%89%A3%E5%AD%90%E8%B5%B7%E9%87%8F%E6%B5%B7%E5%A4%96%E7%89%88.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  