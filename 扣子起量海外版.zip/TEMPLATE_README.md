# 素材推送管理系统 - 模板 V115

> 一个完整的企业级素材管理和推送系统，支持视频、图片、H5等多种素材类型的组织、管理和批量推送。

## 📋 模板概览

本模板基于 **SYSTEM_OVERVIEW_V2.md** 设计文档实现，提供了一个功能完整、UI精美的素材推送管理系统。

### 核心功能模块

1. **素材包管理** - 组织和归类素材
2. **素材库管理** - 视频库、图片库、H5页面管理
3. **推送任务** - 批量推送到XMP平台
4. **数据看板** - 素材效果分析和人效统计

## 🎨 界面特性

- ✅ 左侧折叠导航栏
- ✅ 面包屑导航
- ✅ 高级筛选功能（支持多维度筛选）
- ✅ 表格排序（支持多列排序）
- ✅ 分页功能
- ✅ 缩略图预览
- ✅ 响应式布局
- ✅ Toast通知
- ✅ 模态对话框

## 🛠 技术栈

### 核心框架
- **React 18.3.1** - UI框架
- **TypeScript** - 类型安全
- **Vite 6.3.5** - 构建工具

### UI组件库
- **Radix UI** - 无样式组件基础
- **Tailwind CSS 4.x** - 样式框架
- **Lucide React** - 图标库
- **Material UI** - 部分高级组件

### 功能库
- **date-fns** - 日期处理
- **react-hook-form** - 表单管理
- **sonner** - Toast通知
- **recharts** - 图表库

## 📁 项目结构

```
/
├── src/
│   ├── app/
│   │   ├── components/           # 组件目录
│   │   │   ├── ui/               # 基础UI组件
│   │   │   │   ├── button.tsx
│   │   │   │   ├── table.tsx
│   │   │   │   ├── select.tsx
│   │   │   │   └── ...
│   │   │   ├── Header.tsx        # 顶部导航栏
│   │   │   ├── Sidebar.tsx       # 侧边栏
│   │   │   ├── MaterialPackagePage.tsx    # 素材包列表
│   │   │   ├── MaterialLibraryPage.tsx    # 素材库
│   │   │   ├── MyTasksPage.tsx            # 本人任务
│   │   │   ├── AllTasksPage.tsx           # 全部任务
│   │   │   └── ...
│   │   ├── lib/
│   │   │   ├── mockData.ts       # 模拟数据
│   │   │   └── xmpService.ts     # XMP服务
│   │   ├── types/
│   │   │   └── material.ts       # 类型定义
│   │   └── App.tsx               # 主应用
│   └── styles/
│       ├── index.css             # 全局样式
│       ├── tailwind.css          # Tailwind配置
│       └── theme.css             # 主题样式
├── SYSTEM_OVERVIEW_V2.md         # 系统设计文档
├── MATERIAL_DASHBOARD_SPEC.md    # 看板规格文档
└── package.json
```

## 🚀 快速开始

### 1. 安装依赖

所有依赖已在 `package.json` 中定义，核心依赖包括：

```json
{
  "dependencies": {
    "react": "18.3.1",
    "react-dom": "18.3.1",
    "@radix-ui/*": "latest",
    "tailwindcss": "4.1.12",
    "date-fns": "3.6.0",
    "lucide-react": "0.487.0"
  }
}
```

### 2. 运行项目

```bash
# 构建项目
npm run build
```

### 3. 自定义配置

#### 修改主题颜色

编辑 `/src/styles/theme.css`:

```css
@theme {
  --color-primary: #2563eb;
  --color-secondary: #64748b;
  /* 添加更多自定义颜色 */
}
```

#### 修改Mock数据

编辑 `/src/app/lib/mockData.ts` 来自定义示例数据。

## 📦 核心页面说明

### 1. 素材包管理页面 (MaterialPackagePage)

**功能特性：**
- ✅ 8个筛选维度（素材包名称、编号、产品、制作类型、创建人、关联创意人、创建时间）
- ✅ 4列可排序（创建时间、花费、CTR、ROI）
- ✅ 缩略图预览
- ✅ 素材数量统计（视频/图片/H5）
- ✅ 分页显示

**使用示例：**
```tsx
<MaterialPackagePage 
  onNavigateToDetail={(id) => navigate(`/packages/${id}`)}
  onNavigateToCreate={() => navigate('/packages/create')}
/>
```

### 2. 素材库页面 (MaterialLibraryPage)

**功能特性：**
- ✅ 双标签页（本人素材/全部素材）
- ✅ 多维度筛选
- ✅ 质量分、花费、CTR、ROI展示
- ✅ 批量操作

**使用示例：**
```tsx
<MaterialLibraryPage 
  materialType="video" // 'video' | 'image' | 'html5'
  onNavigateToUpload={() => {}}
  onNavigateToCreateTask={() => {}}
/>
```

### 3. 推送任务页面 (MyTasksPage / AllTasksPage)

**功能特性：**
- ✅ 任务状态跟踪
- ✅ 实时进度显示
- ✅ 成功/失败数统计
- ✅ 任务详情查看

**使用示例：**
```tsx
<MyTasksPage 
  onNavigateToDetail={(taskId) => {}}
  onNavigateToCreate={() => {}}
/>
```

## 🎯 核心组件使用指南

### Table组件

表格组件支持排序、筛选、分页：

```tsx
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/app/components/ui/table';

<Table>
  <TableHeader>
    <TableRow>
      <TableHead>列名</TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    <TableRow>
      <TableCell>数据</TableCell>
    </TableRow>
  </TableBody>
</Table>
```

### Select组件

下拉选择组件：

```tsx
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';

<Select value={value} onValueChange={setValue}>
  <SelectTrigger>
    <SelectValue placeholder="请选择" />
  </SelectTrigger>
  <SelectContent>
    <SelectItem value="option1">选项1</SelectItem>
    <SelectItem value="option2">选项2</SelectItem>
  </SelectContent>
</Select>
```

### Calendar组件

日期选择组件：

```tsx
import { Calendar } from '@/app/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/app/components/ui/popover';

<Popover>
  <PopoverTrigger asChild>
    <Button variant="outline">
      {date ? format(date, 'yyyy-MM-dd') : '选择日期'}
    </Button>
  </PopoverTrigger>
  <PopoverContent>
    <Calendar
      mode="single"
      selected={date}
      onSelect={setDate}
      locale={zhCN}
    />
  </PopoverContent>
</Popover>
```

### Toast通知

使用Sonner进行通知：

```tsx
import { toast } from 'sonner';

toast.success('操作成功！');
toast.error('操作失败！');
toast.info('提示信息');
```

## 🔧 自定义开发指南

### 添加新页面

1. 在 `/src/app/components/` 创建新组件文件
2. 在 `App.tsx` 中导入并添加路由
3. 在 `Sidebar.tsx` 中添加菜单项

```tsx
// 1. 创建新页面组件
// /src/app/components/NewPage.tsx
export function NewPage() {
  return <div>新页面</div>;
}

// 2. 在App.tsx中添加
import { NewPage } from './components/NewPage';

// 3. 添加到渲染逻辑
{currentPage === 'new-page' && <NewPage />}
```

### 添加新的筛选字段

在对应页面组件中：

```tsx
// 1. 添加状态
const [newFilter, setNewFilter] = useState('');

// 2. 添加到应用筛选状态
const [appliedFilters, setAppliedFilters] = useState({
  // ...existing filters
  newFilter: '',
});

// 3. 在渲染中添加UI
<Input
  placeholder="新筛选项"
  value={newFilter}
  onChange={(e) => setNewFilter(e.target.value)}
/>

// 4. 在筛选逻辑中应用
if (appliedFilters.newFilter) {
  result = result.filter(item => 
    item.field.includes(appliedFilters.newFilter)
  );
}
```

### 添加新的排序列

```tsx
// 1. 添加排序状态
const [newFieldSort, setNewFieldSort] = useState<SortOrder>(null);

// 2. 添加排序按钮
<TableHead
  className="cursor-pointer"
  onClick={() => {
    setNewFieldSort(
      newFieldSort === 'asc' ? 'desc' 
        : newFieldSort === 'desc' ? null 
        : 'asc'
    );
    // 重置其他排序
  }}
>
  新字段
  {/* 排序图标 */}
</TableHead>

// 3. 应用排序逻辑
if (newFieldSort) {
  result.sort((a, b) => 
    newFieldSort === 'asc' ? a.field - b.field : b.field - a.field
  );
}
```

## 📊 数据结构说明

### Material (素材)

```typescript
interface Material {
  id: string;
  name: string;
  type: 'video' | 'image' | 'html5';
  packageNumber: string;        // 所属素材包编号
  packageName: string;           // 所属素材包名称
  product: string;               // 产品
  productionType: string;        // 制作类型
  tags: string[];                // 标签
  createdBy: string;             // 创建人
  createdAt: string;             // 创建时间
  qualityScore?: number;         // 质量分
  cost?: number;                 // 花费
  ctr?: number;                  // 点击率
  roi?: number;                  // ROI
}
```

### MaterialPackage (素材包)

```typescript
interface MaterialPackage {
  id: string;
  packageNumber: string;         // 素材包编号
  packageName: string;           // 素材包名称
  product: string;               // 产品
  productionType: '0-1制作' | '1-N制作';
  materialCount: number;         // 素材总数
  videoCount: number;            // 视频数
  imageCount: number;            // 图片数
  html5Count: number;            // H5数
  creatorName: string;           // 创建人
  creativePerson: string;        // 关联创意人
  createdAt: string;             // 创建时间
  cost: number;                  // 花费（最高素材）
  ctr: number;                   // CTR（最高素材）
  roi: number;                   // ROI（最高素材）
}
```

### PushTask (推送任务)

```typescript
interface PushTask {
  id: string;
  product: string;               // 产品
  materialType: 'video' | 'image' | 'html5';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  totalCount: number;            // 总数
  successCount: number;          // 成功数
  failedCount: number;           // 失败数
  pendingCount: number;          // 待处理数
  createdBy: string;             // 创建人
  createdAt: string;             // 创建时间
  completedAt?: string;          // 完成时间
}
```

## 🎨 设计规范

### 颜色系统

- **主色调**: Blue (#2563eb)
- **成功**: Green (#10b981)
- **警告**: Yellow (#f59e0b)
- **错误**: Red (#ef4444)
- **中性**: Gray (#64748b)

### 间距系统

- **xs**: 4px
- **sm**: 8px
- **md**: 16px
- **lg**: 24px
- **xl**: 32px

### 字体大小

- **xs**: 12px
- **sm**: 14px
- **base**: 16px
- **lg**: 18px
- **xl**: 20px
- **2xl**: 24px

## 🔐 权限设计

### 素材库模块
- **本人素材**: 只显示当前用户上传的素材
- **全部素材**: 显示所有用户的素材

### 素材包模块
- **仅本人**: 只能看到自己创建的素材包
- **无全部标签页**: 不提供查看所有素材包的功能

### 推送任务模块
- **本人任务**: 自己创建的任务
- **全部任务**: 所有用户的任务（需要权限）

## 📈 性能优化建议

1. **分页加载**: 大数据集使用分页，默认每页10条
2. **图片懒加载**: 使用Intersection Observer
3. **虚拟滚动**: 超长列表考虑使用虚拟滚动
4. **防抖搜索**: 搜索输入添加防抖处理
5. **缓存策略**: 使用React Query或SWR缓存数据

## 🧪 测试数据

模板包含完整的Mock数据，位于 `/src/app/lib/mockData.ts`：

- **6个素材包**（包含不同产品、制作类型）
- **15+个素材**（视频、图片、H5）
- **10+个推送任务**（不同状态）
- **5个产品**（Bingo Bonus、Yazzy GO!等）
- **5个设计师**（张设计、李设计等）

## 📚 参考文档

- [SYSTEM_OVERVIEW_V2.md](./SYSTEM_OVERVIEW_V2.md) - 系统架构设计文档
- [MATERIAL_DASHBOARD_SPEC.md](./MATERIAL_DASHBOARD_SPEC.md) - 看板功能规格
- [Radix UI](https://www.radix-ui.com/) - UI组件文档
- [Tailwind CSS](https://tailwindcss.com/) - 样式框架文档
- [Lucide Icons](https://lucide.dev/) - 图标库

## 🤝 贡献指南

### 代码规范

1. 使用TypeScript编写所有组件
2. 遵循ESLint规则
3. 使用函数式组件和Hooks
4. 保持组件单一职责

### 命名规范

- **组件**: PascalCase (如 `MaterialPackagePage`)
- **函数**: camelCase (如 `handleQuery`)
- **常量**: UPPER_SNAKE_CASE (如 `MAX_FILE_SIZE`)
- **类型**: PascalCase (如 `MaterialPackage`)

### 文件组织

- 一个文件一个组件
- 相关组件放在同一目录
- UI组件放在 `ui/` 目录
- 业务组件放在 `components/` 根目录

## 📝 更新日志

### Version 115 (当前版本)
- ✅ 完整的素材包管理功能
- ✅ 高级筛选和排序
- ✅ 缩略图预览
- ✅ 投放数据展示
- ✅ 响应式布局
- ✅ 完善的类型定义

## 📞 支持

如有问题，请参考：
1. 系统设计文档 (SYSTEM_OVERVIEW_V2.md)
2. 代码注释
3. 组件示例

## 📄 许可证

本模板仅供学习和参考使用。

---

**模板版本**: V115  
**最后更新**: 2026-01-29  
**维护状态**: ✅ 活跃维护
