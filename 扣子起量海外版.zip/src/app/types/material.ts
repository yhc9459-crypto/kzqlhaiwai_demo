export type MaterialType = 'video' | 'image' | 'html5';

export type PushStatus = 'not_pushed' | 'pushing' | 'pushed' | 'failed';

export type MaterialStatus = 'active' | 'inactive' | 'disabled';

export type ReviewStatus = 'pending' | 'approved' | 'rejected';

export type UsageStatus = 'unused' | 'used';

export type TaskStatus = 'pending' | 'processing' | 'completed' | 'failed';

export interface Material {
  id: string;
  name: string;
  type: MaterialType;
  fileUrl: string;
  fileMd5: string;
  fileExt: string;
  designer: string;
  designerId: string;
  creator: string;              // 制作人
  creativePerson?: string;      // 创意人
  product: string;
  productType: string;
  materialGroup?: string;
  // 素材包相关字段
  packageId: string;
  packageName: string;
  packageNumber: string;
  productionType: '0-1制作' | '1-N制作';
  createdAt: string;
  pushedAt?: string;            // 推送时间
  enabledAt?: string;           // 启用时间
  pushStatus: PushStatus;
  status: MaterialStatus;
  // 审核相关字段
  reviewStatus: ReviewStatus;   // 审核状态：待审核/已通过/未通过
  reviewedBy?: string;          // 审核人姓名
  reviewerId?: string;          // 审核人ID
  reviewedAt?: string;          // 审核时间
  reviewComment?: string;       // 审核意见（驳回时填写原因）
  // 使用状态字段
  usageStatus: UsageStatus;     // 使用状态：未使用/已使用
  tags: string[];  // 素材包级别标签（从素材包继承）
  materialTags?: string[];  // 素材专属标签（素材独有）
  xmpMaterialId?: string;
  xmpUserMaterialId?: string;
  pushError?: string;
  lastPushTime?: string;
  // 投放数据字段
  size?: string;           // 素材尺寸，如 1080x1920
  qualityScore?: number;   // 质量分 0-100
  cost?: number;           // 花费（美元）
  ctr?: number;            // 点击率（百分比）
  roi?: number;            // ROI（倍数）
}

export interface PushTask {
  id: string;
  productId: string;
  productName: string;
  materialType: MaterialType;
  totalCount: number;
  successCount: number;
  failedCount: number;
  pendingCount: number;
  status: TaskStatus;
  createdAt: string;
  createdBy: string;
  completedAt?: string;
}

export interface TaskMaterialDetail {
  id: string;
  taskId: string;
  materialId: string;
  materialName: string;
  status: 'pending' | 'processing' | 'success' | 'failed';
  error?: string;
  xmpMaterialId?: string;
  xmpUserMaterialId?: string;
  pushedAt?: string;
}

export interface PushProgress {
  materialId: string;
  status: 'pending' | 'uploading' | 'success' | 'failed';
  error?: string;
  progress: number;
}