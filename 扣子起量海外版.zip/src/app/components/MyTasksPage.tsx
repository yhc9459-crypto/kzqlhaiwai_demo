import { useState } from 'react';
import { PushTask } from '../types/material';
import { mockPushTasks } from '../lib/mockData';
import { getMaterialTypeName } from '../lib/xmpService';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar } from './ui/calendar';
import { toast } from 'sonner';
import { Plus, Eye, CheckCircle2, Loader2, Clock, XCircle, CalendarIcon, RotateCcw } from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

// 当前登录用户（模拟）
const CURRENT_USER = '张三';

interface MyTasksPageProps {
  onNavigateToDetail: (taskId: string) => void;
  onNavigateToCreate: () => void;
}

export function MyTasksPage({
  onNavigateToDetail,
  onNavigateToCreate,
}: MyTasksPageProps) {
  const [tasks] = useState<PushTask[]>(
    mockPushTasks.filter(task => task.createdBy === CURRENT_USER)
  );
  const [filteredTasks, setFilteredTasks] = useState<PushTask[]>(
    mockPushTasks.filter(task => task.createdBy === CURRENT_USER)
  );

  // Filter states
  const [filterProduct, setFilterProduct] = useState<string>('');
  const [filterMaterialType, setFilterMaterialType] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [filterCreator, setFilterCreator] = useState<string>('');
  const [filterCreatedStartDate, setFilterCreatedStartDate] = useState<Date | undefined>();
  const [filterCreatedEndDate, setFilterCreatedEndDate] = useState<Date | undefined>();
  const [filterCompletedStartDate, setFilterCompletedStartDate] = useState<Date | undefined>();
  const [filterCompletedEndDate, setFilterCompletedEndDate] = useState<Date | undefined>();

  // Get unique products from tasks
  const products = Array.from(new Set(tasks.map((t) => t.productName)));

  const handleQuery = () => {
    let filtered = [...tasks];

    // Filter by product
    if (filterProduct && filterProduct !== 'all') {
      filtered = filtered.filter((task) => task.productName === filterProduct);
    }

    // Filter by material type
    if (filterMaterialType && filterMaterialType !== 'all') {
      filtered = filtered.filter((task) => task.materialType === filterMaterialType);
    }

    // Filter by status
    if (filterStatus && filterStatus !== 'all') {
      filtered = filtered.filter((task) => task.status === filterStatus);
    }

    // Filter by creator
    if (filterCreator) {
      filtered = filtered.filter((task) =>
        task.createdBy.toLowerCase().includes(filterCreator.toLowerCase())
      );
    }

    // Filter by created date range
    if (filterCreatedStartDate) {
      filtered = filtered.filter(
        (task) => new Date(task.createdAt) >= filterCreatedStartDate
      );
    }
    if (filterCreatedEndDate) {
      const endDate = new Date(filterCreatedEndDate);
      endDate.setHours(23, 59, 59, 999);
      filtered = filtered.filter((task) => new Date(task.createdAt) <= endDate);
    }

    // Filter by completed date range
    if (filterCompletedStartDate) {
      filtered = filtered.filter(
        (task) => task.completedAt && new Date(task.completedAt) >= filterCompletedStartDate
      );
    }
    if (filterCompletedEndDate) {
      const endDate = new Date(filterCompletedEndDate);
      endDate.setHours(23, 59, 59, 999);
      filtered = filtered.filter(
        (task) => task.completedAt && new Date(task.completedAt) <= endDate
      );
    }

    setFilteredTasks(filtered);
    toast.success(`查询完成，找到 ${filtered.length} 条记录`);
  };

  const handleResetFilters = () => {
    setFilterProduct('');
    setFilterMaterialType('');
    setFilterStatus('');
    setFilterCreator('');
    setFilterCreatedStartDate(undefined);
    setFilterCreatedEndDate(undefined);
    setFilterCompletedStartDate(undefined);
    setFilterCompletedEndDate(undefined);
    setFilteredTasks(tasks);
    toast.info('筛选条件已重置');
  };

  const getTaskStatusBadge = (task: PushTask) => {
    switch (task.status) {
      case 'completed':
        return (
          <Badge className="bg-green-600">
            <CheckCircle2 className="mr-1 h-3 w-3" />
            已完成
          </Badge>
        );
      case 'processing':
        return (
          <Badge className="bg-blue-600">
            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
            处理中
          </Badge>
        );
      case 'pending':
        return (
          <Badge variant="secondary">
            <Clock className="mr-1 h-3 w-3" />
            待处理
          </Badge>
        );
      case 'failed':
        return (
          <Badge variant="destructive">
            <XCircle className="mr-1 h-3 w-3" />
            失败
          </Badge>
        );
      default:
        return null;
    }
  };

  const getTaskProgress = (task: PushTask) => {
    if (task.totalCount === 0) return 0;
    return Math.round(((task.successCount + task.failedCount) / task.totalCount) * 100);
  };

  return (
    <div className="space-y-4">
      {/* 区域1: 筛选条件 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-4">
          <div className="grid grid-cols-4 gap-4">
            {/* Product Filter */}
            <div className="space-y-2">
              <Label>产品</Label>
              <Select value={filterProduct} onValueChange={setFilterProduct}>
                <SelectTrigger>
                  <SelectValue placeholder="全部产品" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部产品</SelectItem>
                  {products.map((product) => (
                    <SelectItem key={product} value={product}>
                      {product}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Material Type Filter */}
            <div className="space-y-2">
              <Label>素材类型</Label>
              <Select value={filterMaterialType} onValueChange={setFilterMaterialType}>
                <SelectTrigger>
                  <SelectValue placeholder="全部类型" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部类型</SelectItem>
                  <SelectItem value="video">视频</SelectItem>
                  <SelectItem value="image">图片</SelectItem>
                  <SelectItem value="html5">HTML5</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Status Filter */}
            <div className="space-y-2">
              <Label>任务状态</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="全部状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="completed">已完成</SelectItem>
                  <SelectItem value="processing">处理中</SelectItem>
                  <SelectItem value="pending">待处理</SelectItem>
                  <SelectItem value="failed">失败</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Creator Filter */}
            <div className="space-y-2">
              <Label>创建人</Label>
              <Input
                placeholder="输入创建人姓名"
                value={filterCreator}
                onChange={(e) => setFilterCreator(e.target.value)}
              />
            </div>

            {/* Created Date Range */}
            <div className="col-span-2 space-y-2">
              <Label>创建时间</Label>
              <div className="grid grid-cols-2 gap-4">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {filterCreatedStartDate
                        ? format(filterCreatedStartDate, 'yyyy-MM-dd')
                        : '开始日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={filterCreatedStartDate}
                      onSelect={setFilterCreatedStartDate}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {filterCreatedEndDate
                        ? format(filterCreatedEndDate, 'yyyy-MM-dd')
                        : '结束日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={filterCreatedEndDate}
                      onSelect={setFilterCreatedEndDate}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Completed Date Range */}
            <div className="col-span-2 space-y-2">
              <Label>完成时间</Label>
              <div className="grid grid-cols-2 gap-4">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {filterCompletedStartDate
                        ? format(filterCompletedStartDate, 'yyyy-MM-dd')
                        : '开始日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={filterCompletedStartDate}
                      onSelect={setFilterCompletedStartDate}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {filterCompletedEndDate
                        ? format(filterCompletedEndDate, 'yyyy-MM-dd')
                        : '结束日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={filterCompletedEndDate}
                      onSelect={setFilterCompletedEndDate}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={handleResetFilters}>
              <RotateCcw className="mr-2 h-4 w-4" />
              重置
            </Button>
            <Button onClick={handleQuery}>查询</Button>
          </div>
        </div>
      </div>

      {/* 区域2: 列表 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-4">
          {/* Header with Create Button */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-medium">本人推送任务</h2>
              <p className="text-sm text-gray-500 mt-1">
                查看和管理您创建的推送任务，实时监控任务执行状态
              </p>
            </div>
            <Button onClick={onNavigateToCreate}>
              <Plus className="mr-2 h-4 w-4" />
              创建推送任务
            </Button>
          </div>

          {/* Task Table */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead>任务ID</TableHead>
                  <TableHead>产品</TableHead>
                  <TableHead>素材类型</TableHead>
                  <TableHead>任务状态</TableHead>
                  <TableHead>总数</TableHead>
                  <TableHead>成功数</TableHead>
                  <TableHead>失败数</TableHead>
                  <TableHead>待处理数</TableHead>
                  <TableHead>创建时间</TableHead>
                  <TableHead>完成时间</TableHead>
                  <TableHead>创建人</TableHead>
                  <TableHead className="w-24">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTasks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={12} className="text-center py-12 text-gray-500">
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-4xl">📋</div>
                        <div>暂无推送任务</div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-2"
                          onClick={onNavigateToCreate}
                        >
                          <Plus className="mr-2 h-4 w-4" />
                          创建第一个任务
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTasks.map((task) => {
                    const progress = getTaskProgress(task);
                    return (
                      <TableRow key={task.id} className="hover:bg-gray-50">
                        <TableCell className="font-mono text-xs">{task.id}</TableCell>
                        <TableCell>{task.productName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {getMaterialTypeName(task.materialType)}
                          </Badge>
                        </TableCell>
                        <TableCell>{getTaskStatusBadge(task)}</TableCell>
                        <TableCell>
                          <span className="font-medium">{task.totalCount}</span>
                        </TableCell>
                        <TableCell>
                          <span className="text-green-600 font-medium">
                            {task.successCount}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="text-red-600 font-medium">
                            {task.failedCount}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="text-blue-600 font-medium">
                            {task.pendingCount}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {format(new Date(task.createdAt), 'yyyy-MM-dd HH:mm', {
                            locale: zhCN,
                          })}
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {task.completedAt
                            ? format(new Date(task.completedAt), 'yyyy-MM-dd HH:mm', {
                                locale: zhCN,
                              })
                            : '-'}
                        </TableCell>
                        <TableCell>{task.createdBy}</TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="link"
                            onClick={() => onNavigateToDetail(task.id)}
                            className="h-auto p-0 text-blue-600 hover:text-blue-700"
                          >
                            <Eye className="mr-1 h-3.5 w-3.5" />
                            查看详情
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {filteredTasks.length > 0 && (
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">共 {filteredTasks.length} 条记录</div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  上一页
                </Button>
                <Button variant="default" size="sm">
                  1
                </Button>
                <Button variant="outline" size="sm" disabled>
                  下一页
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
