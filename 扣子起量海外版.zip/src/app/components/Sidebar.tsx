import { useState } from 'react';
import { FileVideo, FileImage, FileCode, History, ChevronRight, Layers, User, Users, BarChart3, TrendingUp, Package, Palette, Tags, Tag } from 'lucide-react';
import { cn } from './ui/utils';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export function Sidebar({ currentPage, onPageChange, isCollapsed }: SidebarProps) {
  // 三级菜单结构
  const menuItems = [
    {
      id: 'material-root',
      label: '素材',
      icon: Layers,
      children: [
        {
          id: 'material-package',
          label: '本人素材包',
          icon: Package,
        },
        {
          id: 'all-material-package',
          label: '全部素材包',
          icon: Package,
        },
        {
          id: 'material-management',
          label: '素材管理',
          icon: FileVideo,
          children: [
            { id: 'video', label: '视频库', icon: FileVideo },
            { id: 'image', label: '图片库', icon: FileImage },
            { id: 'html5', label: 'H5页面', icon: FileCode },
          ],
        },
        {
          id: 'push-tasks',
          label: '推送任务',
          icon: History,
          children: [
            { id: 'my-tasks', label: '本人任务', icon: User },
            { id: 'all-tasks', label: '全部任务', icon: Users },
          ],
        },
      ],
    },
    {
      id: 'tag-management-root',
      label: '标签管理',
      icon: Tags,
      children: [
        {
          id: 'package-tag-management',
          label: '素材包标签管理',
          icon: Tags,
        },
        {
          id: 'material-tag-management',
          label: '素材标签管理',
          icon: Tag,
        },
      ],
    },
    {
      id: 'data-root',
      label: '数据',
      icon: BarChart3,
      children: [
        {
          id: 'material-dashboard',
          label: '素材看板',
          icon: BarChart3,
        },
        {
          id: 'designer-dashboard',
          label: '设计师看板',
          icon: Palette,
        },
        {
          id: 'efficiency-dashboard',
          label: '人效看板',
          icon: TrendingUp,
        },
      ],
    },
  ];

  // 默认展开第一级和第二级
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(
    new Set(['material-root', 'material-management', 'push-tasks', 'tag-management-root', 'data-root'])
  );

  const toggleGroup = (groupId: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupId)) {
      newExpanded.delete(groupId);
    } else {
      newExpanded.add(groupId);
    }
    setExpandedGroups(newExpanded);
  };

  // Helper to check if current page matches a menu item
  const isCurrentPage = (itemId: string) => {
    if (currentPage === itemId) return true;
    // For task-related pages, highlight corresponding task menu item
    if (itemId === 'my-tasks' && (currentPage === 'create-task' || currentPage === 'task-detail')) {
      return true;
    }
    if (itemId === 'all-tasks' && (currentPage === 'create-task' || currentPage === 'task-detail')) {
      return true;
    }
    return false;
  };

  return (
    <aside
      className={cn(
        'bg-white border-r border-gray-200 flex flex-col transition-all duration-300',
        isCollapsed ? 'w-16' : 'w-56'
      )}
    >
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-orange-500 rounded flex items-center justify-center text-white">
            <span className="text-xs">扣</span>
          </div>
          {!isCollapsed && <span className="font-medium">扣子起量</span>}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4">
        {menuItems.map((firstLevel) => (
          <div key={firstLevel.id} className="mb-2">
            {/* 第一级菜单 */}
            <button
              onClick={() => toggleGroup(firstLevel.id)}
              className="w-full px-4 py-2 flex items-center justify-between hover:bg-gray-50 text-sm font-medium text-gray-900"
            >
              <div className="flex items-center gap-2">
                <firstLevel.icon className="h-4 w-4" />
                {!isCollapsed && <span>{firstLevel.label}</span>}
              </div>
              {!isCollapsed && (
                <ChevronRight
                  className={cn(
                    'h-4 w-4 transition-transform',
                    expandedGroups.has(firstLevel.id) && 'rotate-90'
                  )}
                />
              )}
            </button>

            {/* 第二级菜单 */}
            {expandedGroups.has(firstLevel.id) && !isCollapsed && (
              <div className="ml-2">
                {firstLevel.children.map((secondLevel) => (
                  <div key={secondLevel.id} className="mb-1">
                    {secondLevel.children ? (
                      // 有子菜单的二级项（如素材管理）
                      <>
                        <button
                          onClick={() => toggleGroup(secondLevel.id)}
                          className="w-full px-4 py-2 flex items-center justify-between hover:bg-gray-50 text-sm text-gray-700"
                        >
                          <div className="flex items-center gap-2">
                            <secondLevel.icon className="h-4 w-4" />
                            <span>{secondLevel.label}</span>
                          </div>
                          <ChevronRight
                            className={cn(
                              'h-4 w-4 transition-transform',
                              expandedGroups.has(secondLevel.id) && 'rotate-90'
                            )}
                          />
                        </button>

                        {/* 第三级菜单 */}
                        {expandedGroups.has(secondLevel.id) && (
                          <div className="ml-4">
                            {secondLevel.children.map((thirdLevel) => (
                              <button
                                key={thirdLevel.id}
                                onClick={() => onPageChange(thirdLevel.id)}
                                className={cn(
                                  'w-full px-4 py-2 flex items-center gap-2 text-sm rounded-lg transition-colors',
                                  isCurrentPage(thirdLevel.id)
                                    ? 'bg-blue-50 text-blue-600'
                                    : 'text-gray-600 hover:bg-gray-50'
                                )}
                              >
                                <thirdLevel.icon className="h-4 w-4" />
                                <span>{thirdLevel.label}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </>
                    ) : (
                      // 无子菜单的二级项（如推送任务），直接跳转
                      <button
                        onClick={() => onPageChange(secondLevel.id)}
                        className={cn(
                          'w-full px-4 py-2 flex items-center gap-2 text-sm rounded-lg transition-colors',
                          isCurrentPage(secondLevel.id)
                            ? 'bg-blue-50 text-blue-600'
                            : 'text-gray-700 hover:bg-gray-50'
                        )}
                      >
                        <secondLevel.icon className="h-4 w-4" />
                        <span>{secondLevel.label}</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>
    </aside>
  );
}