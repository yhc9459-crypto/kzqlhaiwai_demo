import { useState, useMemo } from 'react';
import { Plus, Search, Edit2, Power, PowerOff, History } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { toast } from 'sonner';
import { cn } from './ui/utils';

// 标签类型定义
export type TagType = 'package' | 'material';
export type TagCategory = '前贴' | '主题' | '内容' | '节奏氛围' | '其他' | '前贴部分';
export type TagStatus = 'active' | 'inactive';

export interface Tag {
  id: string;
  name: string;
  description: string;
  category: TagCategory;
  type: TagType;
  status: TagStatus;
  usageCount: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface TagOperation {
  id: string;
  action: '创建' | '编辑' | '启用' | '停用';
  tagName: string;
  tagType: TagType;
  tagCategory: TagCategory;
  operator: string;
  timestamp: string;
  details?: string;
}

// 素材包标签分类
const packageCategories: TagCategory[] = ['前贴', '主题', '内容', '节奏氛围', '其他'];

// 素材标签分类
const materialCategories: TagCategory[] = ['前贴部分', '主题', '内容', '节奏氛围', '其他'];

// 初始化标签数据（基于素材标签配置.md）
const initializePackageTags = (): Tag[] => {
  const tags: Tag[] = [];
  const now = new Date().toISOString();
  
  // 前贴标签
  const qiantieLabels = [
    { name: '前贴-真人', desc: '使用真人出镜的前贴' },
    { name: '前贴-动画', desc: '使用动画形式的前贴' },
    { name: '前贴-大字报', desc: '使用大字报风格的前贴' },
    { name: '前贴-AI', desc: '使用AI生成的前贴' },
    { name: '前贴-风景', desc: '使用风景画面的前贴' },
    { name: '前贴-诱导', desc: '具有诱导性质的前贴' },
    { name: '前贴-展示', desc: '展示型前贴' },
    { name: '前贴-实拍', desc: '实拍素材的前贴' },
    { name: '前贴-ASMR', desc: 'ASMR风格的前贴' },
    { name: '前贴-猎奇', desc: '猎奇风格的前贴' },
    { name: '前贴-阵型展示', desc: '展示阵型的前贴' },
  ];
  
  // 主题标签
  const zhuti = [
    { name: '主题-纯色', desc: '纯色背景主题' },
    { name: '主题-设计包装', desc: '设计包装风格主题' },
    { name: '主题-材质纹理', desc: '材质纹理风格主题' },
    { name: '主题-风景', desc: '风景主题' },
    { name: '主题-AI', desc: 'AI生成风格主题' },
    { name: '主题-小清新', desc: '小清新风格主题' },
    { name: '主题-体育竞技', desc: '体育竞技主题' },
    { name: '主题-真人', desc: '真人出镜主题' },
    { name: '主题-霓虹', desc: '霓虹风格主题' },
    { name: '主题-复古', desc: '复古风格主题' },
    { name: '主题-木纹', desc: '木纹风格主题' },
    { name: '主题-手绘', desc: '手绘风格主题' },
    { name: '主题-车内', desc: '车内场景主题' },
    { name: '主题-食物', desc: '食物主题' },
    { name: '主题-曼陀罗', desc: '曼陀罗图案主题' },
    { name: '主题-博彩', desc: '博彩风格主题' },
  ];
  
  // 内容标签
  const neirong = [
    { name: '内容-核心玩法', desc: '展示产品核心玩法' },
    { name: '内容-竞品玩法', desc: '展示竞品玩法' },
    { name: '内容-跨品类', desc: '跨品类内容' },
    { name: '内容-展示', desc: '展示型内容' },
    { name: '内容-诱导', desc: '诱导型内容' },
    { name: '内容-情绪', desc: '情绪化内容' },
    { name: '内容-科普', desc: '科普型内容' },
    { name: '内容-收集', desc: '收集玩法内容' },
    { name: '内容-闯关', desc: '闯关玩法内容' },
    { name: '内容-多骰子', desc: '多骰子玩法内容' },
  ];
  
  // 节奏氛围标签
  const jiezou = [
    { name: '无BGM', desc: '无背景音乐' },
    { name: '纯音乐', desc: '纯音乐背景' },
    { name: '歌曲', desc: '使用歌曲作为背景音乐' },
    { name: '白噪音', desc: '白噪音背景' },
    { name: '慢节奏', desc: '慢节奏风格' },
    { name: '快节奏', desc: '快节奏风格' },
    { name: 'BGM卡点', desc: 'BGM卡点设计' },
    { name: '神秘', desc: '神秘氛围' },
  ];
  
  // 其他标签
  const qita = [
    { name: '3D', desc: '3D效果素材' },
    { name: '扁平极简', desc: '扁平极简风格' },
    { name: '文案口播', desc: '文案口播形式' },
    { name: '纯文案', desc: '纯文案展示' },
    { name: '文案真人口播', desc: '真人口播文案' },
    { name: '节日元素', desc: '包含节日元素' },
    { name: '卡通', desc: '卡通风格' },
    { name: '实拍', desc: '实拍素材' },
    { name: 'top集合', desc: '优质素材集合' },
    { name: '线稿', desc: '线稿风格' },
    { name: '成功', desc: '成功场景' },
    { name: '失败', desc: '失败场景' },
    { name: '条件限制', desc: '有条件限制的玩法' },
    { name: '对称阵型', desc: '对称阵型展示' },
    { name: '异形阵型', desc: '异形阵型展示' },
    { name: '满屏平铺', desc: '满屏平铺效果' },
  ];
  
  let id = 1;
  const addTags = (labels: Array<{name: string, desc: string}>, category: TagCategory) => {
    labels.forEach(label => {
      tags.push({
        id: `pkg-tag-${id++}`,
        name: label.name,
        description: label.desc,
        category,
        type: 'package',
        status: 'active',
        usageCount: Math.floor(Math.random() * 50),
        createdBy: '系统管理员',
        createdAt: now,
        updatedAt: now,
      });
    });
  };
  
  addTags(qiantieLabels, '前贴');
  addTags(zhuti, '主题');
  addTags(neirong, '内容');
  addTags(jiezou, '节奏氛围');
  addTags(qita, '其他');
  
  return tags;
};

const initializeMaterialTags = (): Tag[] => {
  const tags: Tag[] = [];
  const now = new Date().toISOString();
  
  // 前贴部分标签
  const qiantieBufen = [
    { name: '前贴-材质展示', desc: '展示材质效果的前贴' },
    { name: '前贴-特效展示', desc: '展示特效的前贴' },
    { name: '前贴-剧情提现', desc: '剧情提现类前贴' },
    { name: '前贴-剧情', desc: '剧情类前贴' },
    { name: '前贴-情绪展示', desc: '展示情绪的前贴' },
    { name: '前贴-核心文案', desc: '核心文案类前贴' },
    { name: '前贴-叙事文案', desc: '叙事文案类前贴' },
    { name: '前贴-食物对比', desc: '食物对比类前贴' },
    { name: '前贴-抽像元素', desc: '抽象元素类前贴' },
    { name: '前贴-AI小人', desc: 'AI小人类前贴' },
    { name: '前贴-运动', desc: '运动类前贴' },
    { name: '前贴-身材对比', desc: '身材对比类前贴' },
  ];
  
  // 主题标签
  const zhuti = [
    { name: '主题-绿色', desc: '绿色主题' },
    { name: '主题-红色', desc: '红色主题' },
    { name: '主题-冷色调', desc: '冷色调主题' },
    { name: '主题-暖色调', desc: '暖色调主题' },
    { name: '主题-植物', desc: '植物主题' },
    { name: '主题-季节', desc: '季节主题' },
    { name: '主题-机车', desc: '机车主题' },
    { name: '主题-多人', desc: '多人场景主题' },
    { name: '主题-字母', desc: '字母元素主题' },
    { name: '主题-建筑', desc: '建筑主题' },
    { name: '主题-高卡', desc: '高卡路里主题' },
    { name: '主题-粉色', desc: '粉色主题' },
    { name: '主题-紫色', desc: '紫色主题' },
    { name: '主题-黑色', desc: '黑色主题' },
    { name: '主题-金色', desc: '金色主题' },
    { name: '主题-科技', desc: '科技风格主题' },
    { name: '主题-动物', desc: '动物主题' },
    { name: '主题-室内', desc: '室内场景主题' },
    { name: '主题-室外', desc: '室外场景主题' },
    { name: '主题-单人', desc: '单人场景主题' },
    { name: '主题-美妆', desc: '美妆主题' },
    { name: '主题-低卡', desc: '低卡路里主题' },
    { name: '主题-动画', desc: '动画风格主题' },
  ];
  
  // 内容标签
  const neirong = [
    { name: '内容-点击', desc: '点击类玩法' },
    { name: '内容-推动', desc: '推动类玩法' },
    { name: '内容-拖动', desc: '拖动类玩法' },
    { name: '内容-连线', desc: '连线类玩法' },
    { name: '内容-长连线', desc: '长连线类玩法' },
    { name: '内容-三消', desc: '三消类玩法' },
    { name: '内容-扫雷', desc: '扫雷类玩法' },
    { name: '内容-障碍物', desc: '障碍物类玩法' },
    { name: '内容-迷宫', desc: '迷宫类玩法' },
    { name: '内容-点击屏幕', desc: '点击屏幕类玩法' },
    { name: '内容-翻页', desc: '翻页类玩法' },
    { name: '内容-翻牌', desc: '翻牌类玩法' },
    { name: '内容-扫描', desc: '扫描类玩法' },
  ];
  
  // 节奏氛围标签
  const jiezou = [
    { name: '埃及', desc: '埃及风格氛围' },
  ];
  
  // 其他标签
  const qita = [
    { name: '碎裂', desc: '碎裂效果' },
    { name: '拖尾', desc: '拖尾效果' },
    { name: '女性', desc: '女性角色' },
    { name: '男性', desc: '男性角色' },
    { name: '老人', desc: '老人角色' },
    { name: '中年', desc: '中年角色' },
    { name: '青年', desc: '青年角色' },
    { name: '小孩', desc: '小孩角色' },
    { name: '多层阵型', desc: '多层阵型展示' },
    { name: '国风', desc: '国风风格' },
  ];
  
  let id = 1;
  const addTags = (labels: Array<{name: string, desc: string}>, category: TagCategory) => {
    labels.forEach(label => {
      tags.push({
        id: `mat-tag-${id++}`,
        name: label.name,
        description: label.desc,
        category,
        type: 'material',
        status: 'active',
        usageCount: Math.floor(Math.random() * 100),
        createdBy: '系统管理员',
        createdAt: now,
        updatedAt: now,
      });
    });
  };
  
  addTags(qiantieBufen, '前贴部分');
  addTags(zhuti, '主题');
  addTags(neirong, '内容');
  addTags(jiezou, '节奏氛围');
  addTags(qita, '其他');
  
  return tags;
};

// 模拟操作历史数据
const initializeOperations = (): TagOperation[] => {
  const operations: TagOperation[] = [];
  const actions: Array<'创建' | '编辑' | '启用' | '停用'> = ['创建', '编辑', '启用', '停用'];
  const operators = ['张三', '李四', '王五', '系统管理员'];
  
  for (let i = 1; i <= 20; i++) {
    const action = actions[Math.floor(Math.random() * actions.length)];
    const tagType: TagType = Math.random() > 0.5 ? 'package' : 'material';
    const categories = tagType === 'package' ? packageCategories : materialCategories;
    const category = categories[Math.floor(Math.random() * categories.length)];
    
    operations.push({
      id: `op-${i}`,
      action,
      tagName: `测试标签-${i}`,
      tagType,
      tagCategory: category,
      operator: operators[Math.floor(Math.random() * operators.length)],
      timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      details: action === '编辑' ? '修改了标签描述' : undefined,
    });
  }
  
  return operations.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
};

export function TagManagementPage() {
  const [tagType, setTagType] = useState<TagType>('package');
  const [selectedCategory, setSelectedCategory] = useState<TagCategory>('前贴');
  const [searchQuery, setSearchQuery] = useState('');
  const [packageTags, setPackageTags] = useState<Tag[]>(initializePackageTags());
  const [materialTags, setMaterialTags] = useState<Tag[]>(initializeMaterialTags());
  const [operations, setOperations] = useState<TagOperation[]>(initializeOperations());
  const [showHistory, setShowHistory] = useState(false);
  
  // 对话框状态
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);
  
  // 表单状态
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: selectedCategory,
  });
  
  // 获取当前分类列表
  const categories = tagType === 'package' ? packageCategories : materialCategories;
  
  // 获取当前标签列表
  const currentTags = tagType === 'package' ? packageTags : materialTags;
  
  // 过滤和搜索标签
  const filteredTags = useMemo(() => {
    return currentTags.filter(tag => {
      const matchesCategory = tag.category === selectedCategory;
      const matchesSearch = searchQuery === '' || 
        tag.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tag.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [currentTags, selectedCategory, searchQuery]);
  
  // 统计数据
  const categoryStats = useMemo(() => {
    const stats: Record<string, { total: number; active: number }> = {};
    categories.forEach(cat => {
      const categoryTags = currentTags.filter(t => t.category === cat);
      stats[cat] = {
        total: categoryTags.length,
        active: categoryTags.filter(t => t.status === 'active').length,
      };
    });
    return stats;
  }, [currentTags, categories]);
  
  // 处理添加标签
  const handleAddTag = () => {
    if (!formData.name.trim()) {
      toast.error('请输入标签名称');
      return;
    }
    
    const newTag: Tag = {
      id: `${tagType}-tag-${Date.now()}`,
      name: formData.name,
      description: formData.description,
      category: formData.category as TagCategory,
      type: tagType,
      status: 'active',
      usageCount: 0,
      createdBy: '当前用户',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    if (tagType === 'package') {
      setPackageTags([...packageTags, newTag]);
    } else {
      setMaterialTags([...materialTags, newTag]);
    }
    
    // 添加操作记录
    const newOperation: TagOperation = {
      id: `op-${Date.now()}`,
      action: '创建',
      tagName: formData.name,
      tagType,
      tagCategory: formData.category as TagCategory,
      operator: '当前用户',
      timestamp: new Date().toISOString(),
    };
    setOperations([newOperation, ...operations]);
    
    toast.success('标签创建成功');
    setIsAddDialogOpen(false);
    setFormData({ name: '', description: '', category: selectedCategory });
  };
  
  // 处理编辑标签
  const handleEditTag = () => {
    if (!editingTag || !formData.name.trim()) {
      toast.error('请输入标签名称');
      return;
    }
    
    const updateTags = (tags: Tag[]) => 
      tags.map(tag => 
        tag.id === editingTag.id 
          ? { ...tag, name: formData.name, description: formData.description, updatedAt: new Date().toISOString() }
          : tag
      );
    
    if (tagType === 'package') {
      setPackageTags(updateTags(packageTags));
    } else {
      setMaterialTags(updateTags(materialTags));
    }
    
    // 添加操作记录
    const newOperation: TagOperation = {
      id: `op-${Date.now()}`,
      action: '编辑',
      tagName: formData.name,
      tagType,
      tagCategory: editingTag.category,
      operator: '当前用户',
      timestamp: new Date().toISOString(),
      details: '修改了标签信息',
    };
    setOperations([newOperation, ...operations]);
    
    toast.success('标签更新成功');
    setIsEditDialogOpen(false);
    setEditingTag(null);
    setFormData({ name: '', description: '', category: selectedCategory });
  };
  
  // 切换标签状态
  const handleToggleStatus = (tag: Tag) => {
    const newStatus: TagStatus = tag.status === 'active' ? 'inactive' : 'active';
    
    const updateTags = (tags: Tag[]) => 
      tags.map(t => 
        t.id === tag.id 
          ? { ...t, status: newStatus, updatedAt: new Date().toISOString() }
          : t
      );
    
    if (tagType === 'package') {
      setPackageTags(updateTags(packageTags));
    } else {
      setMaterialTags(updateTags(materialTags));
    }
    
    // 添加操作记录
    const newOperation: TagOperation = {
      id: `op-${Date.now()}`,
      action: newStatus === 'active' ? '启用' : '停用',
      tagName: tag.name,
      tagType: tag.type,
      tagCategory: tag.category,
      operator: '当前用户',
      timestamp: new Date().toISOString(),
    };
    setOperations([newOperation, ...operations]);
    
    toast.success(`标签已${newStatus === 'active' ? '启用' : '停用'}`);
  };
  
  // 打开编辑对话框
  const openEditDialog = (tag: Tag) => {
    setEditingTag(tag);
    setFormData({
      name: tag.name,
      description: tag.description,
      category: tag.category,
    });
    setIsEditDialogOpen(true);
  };
  
  // 打开添加对话框
  const openAddDialog = () => {
    setFormData({
      name: '',
      description: '',
      category: selectedCategory,
    });
    setIsAddDialogOpen(true);
  };
  
  // 切换标签类型时重置选择的分类
  const handleTagTypeChange = (newType: string) => {
    setTagType(newType as TagType);
    // 根据新的类型设置默认分类
    if (newType === 'package') {
      setSelectedCategory('前贴');
    } else {
      setSelectedCategory('前贴部分');
    }
  };
  
  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">标签管理</h1>
          <p className="text-sm text-gray-500 mt-1">
            管理素材包标签和素材标签，支持增删改查及操作记录追溯
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowHistory(!showHistory)}
        >
          <History className="h-4 w-4 mr-2" />
          {showHistory ? '隐藏' : '显示'}操作历史
        </Button>
      </div>
      
      {/* 标签类型选择 */}
      <Tabs value={tagType} onValueChange={handleTagTypeChange}>
        <TabsList>
          <TabsTrigger value="package">素材包标签</TabsTrigger>
          <TabsTrigger value="material">素材标签</TabsTrigger>
        </TabsList>
        
        <TabsContent value={tagType} className="mt-6">
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧分类导航 */}
            <div className="col-span-3">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">标签分类</CardTitle>
                  <CardDescription className="text-xs">
                    共 {categories.length} 个分类
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="h-[600px] overflow-y-auto">
                    <div className="space-y-1 p-2">
                      {categories.map(category => {
                        const stats = categoryStats[category] || { total: 0, active: 0 };
                        return (
                          <button
                            key={category}
                            onClick={() => setSelectedCategory(category)}
                            className={cn(
                              'w-full text-left px-3 py-2.5 rounded-md transition-colors',
                              'flex items-center justify-between group',
                              selectedCategory === category
                                ? 'bg-blue-50 text-blue-700'
                                : 'hover:bg-gray-100 text-gray-700'
                            )}
                          >
                            <span className="font-medium">{category}</span>
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className="text-xs">
                                {stats.active}/{stats.total}
                              </Badge>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* 右侧内容区 */}
            <div className={cn(
              'transition-all duration-300',
              showHistory ? 'col-span-5' : 'col-span-9'
            )}>
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{selectedCategory}</CardTitle>
                      <CardDescription>
                        共 {filteredTags.length} 个标签
                      </CardDescription>
                    </div>
                    <Button onClick={openAddDialog}>
                      <Plus className="h-4 w-4 mr-2" />
                      添加标签
                    </Button>
                  </div>
                  {/* 搜索框 */}
                  <div className="mt-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="搜索标签名称或描述..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>标签名称</TableHead>
                          <TableHead>说明</TableHead>
                          <TableHead className="text-center">使用次数</TableHead>
                          <TableHead className="text-center">状态</TableHead>
                          <TableHead>创建人</TableHead>
                          <TableHead>创建时间</TableHead>
                          <TableHead className="text-right">操作</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredTags.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                              暂无标签数据
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredTags.map(tag => (
                            <TableRow key={tag.id}>
                              <TableCell className="font-medium">{tag.name}</TableCell>
                              <TableCell className="max-w-xs truncate text-gray-600 text-sm">
                                {tag.description}
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge variant="outline">{tag.usageCount}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge variant={tag.status === 'active' ? 'default' : 'secondary'}>
                                  {tag.status === 'active' ? '启用' : '停用'}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-sm text-gray-600">{tag.createdBy}</TableCell>
                              <TableCell className="text-sm text-gray-600">
                                {new Date(tag.createdAt).toLocaleDateString('zh-CN')}
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => openEditDialog(tag)}
                                  >
                                    <Edit2 className="h-3.5 w-3.5" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleToggleStatus(tag)}
                                  >
                                    {tag.status === 'active' ? (
                                      <PowerOff className="h-3.5 w-3.5 text-red-500" />
                                    ) : (
                                      <Power className="h-3.5 w-3.5 text-green-500" />
                                    )}
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* 操作历史面板 */}
            {showHistory && (
              <div className="col-span-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">操作历史</CardTitle>
                    <CardDescription className="text-xs">
                      最近 {operations.length} 条操作记录
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="h-[600px] overflow-y-auto">
                      <div className="space-y-3 p-4">
                        {operations.map(op => (
                          <div
                            key={op.id}
                            className="border-l-2 border-blue-200 pl-4 pb-3"
                          >
                            <div className="flex items-start justify-between">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <Badge
                                    variant={
                                      op.action === '创建' ? 'default' :
                                      op.action === '编辑' ? 'secondary' :
                                      op.action === '启用' ? 'default' : 'destructive'
                                    }
                                    className="text-xs"
                                  >
                                    {op.action}
                                  </Badge>
                                  <span className="text-sm font-medium">{op.tagName}</span>
                                </div>
                                <div className="text-xs text-gray-500 space-y-0.5">
                                  <div>分类：{op.tagCategory}</div>
                                  <div>类型：{op.tagType === 'package' ? '素材包标签' : '素材标签'}</div>
                                  <div>操作人：{op.operator}</div>
                                  {op.details && <div className="text-gray-400">备注：{op.details}</div>}
                                </div>
                              </div>
                            </div>
                            <div className="text-xs text-gray-400 mt-2">
                              {new Date(op.timestamp).toLocaleString('zh-CN', {
                                month: '2-digit',
                                day: '2-digit',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      {/* 添加标签对话框 */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>添加{tagType === 'package' ? '素材包' : '素材'}标签</DialogTitle>
            <DialogDescription>
              为 {selectedCategory} 分类添加新标签
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="tag-name">标签名称 *</Label>
              <Input
                id="tag-name"
                placeholder="请输入标签名称"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tag-category">所属分类</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value as TagCategory })}
              >
                <SelectTrigger id="tag-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="tag-description">标签说明</Label>
              <Textarea
                id="tag-description"
                placeholder="请输入标签说明"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleAddTag}>
              确定添加
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* 编辑标签对话框 */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>编辑标签</DialogTitle>
            <DialogDescription>
              修改标签信息
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-tag-name">标签名称 *</Label>
              <Input
                id="edit-tag-name"
                placeholder="请输入标签名称"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-tag-description">标签说明</Label>
              <Textarea
                id="edit-tag-description"
                placeholder="请输入标签说明"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleEditTag}>
              保存修改
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}