import { Material } from "../types/material";
import { Badge } from "./ui/badge";

interface MaterialTagsCellProps {
  material: Material;
}

export function MaterialTagsCell({ material }: MaterialTagsCellProps) {
  // 合并素材包标签和素材专属标签
  const packageTags = material.tags || [];
  const materialTags = material.materialTags || [];
  const allTags = [...packageTags, ...materialTags];

  return (
    <div className="flex flex-wrap gap-1">
      {allTags.slice(0, 2).map((tag, index) => (
        <Badge key={index} variant="outline" className="text-xs">
          {tag}
        </Badge>
      ))}
      {allTags.length > 2 && (
        <Badge variant="outline" className="text-xs">
          +{allTags.length - 2}
        </Badge>
      )}
    </div>
  );
}
