import { useState } from 'react';
import { ArrowLeft, Download, Play } from 'lucide-react';
import { cn } from './ui/utils';

// 按渠道数据类型
interface ChannelData {
  channel: string;
  cost: number;
  impressions: number;
  clicks: number;
  ctr: number;
  cvr: number;
  ipm: number;
  cpm: number;
  installs: number;
  d2Retention: number;
  d7Retention: number;
  d30Retention: number;
  paying: number;
  roi: number;
  qualityScore: number;
}

// 按国家数据类型
interface CountryData {
  country: string;
  cost: number;
  impressions: number;
  clicks: number;
  ctr: number;
  cvr: number;
  ipm: number;
  cpm: number;
  installs: number;
  d2Retention: number;
  d7Retention: number;
  d30Retention: number;
  paying: number;
  roi: number;
  qualityScore: number;
}

// Mock 数据
const mockChannelData: ChannelData[] = [
  {
    channel: 'Facebook',
    cost: 8520.50,
    impressions: 2800000,
    clicks: 238000,
    ctr: 8.5,
    cvr: 3.2,
    ipm: 1520,
    cpm: 3.04,
    installs: 7616,
    d2Retention: 45.2,
    d7Retention: 28.5,
    d30Retention: 12.8,
    paying: 856,
    roi: 2.8,
    qualityScore: 92,
  },
  {
    channel: 'Google Ads',
    cost: 5680.20,
    impressions: 1950000,
    clicks: 156000,
    ctr: 8.0,
    cvr: 2.9,
    ipm: 1380,
    cpm: 2.91,
    installs: 4524,
    d2Retention: 42.8,
    d7Retention: 26.2,
    d30Retention: 11.5,
    paying: 520,
    roi: 2.3,
    qualityScore: 88,
  },
  {
    channel: 'TikTok',
    cost: 3250.75,
    impressions: 1520000,
    clicks: 121600,
    ctr: 8.0,
    cvr: 3.5,
    ipm: 1620,
    cpm: 2.14,
    installs: 4256,
    d2Retention: 48.5,
    d7Retention: 31.2,
    d30Retention: 14.2,
    paying: 485,
    roi: 3.1,
    qualityScore: 90,
  },
];

const mockCountryData: CountryData[] = [
  {
    country: '美国',
    cost: 6850.30,
    impressions: 1850000,
    clicks: 157250,
    ctr: 8.5,
    cvr: 3.1,
    ipm: 1480,
    cpm: 3.70,
    installs: 4875,
    d2Retention: 46.8,
    d7Retention: 29.5,
    d30Retention: 13.2,
    paying: 682,
    roi: 2.9,
    qualityScore: 91,
  },
  {
    country: '日本',
    cost: 4320.50,
    impressions: 1280000,
    clicks: 102400,
    ctr: 8.0,
    cvr: 3.3,
    ipm: 1520,
    cpm: 3.38,
    installs: 3379,
    d2Retention: 48.2,
    d7Retention: 30.8,
    d30Retention: 14.5,
    paying: 425,
    roi: 3.2,
    qualityScore: 93,
  },
  {
    country: '韩国',
    cost: 3580.20,
    impressions: 1120000,
    clicks: 89600,
    ctr: 8.0,
    cvr: 2.8,
    ipm: 1420,
    cpm: 3.20,
    installs: 2509,
    d2Retention: 43.5,
    d7Retention: 27.2,
    d30Retention: 11.8,
    paying: 298,
    roi: 2.5,
    qualityScore: 87,
  },
  {
    country: '中国',
    cost: 2700.45,
    impressions: 1250000,
    clicks: 106250,
    ctr: 8.5,
    cvr: 3.0,
    ipm: 1580,
    cpm: 2.16,
    installs: 3188,
    d2Retention: 44.8,
    d7Retention: 28.2,
    d30Retention: 12.5,
    paying: 356,
    roi: 2.7,
    qualityScore: 89,
  },
];

interface MaterialDetailPageProps {
  materialId: string;
  onBack: () => void;
}

export function MaterialDetailPage({ materialId, onBack }: MaterialDetailPageProps) {
  const [viewMode, setViewMode] = useState<'channel' | 'country'>('channel');
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | 'all'>('30d');

  // Mock 素材信息
  const materialInfo = {
    name: 'bingo_newyear_en_1080x1920',
    type: 'video',
    packageNumber: 'MP-20260120-0001',
    packageName: 'Bingo Bonus 新年活动素材包',
    creatorName: '张设计',
    createdAt: '2026-01-20',
    lastUpdated: '2026-01-27 10:30',
  };

  const formatNumber = (num: number) => {
    return num.toLocaleString('en-US');
  };

  const exportData = () => {
    console.log('导出数据');
  };

  return (
    <div className="space-y-4">
      {/* 返回按钮 */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 text-sm"
      >
        <ArrowLeft className="w-4 h-4" />
        返回素材库
      </button>

      {/* 素材信息卡片 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-4">
            <div className="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center">
              <Play className="w-12 h-12 text-gray-400" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">{materialInfo.name}</h2>
              <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-sm text-gray-600">
                <div>所属素材包：<span className="text-blue-600">{materialInfo.packageNumber}</span></div>
                <div>创建人：{materialInfo.creatorName}</div>
                <div>素材包名称：{materialInfo.packageName}</div>
                <div>创建时间：{materialInfo.createdAt}</div>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs text-gray-500 mb-1">数据更新时间</div>
            <div className="text-sm text-gray-700">{materialInfo.lastUpdated}</div>
          </div>
        </div>
      </div>

      {/* 筛选和操作栏 */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          {/* 维度切换 */}
          <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg p-1">
            <button
              onClick={() => setViewMode('channel')}
              className={cn(
                'px-4 py-1.5 rounded text-sm transition-colors',
                viewMode === 'channel'
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              )}
            >
              按渠道
            </button>
            <button
              onClick={() => setViewMode('country')}
              className={cn(
                'px-4 py-1.5 rounded text-sm transition-colors',
                viewMode === 'country'
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              )}
            >
              按国家
            </button>
          </div>

          {/* 时间范围 */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">时间范围：</span>
            {(['7d', '30d', 'all'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={cn(
                  'px-3 py-1 rounded text-sm',
                  timeRange === range
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                )}
              >
                {range === '7d' ? '近7天' : range === '30d' ? '近30天' : '全部'}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={exportData}
          className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50"
        >
          <Download className="w-4 h-4" />
          导出数据
        </button>
      </div>

      {/* 数据表格 */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="px-4 py-3 text-left font-medium text-gray-900">
                  {viewMode === 'channel' ? '渠��' : '国家'}
                </th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">花费($)</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">展示(IM)</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">点击(CLK)</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">CTR(%)</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">CVR(%)</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">IPM</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">CPM</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">安装</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">次留(%)</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">七留(%)</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">30日留(%)</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">付费</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">ROI</th>
                <th className="px-4 py-3 text-right font-medium text-gray-900">质量分</th>
              </tr>
            </thead>
            <tbody>
              {viewMode === 'channel' 
                ? mockChannelData.map((row, index) => (
                    <tr
                      key={row.channel}
                      className={cn(
                        'border-b border-gray-100',
                        index % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'
                      )}
                    >
                      <td className="px-4 py-3 text-gray-900 font-medium">{row.channel}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.cost.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{(row.impressions / 1000000).toFixed(2)}M</td>
                      <td className="px-4 py-3 text-right text-gray-900">{formatNumber(row.clicks)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.ctr.toFixed(2)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.cvr.toFixed(2)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.ipm}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.cpm.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{formatNumber(row.installs)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.d2Retention.toFixed(1)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.d7Retention.toFixed(1)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.d30Retention.toFixed(1)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{formatNumber(row.paying)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.roi.toFixed(1)}</td>
                      <td className="px-4 py-3 text-right">
                        <span className={cn(
                          'font-medium',
                          row.qualityScore >= 85 ? 'text-green-600' : 
                          row.qualityScore >= 70 ? 'text-yellow-600' : 
                          'text-red-600'
                        )}>
                          {row.qualityScore}
                        </span>
                      </td>
                    </tr>
                  ))
                : mockCountryData.map((row, index) => (
                    <tr
                      key={row.country}
                      className={cn(
                        'border-b border-gray-100',
                        index % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'
                      )}
                    >
                      <td className="px-4 py-3 text-gray-900 font-medium">{row.country}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.cost.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{(row.impressions / 1000000).toFixed(2)}M</td>
                      <td className="px-4 py-3 text-right text-gray-900">{formatNumber(row.clicks)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.ctr.toFixed(2)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.cvr.toFixed(2)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.ipm}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.cpm.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{formatNumber(row.installs)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.d2Retention.toFixed(1)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.d7Retention.toFixed(1)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.d30Retention.toFixed(1)}%</td>
                      <td className="px-4 py-3 text-right text-gray-900">{formatNumber(row.paying)}</td>
                      <td className="px-4 py-3 text-right text-gray-900">{row.roi.toFixed(1)}</td>
                      <td className="px-4 py-3 text-right">
                        <span className={cn(
                          'font-medium',
                          row.qualityScore >= 85 ? 'text-green-600' : 
                          row.qualityScore >= 70 ? 'text-yellow-600' : 
                          'text-red-600'
                        )}>
                          {row.qualityScore}
                        </span>
                      </td>
                    </tr>
                  ))
              }
            </tbody>
          </table>
        </div>
      </div>

      {/* 数据说明 */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="text-sm font-medium text-blue-900 mb-2">数据指标说明</h4>
        <div className="grid grid-cols-3 gap-4 text-xs text-blue-800">
          <div><strong>CTR</strong>: 点击率 = (点击数 / 展示数) × 100%</div>
          <div><strong>CVR</strong>: 转化率 = (安装数 / 点击数) × 100%</div>
          <div><strong>IPM</strong>: 千次展示安装数</div>
          <div><strong>CPM</strong>: 千次展示成本</div>
          <div><strong>次留</strong>: 次日留存率</div>
          <div><strong>七留</strong>: 七日留存率</div>
          <div><strong>30日留</strong>: 30日留存率</div>
          <div><strong>ROI</strong>: 投资回报率</div>
          <div><strong>质量分</strong>: 综合评分 (0-100)</div>
        </div>
      </div>
    </div>
  );
}
