import { useState } from 'react';
import { RotateCcw, CalendarIcon, ArrowUpDown, ArrowUp, ArrowDown, FileVideo, FileImage, FileCode } from 'lucide-react';
import { cn } from './ui/utils';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { Calendar } from './ui/calendar';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

// 设计师看板筛选条件接口
export interface DesignerDashboardFilters {
  dateFrom?: Date;
  dateTo?: Date;
  packageNameQuery: string;
  packageNumberQuery: string;
  productFilter: string;
  productionTypeFilter: string;
  networkFilter: string;
  countryFilter: string;
  creatorFilter: string;
  creativePersonFilter: string;
  materialTypeFilter: string;
}

// 素材包数据类型（设计师看板）
interface DesignerPackageData {
  id: string;
  packageNumber: string;
  packageName: string;
  product: string;
  productionType: '0-1制作' | '1-N制作';
  materialCount: number;
  videoCount: number;
  imageCount: number;
  html5Count: number;
  creator: string;
  creativePerson: string;
  // 投放数据指标
  act: number;           // 激活数
  d0Roi: number;         // D0 ROI
  retention2: number;    // 激活次留
  retention7: number;    // 激活7留
  retention14: number;   // 激活14留
}

// Mock 数据
const mockDesignerPackages: DesignerPackageData[] = [
  {
    id: '1',
    packageNumber: 'MP-20260120-0001',
    packageName: 'Bingo Bonus 新年活动素材包',
    product: 'Bingo Bonus',
    productionType: '0-1制作',
    materialCount: 8,
    videoCount: 3,
    imageCount: 4,
    html5Count: 1,
    creator: '张设计',
    creativePerson: '张设计',
    act: 12580,
    d0Roi: 1.85,
    retention2: 45.2,
    retention7: 28.5,
    retention14: 18.3,
  },
  {
    id: '2',
    packageNumber: 'MP-20260118-0002',
    packageName: 'Yazzy GO! 海外推广包',
    product: 'Yazzy GO!',
    productionType: '1-N制作',
    materialCount: 12,
    videoCount: 5,
    imageCount: 6,
    html5Count: 1,
    creator: '李设计',
    creativePerson: '李设计',
    act: 18920,
    d0Roi: 2.15,
    retention2: 52.8,
    retention7: 35.6,
    retention14: 22.1,
  },
  {
    id: '3',
    packageNumber: 'MP-20260115-0003',
    packageName: 'Fishberry Story 情人节素材',
    product: 'Fishberry Story',
    productionType: '0-1制作',
    materialCount: 6,
    videoCount: 2,
    imageCount: 3,
    html5Count: 1,
    creator: '王设计',
    creativePerson: '王设计',
    act: 8650,
    d0Roi: 1.42,
    retention2: 38.6,
    retention7: 24.2,
    retention14: 15.8,
  },
];

interface DesignerDashboardPageProps {
  onNavigateToPackageDetail: (packageId: string, filters: DesignerDashboardFilters) => void;
}

export function DesignerDashboardPage({ onNavigateToPackageDetail }: DesignerDashboardPageProps) {
  // 筛选条件
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  const [packageNameQuery, setPackageNameQuery] = useState('');
  const [packageNumberQuery, setPackageNumberQuery] = useState('');
  const [productFilter, setProductFilter] = useState<string>('all');
  const [productionTypeFilter, setProductionTypeFilter] = useState<string>('all');
  const [networkFilter, setNetworkFilter] = useState<string>('all');
  const [countryFilter, setCountryFilter] = useState<string>('all');
  const [creatorFilter, setCreatorFilter] = useState<string>('all');
  const [creativePersonFilter, setCreativePersonFilter] = useState<string>('all');
  const [materialTypeFilter, setMaterialTypeFilter] = useState<string>('all');

  // 已应用的筛选条件
  const [appliedFilters, setAppliedFilters] = useState<DesignerDashboardFilters>({
    packageNameQuery: '',
    packageNumberQuery: '',
    productFilter: 'all',
    productionTypeFilter: 'all',
    networkFilter: 'all',
    countryFilter: 'all',
    creatorFilter: 'all',
    creativePersonFilter: 'all',
    materialTypeFilter: 'all',
  });

  // 分页
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // 排序状态
  type SortOrder = 'asc' | 'desc' | null;
  const [actSort, setActSort] = useState<SortOrder>(null);
  const [d0RoiSort, setD0RoiSort] = useState<SortOrder>(null);
  const [retention2Sort, setRetention2Sort] = useState<SortOrder>(null);
  const [retention7Sort, setRetention7Sort] = useState<SortOrder>(null);
  const [retention14Sort, setRetention14Sort] = useState<SortOrder>(null);

  // 获取所有产品
  const allProducts = Array.from(new Set(mockDesignerPackages.map(pkg => pkg.product)));
  const allCreators = Array.from(new Set(mockDesignerPackages.map(pkg => pkg.creator)));
  const allCreativePersons = Array.from(new Set(mockDesignerPackages.map(pkg => pkg.creativePerson)));

  // 筛选和排序逻辑
  const filteredPackages = (() => {
    let result = mockDesignerPackages.filter(pkg => {
      if (appliedFilters.packageNameQuery) {
        if (!pkg.packageName.toLowerCase().includes(appliedFilters.packageNameQuery.toLowerCase())) return false;
      }
      if (appliedFilters.packageNumberQuery) {
        if (!pkg.packageNumber.toLowerCase().includes(appliedFilters.packageNumberQuery.toLowerCase())) return false;
      }
      if (appliedFilters.productFilter !== 'all') {
        if (pkg.product !== appliedFilters.productFilter) return false;
      }
      if (appliedFilters.productionTypeFilter !== 'all') {
        if (pkg.productionType !== appliedFilters.productionTypeFilter) return false;
      }
      if (appliedFilters.creatorFilter !== 'all') {
        if (pkg.creator !== appliedFilters.creatorFilter) return false;
      }
      if (appliedFilters.creativePersonFilter !== 'all') {
        if (pkg.creativePerson !== appliedFilters.creativePersonFilter) return false;
      }
      return true;
    });

    // 应用排序
    if (actSort) {
      result.sort((a, b) => actSort === 'asc' ? a.act - b.act : b.act - a.act);
    } else if (d0RoiSort) {
      result.sort((a, b) => d0RoiSort === 'asc' ? a.d0Roi - b.d0Roi : b.d0Roi - a.d0Roi);
    } else if (retention2Sort) {
      result.sort((a, b) => retention2Sort === 'asc' ? a.retention2 - b.retention2 : b.retention2 - a.retention2);
    } else if (retention7Sort) {
      result.sort((a, b) => retention7Sort === 'asc' ? a.retention7 - b.retention7 : b.retention7 - a.retention7);
    } else if (retention14Sort) {
      result.sort((a, b) => retention14Sort === 'asc' ? a.retention14 - b.retention14 : b.retention14 - a.retention14);
    }

    return result;
  })();

  // 分页
  const totalPages = Math.ceil(filteredPackages.length / itemsPerPage);
  const paginatedPackages = filteredPackages.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleQuery = () => {
    setAppliedFilters({
      dateFrom,
      dateTo,
      packageNameQuery,
      packageNumberQuery,
      productFilter,
      productionTypeFilter,
      networkFilter,
      countryFilter,
      creatorFilter,
      creativePersonFilter,
      materialTypeFilter,
    });
    setCurrentPage(1);
    toast.success('查询完成');
  };

  const handleResetFilters = () => {
    setDateFrom(undefined);
    setDateTo(undefined);
    setPackageNameQuery('');
    setPackageNumberQuery('');
    setProductFilter('all');
    setProductionTypeFilter('all');
    setNetworkFilter('all');
    setCountryFilter('all');
    setCreatorFilter('all');
    setCreativePersonFilter('all');
    setMaterialTypeFilter('all');
    setAppliedFilters({
      packageNameQuery: '',
      packageNumberQuery: '',
      productFilter: 'all',
      productionTypeFilter: 'all',
      networkFilter: 'all',
      countryFilter: 'all',
      creatorFilter: 'all',
      creativePersonFilter: 'all',
      materialTypeFilter: 'all',
    });
    setCurrentPage(1);
    toast.success('筛选条件已重置');
  };

  const handleRowClick = (packageId: string) => {
    onNavigateToPackageDetail(packageId, appliedFilters);
  };

  const renderFilters = () => (
    <div className="space-y-6">
      {/* 第一行 */}
      <div className="grid grid-cols-4 gap-4">
        <div>
          <label className="text-sm text-gray-600 mb-1 block">日期</label>
          <div className="grid grid-cols-2 gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn('w-full justify-start text-left text-sm', !dateFrom && 'text-gray-400')}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateFrom ? format(dateFrom, 'yyyy-MM-dd') : '开始'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} locale={zhCN} />
              </PopoverContent>
            </Popover>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn('w-full justify-start text-left text-sm', !dateTo && 'text-gray-400')}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateTo ? format(dateTo, 'yyyy-MM-dd') : '结束'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={dateTo} onSelect={setDateTo} locale={zhCN} />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">素材包名称</label>
          <Input placeholder="请输入" value={packageNameQuery} onChange={(e) => setPackageNameQuery(e.target.value)} />
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">应用</label>
          <Select value={productFilter} onValueChange={setProductFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allProducts.map((product) => (
                <SelectItem key={product} value={product}>{product}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">network</label>
          <Select value={networkFilter} onValueChange={setNetworkFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="facebook">Facebook</SelectItem>
              <SelectItem value="google">Google Ads</SelectItem>
              <SelectItem value="tiktok">TikTok</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* 第二行 */}
      <div className="grid grid-cols-4 gap-4">
        <div>
          <label className="text-sm text-gray-600 mb-1 block">国家</label>
          <Select value={countryFilter} onValueChange={setCountryFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="US">美国</SelectItem>
              <SelectItem value="UK">英国</SelectItem>
              <SelectItem value="JP">日本</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">制作类型</label>
          <Select value={productionTypeFilter} onValueChange={setProductionTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="0-1制作">0-1制作</SelectItem>
              <SelectItem value="1-N制作">1-N制作</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">制作人</label>
          <Select value={creatorFilter} onValueChange={setCreatorFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allCreators.map((creator) => (
                <SelectItem key={creator} value={creator}>{creator}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">创意人</label>
          <Select value={creativePersonFilter} onValueChange={setCreativePersonFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allCreativePersons.map((person) => (
                <SelectItem key={person} value={person}>{person}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* 第三行 */}
      <div className="grid grid-cols-4 gap-4">
        <div>
          <label className="text-sm text-gray-600 mb-1 block">素材类型</label>
          <Select value={materialTypeFilter} onValueChange={setMaterialTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="video">视频</SelectItem>
              <SelectItem value="image">图片</SelectItem>
              <SelectItem value="html5">H5</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* 操作按钮 */}
      <div className="flex justify-end items-center">
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleResetFilters}>
            <RotateCcw className="mr-2 h-4 w-4" />
            重置
          </Button>
          <Button onClick={handleQuery}>查询</Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* 筛选条件 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        {renderFilters()}
      </div>

      {/* 表格 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-4">
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead>素材包编号</TableHead>
                  <TableHead>素材包名称</TableHead>
                  <TableHead>应用</TableHead>
                  <TableHead>制作类型</TableHead>
                  <TableHead className="text-center">素材数量</TableHead>
                  <TableHead>制作人</TableHead>
                  <TableHead>创意人</TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setActSort(actSort === 'asc' ? 'desc' : actSort === 'desc' ? null : 'asc');
                      setD0RoiSort(null);
                      setRetention2Sort(null);
                      setRetention7Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      Act
                      {actSort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {actSort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {actSort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setD0RoiSort(d0RoiSort === 'asc' ? 'desc' : d0RoiSort === 'desc' ? null : 'asc');
                      setActSort(null);
                      setRetention2Sort(null);
                      setRetention7Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      D0_ROI
                      {d0RoiSort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {d0RoiSort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {d0RoiSort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setRetention2Sort(retention2Sort === 'asc' ? 'desc' : retention2Sort === 'desc' ? null : 'asc');
                      setActSort(null);
                      setD0RoiSort(null);
                      setRetention7Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      激活次留(%)
                      {retention2Sort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {retention2Sort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {retention2Sort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setRetention7Sort(retention7Sort === 'asc' ? 'desc' : retention7Sort === 'desc' ? null : 'asc');
                      setActSort(null);
                      setD0RoiSort(null);
                      setRetention2Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      激活7留(%)
                      {retention7Sort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {retention7Sort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {retention7Sort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setRetention14Sort(retention14Sort === 'asc' ? 'desc' : retention14Sort === 'desc' ? null : 'asc');
                      setActSort(null);
                      setD0RoiSort(null);
                      setRetention2Sort(null);
                      setRetention7Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      激活14留(%)
                      {retention14Sort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {retention14Sort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {retention14Sort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedPackages.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={12} className="text-center py-12 text-gray-500">
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-4xl">📦</div>
                        <div>暂无数据</div>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedPackages.map((pkg) => (
                    <TableRow
                      key={pkg.id}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => handleRowClick(pkg.id)}
                    >
                      <TableCell className="text-blue-600 font-medium">{pkg.packageNumber}</TableCell>
                      <TableCell>{pkg.packageName}</TableCell>
                      <TableCell>{pkg.product}</TableCell>
                      <TableCell>{pkg.productionType}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-3">
                          <div className="flex items-center gap-1 text-xs">
                            <FileVideo className="w-3.5 h-3.5 text-purple-600" />
                            <span className="text-gray-700">{pkg.videoCount}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <FileImage className="w-3.5 h-3.5 text-blue-600" />
                            <span className="text-gray-700">{pkg.imageCount}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <FileCode className="w-3.5 h-3.5 text-green-600" />
                            <span className="text-gray-700">{pkg.html5Count}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{pkg.creator}</TableCell>
                      <TableCell>{pkg.creativePerson}</TableCell>
                      <TableCell className="text-right">{pkg.act.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{pkg.d0Roi.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{pkg.retention2.toFixed(1)}%</TableCell>
                      <TableCell className="text-right">{pkg.retention7.toFixed(1)}%</TableCell>
                      <TableCell className="text-right">{pkg.retention14.toFixed(1)}%</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* 分页 */}
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              第 {(currentPage - 1) * itemsPerPage + 1} - {Math.min(currentPage * itemsPerPage, filteredPackages.length)} 条，
              共 {filteredPackages.length} 条
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                上一页
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                下一页
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
