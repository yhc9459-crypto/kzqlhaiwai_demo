import { useState, useMemo } from 'react';
import { PushTask, TaskMaterialDetail } from '../types/material';
import { mockPushTasks, mockTaskMaterialDetails } from '../lib/mockData';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { toast } from 'sonner';
import { ArrowLeft, CheckCircle2, XCircle, Loader2, Clock, RefreshCw, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { getMaterialTypeName } from '../lib/xmpService';

interface TaskDetailPageProps {
  taskId: string;
  onBack: () => void;
}

export function TaskDetailPage({ taskId, onBack }: TaskDetailPageProps) {
  const [task, setTask] = useState<PushTask | undefined>(
    mockPushTasks.find((t) => t.id === taskId)
  );
  const [materialDetails, setMaterialDetails] = useState<TaskMaterialDetail[]>(
    mockTaskMaterialDetails.filter((d) => d.taskId === taskId)
  );

  if (!task) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="text-center py-12">
          <div className="text-4xl mb-4">❌</div>
          <div className="text-gray-600 mb-4">任务不存在</div>
          <Button onClick={onBack}>返回任务列表</Button>
        </div>
      </div>
    );
  }

  const getTaskProgress = () => {
    if (task.totalCount === 0) return 0;
    return Math.round(((task.successCount + task.failedCount) / task.totalCount) * 100);
  };

  const failedMaterials = useMemo(() => {
    return materialDetails.filter((d) => d.status === 'failed');
  }, [materialDetails]);

  // F4: 重新推送失败的素材
  const handleRetryFailed = async () => {
    if (failedMaterials.length === 0) {
      toast.error('没有失败的素材需要重新推送');
      return;
    }

    toast.info(`正在重新推送 ${failedMaterials.length} 条失败的素材...`);

    // 模拟重新推送
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // 更新状态
    setMaterialDetails((prev) =>
      prev.map((detail) => {
        if (detail.status === 'failed') {
          const success = Math.random() > 0.3;
          return {
            ...detail,
            status: success ? 'success' : 'failed',
            error: success ? undefined : '网络连接超时',
            xmpMaterialId: success ? `xmp_mat_${detail.materialId}` : undefined,
            xmpUserMaterialId: success ? `xmp_user_mat_${detail.materialId}` : undefined,
            pushedAt: success ? new Date().toISOString() : detail.pushedAt,
          };
        }
        return detail;
      })
    );

    // 更新任务统计
    const newSuccessCount = materialDetails.filter(
      (d) => d.status === 'success' || (d.status === 'failed' && Math.random() > 0.3)
    ).length;
    const newFailedCount = task.totalCount - newSuccessCount;

    setTask({
      ...task,
      successCount: newSuccessCount,
      failedCount: newFailedCount,
      pendingCount: 0,
      status: newFailedCount === 0 ? 'completed' : 'completed',
    });

    toast.success('重新推送完成');
  };

  // F4: 重新推送单个素材
  const handleRetrySingle = async (detail: TaskMaterialDetail) => {
    toast.info(`正在重新推送: ${detail.materialName}`);

    // 更新状态为处理中
    setMaterialDetails((prev) =>
      prev.map((d) =>
        d.id === detail.id
          ? { ...d, status: 'processing' as const }
          : d
      )
    );

    // 模拟推送
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const success = Math.random() > 0.3;

    setMaterialDetails((prev) =>
      prev.map((d) => {
        if (d.id === detail.id) {
          if (success) {
            toast.success(`${detail.materialName} 推送成功`);
            return {
              ...d,
              status: 'success' as const,
              error: undefined,
              xmpMaterialId: `xmp_mat_${detail.materialId}`,
              xmpUserMaterialId: `xmp_user_mat_${detail.materialId}`,
              pushedAt: new Date().toISOString(),
            };
          } else {
            toast.error(`${detail.materialName} 推送失败`);
            return {
              ...d,
              status: 'failed' as const,
              error: '网络连接超时',
            };
          }
        }
        return d;
      })
    );

    // 更新任务统计
    if (success) {
      setTask({
        ...task,
        successCount: task.successCount + 1,
        failedCount: task.failedCount - 1,
      });
    }
  };

  const getDetailStatusBadge = (detail: TaskMaterialDetail) => {
    switch (detail.status) {
      case 'success':
        return (
          <Badge className="bg-green-600">
            <CheckCircle2 className="mr-1 h-3 w-3" />
            成功
          </Badge>
        );
      case 'failed':
        return (
          <Badge variant="destructive">
            <XCircle className="mr-1 h-3 w-3" />
            失败
          </Badge>
        );
      case 'processing':
        return (
          <Badge className="bg-blue-600">
            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
            处理中
          </Badge>
        );
      case 'pending':
        return (
          <Badge variant="secondary">
            <Clock className="mr-1 h-3 w-3" />
            待处理
          </Badge>
        );
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="mb-6">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              返回
            </Button>
            <h2 className="text-lg font-medium">任务详情</h2>
          </div>

          {/* Task Summary */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="border rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">任务ID</div>
              <div className="font-mono text-sm">{task.id}</div>
            </div>
            <div className="border rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">产品</div>
              <div className="font-medium">{task.productName}</div>
            </div>
            <div className="border rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">素材类型</div>
              <div>
                <Badge variant="outline">{getMaterialTypeName(task.materialType)}</Badge>
              </div>
            </div>
            <div className="border rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">创建人</div>
              <div className="font-medium">{task.createdBy}</div>
            </div>
          </div>

          {/* F3: 任务状态统计 */}
          <div className="grid grid-cols-5 gap-4 mb-6">
            <div className="border rounded-lg p-4 bg-gray-50">
              <div className="text-sm text-gray-600 mb-1">总数</div>
              <div className="text-2xl font-bold">{task.totalCount}</div>
            </div>
            <div className="border rounded-lg p-4 bg-green-50">
              <div className="text-sm text-gray-600 mb-1">成功数</div>
              <div className="text-2xl font-bold text-green-600">{task.successCount}</div>
            </div>
            <div className="border rounded-lg p-4 bg-red-50">
              <div className="text-sm text-gray-600 mb-1">失败数</div>
              <div className="text-2xl font-bold text-red-600">{task.failedCount}</div>
            </div>
            <div className="border rounded-lg p-4 bg-blue-50">
              <div className="text-sm text-gray-600 mb-1">待处理数</div>
              <div className="text-2xl font-bold text-blue-600">{task.pendingCount}</div>
            </div>
            <div className="border rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">任务进度</div>
              <div className="space-y-1">
                <Progress value={getTaskProgress()} className="h-2" />
                <div className="text-sm font-medium">{getTaskProgress()}%</div>
              </div>
            </div>
          </div>

          {/* F4: 失败素材重试提示 */}
          {failedMaterials.length > 0 && (
            <Alert className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="flex items-center justify-between">
                <span>
                  检测到 {failedMaterials.length} 条素材推送失败，您可以重新推送这些素材
                </span>
                <Button size="sm" onClick={handleRetryFailed}>
                  <RefreshCw className="mr-2 h-3 w-3" />
                  批量重新推送失败素材
                </Button>
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* F3: 素材明细列表 */}
        <div className="border border-gray-200 rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>素材名称</TableHead>
                <TableHead>状态</TableHead>
                <TableHead>XMP素材ID</TableHead>
                <TableHead>推送时间</TableHead>
                <TableHead>错误信息</TableHead>
                <TableHead className="w-24">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {materialDetails.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-gray-500">
                    <div className="flex flex-col items-center gap-2">
                      <div className="text-4xl">📦</div>
                      <div>暂无素材明细</div>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                materialDetails.map((detail) => (
                  <TableRow key={detail.id} className="hover:bg-gray-50">
                    <TableCell>{detail.materialName}</TableCell>
                    <TableCell>{getDetailStatusBadge(detail)}</TableCell>
                    <TableCell>
                      {detail.xmpMaterialId ? (
                        <div className="text-xs text-gray-600 space-y-1">
                          <div>素材: {detail.xmpMaterialId}</div>
                          {detail.xmpUserMaterialId && (
                            <div>用户: {detail.xmpUserMaterialId}</div>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {detail.pushedAt ? (
                        <span className="text-sm text-gray-600">
                          {format(new Date(detail.pushedAt), 'yyyy-MM-dd HH:mm:ss', {
                            locale: zhCN,
                          })}
                        </span>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {detail.error ? (
                        <span className="text-sm text-red-600">{detail.error}</span>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {/* F4: 单个素材重新推送按钮 */}
                      {detail.status === 'failed' && (
                        <Button
                          size="sm"
                          variant="link"
                          onClick={() => handleRetrySingle(detail)}
                          className="h-auto p-0"
                        >
                          <RefreshCw className="mr-1 h-3 w-3" />
                          重试
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
