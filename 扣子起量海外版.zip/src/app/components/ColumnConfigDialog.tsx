import { useState, useRef } from 'react';
import { X, GripVertical, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Checkbox } from './ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import type { Identifier, XYCoord } from 'dnd-core';

interface ColumnDef {
  id: string;
  name: string;
  description: string;
  type: 'dimension' | 'atomic' | 'composite' | 'derived';
  formula?: string;
  category: string;
}

interface ColumnConfig {
  id: string;
  visible: boolean;
  order: number;
}

interface ColumnConfigDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  columnDefs: ColumnDef[];
  columnConfigs: ColumnConfig[];
  onSave: (configs: ColumnConfig[]) => void;
}

interface DragItem {
  id: string;
  index: number;
}

function DraggableSelectedItem({
  column,
  index,
  columnDef,
  onRemove,
  moveItem,
}: {
  column: ColumnConfig;
  index: number;
  columnDef: ColumnDef;
  onRemove: (id: string) => void;
  moveItem: (dragIndex: number, hoverIndex: number) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);

  const [{ handlerId }, drop] = useDrop<
    DragItem,
    void,
    { handlerId: Identifier | null }
  >({
    accept: 'selected-column',
    collect(monitor) {
      return {
        handlerId: monitor.getHandlerId(),
      };
    },
    hover(item: DragItem, monitor) {
      if (!ref.current) {
        return;
      }
      const dragIndex = item.index;
      const hoverIndex = index;

      if (dragIndex === hoverIndex) {
        return;
      }

      const hoverBoundingRect = ref.current?.getBoundingClientRect();
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
      const clientOffset = monitor.getClientOffset();
      const hoverClientY = (clientOffset as XYCoord).y - hoverBoundingRect.top;

      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }

      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }

      moveItem(dragIndex, hoverIndex);
      item.index = hoverIndex;
    },
  });

  const [{ isDragging }, drag, preview] = useDrag({
    type: 'selected-column',
    item: () => {
      return { id: column.id, index };
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  drag(drop(ref));

  return (
    <div
      ref={ref}
      data-handler-id={handlerId}
      className={`flex items-center justify-between gap-2 px-3 py-2 bg-white border border-gray-200 rounded hover:bg-gray-50 cursor-move ${
        isDragging ? 'opacity-50' : 'opacity-100'
      }`}
    >
      <div className="flex items-center gap-2 flex-1 min-w-0">
        <GripVertical className="h-4 w-4 text-gray-400 flex-shrink-0" />
        <span className="text-sm truncate">{columnDef.name}</span>
      </div>
      <button
        onClick={() => onRemove(column.id)}
        className="text-gray-400 hover:text-gray-600 flex-shrink-0"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

function ColumnConfigDialogContent({
  columnDefs,
  columnConfigs: initialConfigs,
  onSave,
  onCancel,
}: {
  columnDefs: ColumnDef[];
  columnConfigs: ColumnConfig[];
  onSave: (configs: ColumnConfig[]) => void;
  onCancel: () => void;
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [tempConfigs, setTempConfigs] = useState<ColumnConfig[]>(initialConfigs);

  // 获取选中的列
  const selectedColumns = tempConfigs
    .filter(c => c.visible)
    .sort((a, b) => a.order - b.order);

  // 按类别分组的列
  const groupedColumns = columnDefs.reduce((acc, def) => {
    if (!acc[def.category]) {
      acc[def.category] = [];
    }
    acc[def.category].push(def);
    return acc;
  }, {} as Record<string, ColumnDef[]>);

  // 筛选后的列
  const filteredGroupedColumns = Object.entries(groupedColumns).reduce((acc, [category, columns]) => {
    const filtered = columns.filter(col =>
      col.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      col.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
    if (filtered.length > 0) {
      acc[category] = filtered;
    }
    return acc;
  }, {} as Record<string, ColumnDef[]>);

  // 切换列的可见性
  const toggleColumn = (columnId: string) => {
    setTempConfigs(prev => {
      const config = prev.find(c => c.id === columnId);
      if (!config) return prev;

      if (config.visible) {
        // 取消选中
        return prev.map(c =>
          c.id === columnId ? { ...c, visible: false } : c
        );
      } else {
        // 选中 - 添加到末尾
        const maxOrder = Math.max(...prev.filter(c => c.visible).map(c => c.order), -1);
        return prev.map(c =>
          c.id === columnId ? { ...c, visible: true, order: maxOrder + 1 } : c
        );
      }
    });
  };

  // 移除选中的列
  const removeColumn = (columnId: string) => {
    setTempConfigs(prev => {
      const removedConfig = prev.find(c => c.id === columnId);
      if (!removedConfig) return prev;

      // 取消选中并重新排序
      return prev.map(c => {
        if (c.id === columnId) {
          return { ...c, visible: false };
        }
        if (c.visible && c.order > removedConfig.order) {
          return { ...c, order: c.order - 1 };
        }
        return c;
      });
    });
  };

  // 移动选中的列
  const moveSelectedItem = (dragIndex: number, hoverIndex: number) => {
    setTempConfigs(prev => {
      const selected = prev.filter(c => c.visible).sort((a, b) => a.order - b.order);
      const dragItem = selected[dragIndex];
      const hoverItem = selected[hoverIndex];

      if (!dragItem || !hoverItem) return prev;

      return prev.map(c => {
        if (c.id === dragItem.id) {
          return { ...c, order: hoverItem.order };
        }
        if (c.id === hoverItem.id) {
          return { ...c, order: dragItem.order };
        }
        return c;
      });
    });
  };

  // 清空所有选中
  const clearAll = () => {
    setTempConfigs(prev => prev.map(c => ({ ...c, visible: false })));
  };

  // 全选某个分组
  const selectAllInCategory = (category: string) => {
    const categoryColumns = groupedColumns[category] || [];
    setTempConfigs(prev => {
      const maxOrder = Math.max(...prev.filter(c => c.visible).map(c => c.order), -1);
      let nextOrder = maxOrder + 1;

      return prev.map(c => {
        const isInCategory = categoryColumns.some(col => col.id === c.id);
        if (isInCategory && !c.visible) {
          return { ...c, visible: true, order: nextOrder++ };
        }
        return c;
      });
    });
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex flex-1 gap-4 min-h-0">
        {/* 左侧：可选列 */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="mb-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="请输入列名搜索"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto pr-2 space-y-4">
            {Object.entries(filteredGroupedColumns).map(([category, columns]) => (
              <div key={category}>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-gray-700">{category}</h3>
                  <button
                    onClick={() => selectAllInCategory(category)}
                    className="text-xs text-blue-600 hover:text-blue-700"
                  >
                    全选
                  </button>
                </div>
                <div className="space-y-1">
                  {columns.map(col => {
                    const config = tempConfigs.find(c => c.id === col.id);
                    const isSelected = config?.visible || false;

                    return (
                      <div
                        key={col.id}
                        className={`flex items-start gap-2 p-2 rounded cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-blue-50 border border-blue-200'
                            : 'hover:bg-gray-50'
                        }`}
                        onClick={() => toggleColumn(col.id)}
                      >
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleColumn(col.id)}
                          onClick={(e) => e.stopPropagation()}
                          className="mt-0.5"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium">{col.name}</div>
                          <div className="text-xs text-gray-500">
                            {col.description}
                            {col.formula && (
                              <span className="ml-1 text-blue-600">({col.formula})</span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 右侧：已选列 */}
        <div className="w-64 flex flex-col border-l border-gray-200 pl-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium">
              已选择 <span className="text-blue-600">{selectedColumns.length}</span> 列
            </h3>
            {selectedColumns.length > 0 && (
              <button
                onClick={clearAll}
                className="text-xs text-blue-600 hover:text-blue-700"
              >
                清除
              </button>
            )}
          </div>

          {selectedColumns.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-gray-400 text-sm">
              拖动到上方的时候删除显示
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto space-y-2">
              {selectedColumns.map((config, index) => {
                const def = columnDefs.find(d => d.id === config.id);
                if (!def) return null;

                return (
                  <DraggableSelectedItem
                    key={config.id}
                    column={config}
                    index={index}
                    columnDef={def}
                    onRemove={removeColumn}
                    moveItem={moveSelectedItem}
                  />
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4 border-t border-gray-200 mt-4">
        <Button variant="outline" onClick={onCancel}>
          取消
        </Button>
        <Button onClick={() => onSave(tempConfigs)}>确定</Button>
      </div>
    </div>
  );
}

export function ColumnConfigDialog({
  open,
  onOpenChange,
  columnDefs,
  columnConfigs,
  onSave,
}: ColumnConfigDialogProps) {
  const handleSave = (configs: ColumnConfig[]) => {
    onSave(configs);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-4xl h-[80vh] flex flex-col"
        aria-describedby={undefined}
      >
        <DialogHeader>
          <DialogTitle>指标设置</DialogTitle>
        </DialogHeader>

        <div className="flex-1 min-h-0">
          <DndProvider backend={HTML5Backend}>
            <ColumnConfigDialogContent
              columnDefs={columnDefs}
              columnConfigs={columnConfigs}
              onSave={handleSave}
              onCancel={() => onOpenChange(false)}
            />
          </DndProvider>
        </div>
      </DialogContent>
    </Dialog>
  );
}
