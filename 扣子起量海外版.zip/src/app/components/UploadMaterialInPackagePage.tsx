import { useState } from 'react';
import { ArrowLeft, Upload, X, FileVideo, FileImage, FileCode } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { toast } from 'sonner';
import { cn } from './ui/utils';

interface MaterialFile {
  id: string;
  file: File;
  name: string;
  type: 'video' | 'image' | 'html5';
  size: string;
  thumbnail?: string; // 缩略图URL
}

interface UploadMaterialInPackagePageProps {
  packageId: string;
  packageName: string;
  onBack: () => void;
  onSuccess: () => void;
}

export function UploadMaterialInPackagePage({
  packageId,
  packageName,
  onBack,
  onSuccess,
}: UploadMaterialInPackagePageProps) {
  const [materials, setMaterials] = useState<MaterialFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  // 处理文件选择
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>, type: 'video' | 'image' | 'html5') => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newMaterialsPromises = Array.from(files).map(async (file, index) => {
      const thumbnail = await generateThumbnail(file, type);
      return {
        id: `${Date.now()}-${index}`,
        file,
        name: file.name.replace(/\.[^/.]+$/, ''), // 去除扩展名
        type,
        size: formatFileSize(file.size),
        thumbnail,
      };
    });

    const newMaterials = await Promise.all(newMaterialsPromises);
    setMaterials([...materials, ...newMaterials]);
    e.target.value = ''; // 清空input，允许再次选择相同文件
  };

  // 生成缩略图
  const generateThumbnail = (file: File, type: 'video' | 'image' | 'html5'): Promise<string | undefined> => {
    return new Promise((resolve) => {
      if (type === 'image') {
        // 图片直接使用URL
        const url = URL.createObjectURL(file);
        resolve(url);
      } else if (type === 'video') {
        // 视频生成第一帧缩略图
        const video = document.createElement('video');
        video.preload = 'metadata';
        video.muted = true;
        
        video.onloadeddata = () => {
          video.currentTime = 1; // 取第1秒的帧
        };
        
        video.onseeked = () => {
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const thumbnail = canvas.toDataURL('image/jpeg', 0.7);
            URL.revokeObjectURL(video.src);
            resolve(thumbnail);
          } else {
            resolve(undefined);
          }
        };
        
        video.onerror = () => {
          resolve(undefined);
        };
        
        video.src = URL.createObjectURL(file);
      } else {
        // H5文件没有缩略图
        resolve(undefined);
      }
    });
  };

  // 格式化文件大小
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  // 删除素材
  const handleRemoveMaterial = (id: string) => {
    setMaterials(materials.filter(m => m.id !== id));
  };

  // 更新素材信息
  const handleUpdateMaterial = (id: string, field: keyof MaterialFile, value: any) => {
    setMaterials(materials.map(m => 
      m.id === id ? { ...m, [field]: value } : m
    ));
  };

  // 获取类型图标
  const getTypeIcon = (type: 'video' | 'image' | 'html5') => {
    switch (type) {
      case 'video':
        return <FileVideo className="w-5 h-5 text-purple-600" />;
      case 'image':
        return <FileImage className="w-5 h-5 text-blue-600" />;
      case 'html5':
        return <FileCode className="w-5 h-5 text-green-600" />;
    }
  };

  // 获取类型标签
  const getTypeLabel = (type: 'video' | 'image' | 'html5') => {
    switch (type) {
      case 'video':
        return '视频';
      case 'image':
        return '图片';
      case 'html5':
        return 'H5试玩';
    }
  };

  // 提交上传
  const handleSubmit = async () => {
    if (materials.length === 0) {
      toast.error('请至少选择一个文件');
      return;
    }

    // 验证所有素材名称都已填写
    const hasEmptyName = materials.some(m => !m.name.trim());
    if (hasEmptyName) {
      toast.error('请为所有素材填写名称');
      return;
    }

    setIsUploading(true);

    // 模拟上传
    setTimeout(() => {
      setIsUploading(false);
      toast.success(`成功上传 ${materials.length} 个素材到素材包`);
      onSuccess();
    }, 2000);
  };

  return (
    <div className="space-y-4">
      {/* 返回按钮 */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 text-sm"
      >
        <ArrowLeft className="w-4 h-4" />
        返回素材包详情
      </button>

      {/* 页面标题 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
            <Upload className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">上传素材到素材包</h2>
            <p className="text-sm text-gray-600">素材包：{packageName}</p>
            <p className="text-xs text-blue-600 mt-1">
              该素材包的产品、生产类型、创意人和素材标签已在创建时设置，上传的素材将自动应用这些属性
            </p>
          </div>
        </div>
      </div>

      {/* 上传按钮区域 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-sm font-medium text-gray-900 mb-4">选择素材文件</h3>
        <div className="grid grid-cols-3 gap-4">
          {/* 上传视频 */}
          <label className="cursor-pointer">
            <input
              type="file"
              accept="video/*"
              multiple
              className="hidden"
              onChange={(e) => handleFileSelect(e, 'video')}
            />
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-purple-500 hover:bg-purple-50 transition-colors">
              <div className="flex flex-col items-center gap-2">
                <FileVideo className="w-8 h-8 text-purple-600" />
                <span className="text-sm font-medium text-gray-900">上传视频</span>
                <span className="text-xs text-gray-500">支持 MP4, MOV</span>
              </div>
            </div>
          </label>

          {/* 上传图片 */}
          <label className="cursor-pointer">
            <input
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => handleFileSelect(e, 'image')}
            />
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-blue-500 hover:bg-blue-50 transition-colors">
              <div className="flex flex-col items-center gap-2">
                <FileImage className="w-8 h-8 text-blue-600" />
                <span className="text-sm font-medium text-gray-900">上传图片</span>
                <span className="text-xs text-gray-500">支持 JPG, PNG</span>
              </div>
            </div>
          </label>

          {/* 上传H5 */}
          <label className="cursor-pointer">
            <input
              type="file"
              accept=".html,.zip"
              multiple
              className="hidden"
              onChange={(e) => handleFileSelect(e, 'html5')}
            />
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-green-500 hover:bg-green-50 transition-colors">
              <div className="flex flex-col items-center gap-2">
                <FileCode className="w-8 h-8 text-green-600" />
                <span className="text-sm font-medium text-gray-900">上传H5</span>
                <span className="text-xs text-gray-500">支持 HTML, ZIP</span>
              </div>
            </div>
          </label>
        </div>
      </div>

      {/* 素材列表 */}
      {materials.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-900">
              待上传素材列表 ({materials.length})
            </h3>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setMaterials([])}
            >
              清空列表
            </Button>
          </div>

          <div className="space-y-3">
            {materials.map((material) => (
              <div
                key={material.id}
                className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors"
              >
                <div className="flex items-start gap-4">
                  {/* 缩略图 */}
                  <div className="flex-shrink-0">
                    {material.thumbnail ? (
                      <div className="w-24 h-24 rounded-lg overflow-hidden bg-gray-100">
                        <img
                          src={material.thumbnail}
                          alt={material.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-24 h-24 rounded-lg bg-gray-100 flex items-center justify-center">
                        {getTypeIcon(material.type)}
                      </div>
                    )}
                  </div>

                  {/* 文件信息 */}
                  <div className="flex-1 grid grid-cols-3 gap-4">
                    {/* 素材名称 */}
                    <div>
                      <label className="text-xs text-gray-600 mb-1 block">
                        素材名称 <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={material.name}
                        onChange={(e) => handleUpdateMaterial(material.id, 'name', e.target.value)}
                        placeholder="请输入素材名称"
                        className="h-8 text-sm"
                      />
                    </div>

                    {/* 素材类型 */}
                    <div>
                      <label className="text-xs text-gray-600 mb-1 block">
                        素材类型
                      </label>
                      <div className="h-8 flex items-center">
                        <span className={cn(
                          'px-2 py-1 rounded text-xs font-medium',
                          material.type === 'video' && 'bg-purple-100 text-purple-700',
                          material.type === 'image' && 'bg-blue-100 text-blue-700',
                          material.type === 'html5' && 'bg-green-100 text-green-700'
                        )}>
                          {getTypeLabel(material.type)}
                        </span>
                      </div>
                    </div>

                    {/* 文件大小 */}
                    <div>
                      <label className="text-xs text-gray-600 mb-1 block">
                        文件大小
                      </label>
                      <div className="h-8 flex items-center text-sm text-gray-700">
                        {material.size}
                      </div>
                    </div>
                  </div>

                  {/* 删除按钮 */}
                  <button
                    onClick={() => handleRemoveMaterial(material.id)}
                    className="flex-shrink-0 p-1 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 提交按钮 */}
      {materials.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              共 {materials.length} 个素材待上传
              <span className="ml-4">
                视频: {materials.filter(m => m.type === 'video').length} | 
                图片: {materials.filter(m => m.type === 'image').length} | 
                H5: {materials.filter(m => m.type === 'html5').length}
              </span>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={onBack}
                disabled={isUploading}
              >
                取消
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={isUploading}
              >
                {isUploading ? '上传中...' : '开始上传'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* 空状态提示 */}
      {materials.length === 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-12">
          <div className="text-center">
            <Upload className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              还没有选择任何文件
            </h3>
            <p className="text-sm text-gray-500">
              点击上方的上传按钮选择视频、图片或H5文件
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
