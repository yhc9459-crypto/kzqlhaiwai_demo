import { useState, useMemo } from "react";
import {
  Material,
  MaterialType,
  MaterialStatus,
  PushStatus,
} from "../types/material";
import { mockMaterials } from "../lib/mockData";
import { getMaterialTypeName } from "../lib/xmpService";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "./ui/popover";
import { Calendar } from "./ui/calendar";
import { toast } from "sonner";
import { MaterialTagSelector } from "./MaterialTagSelector";
import {
  CheckCircle2,
  XCircle,
  RotateCcw,
  Image as ImageIcon,
  Video,
  CalendarIcon,
  ChevronLeft,
  ChevronRight,
  PlayCircle,
  Pause,
  Ban,
  Upload,
  Edit,
  Send,
  X,
  Trash2,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
} from "lucide-react";
import { format } from "date-fns";
import { zhCN } from "date-fns/locale";
import { cn } from "./ui/utils";
import { Checkbox } from "./ui/checkbox";
import { MaterialTagsCell } from "./MaterialTagsCell";

// 素材标签选项
const MATERIAL_TAGS = [
  '原创',
  '纯剪辑/去logo',
  '拼接/混剪',
  '原创-片头',
  '改尺寸/语言',
  'H5试玩',
  'AI数字人',
  'AI生图',
];

interface MaterialLibraryPageProps {
  materialType: MaterialType;
  onNavigateToUpload?: (materialId?: string) => void;
  onNavigateToCreateTask?: () => void;
}

export function MaterialLibraryPage({
  materialType,
  onNavigateToUpload,
  onNavigateToCreateTask,
}: MaterialLibraryPageProps) {
  const [materials] = useState<Material[]>(mockMaterials);
  const [activeTab, setActiveTab] =
    useState<string>("my-materials");

  // Filter states
  const [nameQuery, setNameQuery] = useState("");
  const [materialStatusFilter, setMaterialStatusFilter] =
    useState<string>("all");
  const [pushStatusFilter, setPushStatusFilter] =
    useState<string>("all");
  const [tagFilter, setTagFilter] = useState<string>("all");
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  const [pushDateFrom, setPushDateFrom] = useState<Date>();
  const [pushDateTo, setPushDateTo] = useState<Date>();

  // Applied filters (only update when clicking "查询")
  const [appliedFilters, setAppliedFilters] = useState({
    nameQuery: "",
    materialStatusFilter: "all",
    pushStatusFilter: "all",
    tagFilter: "all",
    dateFrom: undefined as Date | undefined,
    dateTo: undefined as Date | undefined,
    pushDateFrom: undefined as Date | undefined,
    pushDateTo: undefined as Date | undefined,
  });

  const [editingMaterial, setEditingMaterial] =
    useState<Material | null>(null);
  const [editingMaterialTags, setEditingMaterialTags] = 
    useState<string[]>([]);
  const [isEditDialogOpen, setIsEditDialogOpen] =
    useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Delete state
  const [deletingMaterial, setDeletingMaterial] =
    useState<Material | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] =
    useState(false);

  // Preview state
  const [previewMaterial, setPreviewMaterial] =
    useState<Material | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // Sort state
  type SortOrder = "asc" | "desc" | null;
  const [createdAtSort, setCreatedAtSort] =
    useState<SortOrder>(null);
  const [pushTimeSort, setPushTimeSort] =
    useState<SortOrder>(null);

  // Helper function: 合并素材包标签和素材专属标签
  const getAllMaterialTags = (material: Material): string[] => {
    const packageTags = material.tags || [];
    const materialTags = material.materialTags || [];
    return [...packageTags, ...materialTags];
  };

  // Get all unique tags (包括素材包标签和素材专属标签)
  const allTags = useMemo(() => {
    const tags = new Set<string>();
    materials.forEach((m) => {
      const allMaterialTags = getAllMaterialTags(m);
      allMaterialTags.forEach((tag) => tags.add(tag));
    });
    return Array.from(tags);
  }, [materials]);

  // Filter materials by type and applied filters
  const filteredMaterials = useMemo(() => {
    let result = materials
      .filter((m) => m.type === materialType)
      .filter((m) => {
        // Name filter
        if (appliedFilters.nameQuery) {
          const searchLower =
            appliedFilters.nameQuery.toLowerCase();
          return m.name.toLowerCase().includes(searchLower);
        }
        return true;
      })
      .filter((m) => {
        // Material status filter
        if (appliedFilters.materialStatusFilter !== "all") {
          return (
            m.status === appliedFilters.materialStatusFilter
          );
        }
        return true;
      })
      .filter((m) => {
        // Push status filter
        if (appliedFilters.pushStatusFilter !== "all") {
          return (
            m.pushStatus === appliedFilters.pushStatusFilter
          );
        }
        return true;
      })
      .filter((m) => {
        // Tag filter (检查素材包标签和素材专属标签)
        if (appliedFilters.tagFilter !== "all") {
          const allTags = getAllMaterialTags(m);
          return allTags.includes(appliedFilters.tagFilter);
        }
        return true;
      })
      .filter((m) => {
        // Date range filter
        if (appliedFilters.dateFrom || appliedFilters.dateTo) {
          const materialDate = new Date(m.createdAt);
          if (
            appliedFilters.dateFrom &&
            materialDate < appliedFilters.dateFrom
          )
            return false;
          if (
            appliedFilters.dateTo &&
            materialDate > appliedFilters.dateTo
          )
            return false;
        }
        return true;
      })
      .filter((m) => {
        // Push date range filter
        if (
          appliedFilters.pushDateFrom ||
          appliedFilters.pushDateTo
        ) {
          const pushDate = new Date(
            m.lastPushTime || "1970-01-01",
          );
          if (
            appliedFilters.pushDateFrom &&
            pushDate < appliedFilters.pushDateFrom
          )
            return false;
          if (
            appliedFilters.pushDateTo &&
            pushDate > appliedFilters.pushDateTo
          )
            return false;
        }
        return true;
      });

    // Apply sorting
    if (createdAtSort) {
      result.sort((a, b) => {
        const dateA = new Date(a.createdAt).getTime();
        const dateB = new Date(b.createdAt).getTime();
        return createdAtSort === "asc"
          ? dateA - dateB
          : dateB - dateA;
      });
    } else if (pushTimeSort) {
      result.sort((a, b) => {
        const dateA = new Date(
          a.lastPushTime || "1970-01-01",
        ).getTime();
        const dateB = new Date(
          b.lastPushTime || "1970-01-01",
        ).getTime();
        return pushTimeSort === "asc"
          ? dateA - dateB
          : dateB - dateA;
      });
    }

    return result;
  }, [
    materials,
    materialType,
    appliedFilters,
    createdAtSort,
    pushTimeSort,
  ]);

  // Pagination
  const totalPages = Math.ceil(
    filteredMaterials.length / itemsPerPage,
  );
  const paginatedMaterials = filteredMaterials.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  const handleQuery = () => {
    setAppliedFilters({
      nameQuery,
      materialStatusFilter,
      pushStatusFilter,
      tagFilter,
      dateFrom,
      dateTo,
      pushDateFrom,
      pushDateTo,
    });
    setCurrentPage(1);
    toast.success("查询完成");
  };

  const handleResetFilters = () => {
    setNameQuery("");
    setMaterialStatusFilter("all");
    setPushStatusFilter("all");
    setTagFilter("all");
    setDateFrom(undefined);
    setDateTo(undefined);
    setPushDateFrom(undefined);
    setPushDateTo(undefined);
    setAppliedFilters({
      nameQuery: "",
      materialStatusFilter: "all",
      pushStatusFilter: "all",
      tagFilter: "all",
      dateFrom: undefined,
      dateTo: undefined,
      pushDateFrom: undefined,
      pushDateTo: undefined,
    });
    setCurrentPage(1);
    toast.success("筛选条件已重置");
  };

  const handleEditClick = (material: Material) => {
    setEditingMaterial(material);
    setEditingMaterialTags(material.materialTags || []);
    setIsEditDialogOpen(true);
  };

  const handleModifyClick = (material: Material) => {
    // 跳转到上传页面并传递素材ID以进行重新上传
    if (onNavigateToUpload) {
      onNavigateToUpload(material.id);
    } else {
      toast.info("重新上传功能开发中...");
    }
  };

  const handleDeleteClick = (material: Material) => {
    setDeletingMaterial(material);
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (deletingMaterial) {
      // 在实际应用中，这里应该调用删除API
      toast.success(`素材"${deletingMaterial.name}"已删除`);
      setIsDeleteDialogOpen(false);
      setDeletingMaterial(null);
      // TODO: 刷新素材列表
    }
  };

  const handleUpload = () => {
    if (onNavigateToUpload) {
      onNavigateToUpload();
    } else {
      const uploadText = getUploadButtonText();
      toast.info(`${uploadText}功能开发中...`);
    }
  };

  const getUploadButtonText = () => {
    switch (materialType) {
      case "video":
        return "上传视频";
      case "image":
        return "上传图片";
      case "html5":
        return "上传H5";
    }
  };

  // 根据推送状态动态获取素材状态
  const getDisplayMaterialStatus = (material: Material): MaterialStatus => {
    // 推送状态为"推送中"时，强制显示为"未启用"
    if (material.pushStatus === "pushing") {
      return "inactive";
    }
    // 推送状态为"未推送"时，强制显示为"未启用"
    if (material.pushStatus === "not_pushed") {
      return "inactive";
    }
    // 其他情况返回实际状态
    return material.status;
  };

  const getMaterialStatusBadge = (status: MaterialStatus) => {
    switch (status) {
      case "active":
        return (
          <Badge className="bg-green-600">
            <PlayCircle className="mr-1 h-3 w-3" />
            使用中
          </Badge>
        );
      case "inactive":
        return (
          <Badge variant="secondary">
            <Pause className="mr-1 h-3 w-3" />
            未启用
          </Badge>
        );
      case "disabled":
        return (
          <Badge variant="destructive">
            <Ban className="mr-1 h-3 w-3" />
            已停用
          </Badge>
        );
    }
  };

  const getPushStatusBadge = (pushStatus: PushStatus) => {
    switch (pushStatus) {
      case "pushed":
        return (
          <Badge className="bg-blue-600">
            <CheckCircle2 className="mr-1 h-3 w-3" />
            已推送
          </Badge>
        );
      case "pushing":
        return <Badge variant="outline">推送中</Badge>;
      case "failed":
        return (
          <Badge variant="destructive">
            <XCircle className="mr-1 h-3 w-3" />
            推送失败
          </Badge>
        );
      case "not_pushed":
        return <Badge variant="secondary">未推送</Badge>;
    }
  };

  const getTypeTitle = () => {
    switch (materialType) {
      case "video":
        return "视频库";
      case "image":
        return "图片库";
      case "html5":
        return "H5页面";
    }
  };

  // 获取缩略图URL
  const getThumbnailUrl = (material: Material) => {
    const seed = material.id;
    const width = 80;
    const height = 60;

    if (material.type === "video") {
      return `https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    } else if (material.type === "image") {
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    }
    return "";
  };

  // 获取完整文件URL（用于全屏预览）
  const getFullFileUrl = (material: Material) => {
    const seed = material.id;

    if (material.type === "video") {
      // 使用示例视频URL
      return `https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4`;
    } else if (material.type === "image") {
      // 使用高分辨率图片
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&h=1080&fit=crop&seed=${seed}`;
    }
    return "";
  };

  // 处理缩略图点击
  const handleThumbnailClick = (material: Material) => {
    if (
      material.type === "video" ||
      material.type === "image"
    ) {
      setPreviewMaterial(material);
      setIsPreviewOpen(true);
    }
  };

  // 判断是否显示缩略图列
  const shouldShowThumbnail =
    materialType === "video" || materialType === "image";

  return (
    <Tabs
      value={activeTab}
      onValueChange={setActiveTab}
      className="space-y-4"
    >
      {/* 区域1: 顶部页签 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <TabsList>
          <TabsTrigger value="my-materials">
            本人素材
          </TabsTrigger>
          <TabsTrigger value="featured-materials">
            全部素材
          </TabsTrigger>
        </TabsList>
      </div>

      {/* 区域2: 筛选条件 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <TabsContent value="my-materials" className="mt-0">
          <div className="space-y-6">
            {/* Filters - 两行四列布局 */}
            <div className="grid grid-cols-4 gap-4">
              {/* 第一行 */}
              {/* 素材名称 */}
              <div>
                <label className="text-sm text-gray-600 mb-1 block">
                  素材名称
                </label>
                <Input
                  placeholder="请输入素材名称"
                  value={nameQuery}
                  onChange={(e) => setNameQuery(e.target.value)}
                />
              </div>

              {/* 素材状态 */}
              <div>
                <label className="text-sm text-gray-600 mb-1 block">
                  素材状态
                </label>
                <Select
                  value={materialStatusFilter}
                  onValueChange={setMaterialStatusFilter}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="请选择" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    <SelectItem value="active">
                      使用中
                    </SelectItem>
                    <SelectItem value="inactive">
                      未启用
                    </SelectItem>
                    <SelectItem value="disabled">
                      已停用
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* 推送状态 */}
              <div>
                <label className="text-sm text-gray-600 mb-1 block">
                  推送状态
                </label>
                <Select
                  value={pushStatusFilter}
                  onValueChange={setPushStatusFilter}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="请选择" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    <SelectItem value="not_pushed">
                      未推送
                    </SelectItem>
                    <SelectItem value="pushing">
                      推送中
                    </SelectItem>
                    <SelectItem value="pushed">
                      已推送
                    </SelectItem>
                    <SelectItem value="failed">
                      推送失败
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* 素材标签 */}
              <div>
                <label className="text-sm text-gray-600 mb-1 block">
                  素材标签
                </label>
                <Select
                  value={tagFilter}
                  onValueChange={setTagFilter}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="请选择" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    {allTags.map((tag) => (
                      <SelectItem key={tag} value={tag}>
                        {tag}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* 第二行 */}
              {/* 制作时间 - 占据两列 */}
              <div className="col-span-2">
                <label className="text-sm text-gray-600 mb-1 block">
                  制作时间
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left",
                          !dateFrom && "text-gray-400",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateFrom
                          ? format(dateFrom, "yyyy-MM-dd")
                          : "开始日期"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent
                      className="w-auto p-0"
                      align="start"
                    >
                      <Calendar
                        mode="single"
                        selected={dateFrom}
                        onSelect={setDateFrom}
                        locale={zhCN}
                      />
                    </PopoverContent>
                  </Popover>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left",
                          !dateTo && "text-gray-400",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateTo
                          ? format(dateTo, "yyyy-MM-dd")
                          : "结束日期"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent
                      className="w-auto p-0"
                      align="start"
                    >
                      <Calendar
                        mode="single"
                        selected={dateTo}
                        onSelect={setDateTo}
                        locale={zhCN}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* 推送时间 - 占据两列 */}
              <div className="col-span-2">
                <label className="text-sm text-gray-600 mb-1 block">
                  推送时间
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left",
                          !pushDateFrom && "text-gray-400",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {pushDateFrom
                          ? format(pushDateFrom, "yyyy-MM-dd")
                          : "开始日期"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent
                      className="w-auto p-0"
                      align="start"
                    >
                      <Calendar
                        mode="single"
                        selected={pushDateFrom}
                        onSelect={setPushDateFrom}
                        locale={zhCN}
                      />
                    </PopoverContent>
                  </Popover>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left",
                          !pushDateTo && "text-gray-400",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {pushDateTo
                          ? format(pushDateTo, "yyyy-MM-dd")
                          : "结束日期"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent
                      className="w-auto p-0"
                      align="start"
                    >
                      <Calendar
                        mode="single"
                        selected={pushDateTo}
                        onSelect={setPushDateTo}
                        locale={zhCN}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end items-center">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleResetFilters}
                >
                  <RotateCcw className="mr-2 h-4 w-4" />
                  重置
                </Button>
                <Button onClick={handleQuery}>查询</Button>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent
          value="featured-materials"
          className="mt-0"
        >
          <div className="space-y-6">
            {/* Filters - 全部素材使用相同的筛选条件，两行四列布局 */}
            <div className="grid grid-cols-4 gap-4">
              {/* 第一行 */}
              {/* 素材名称 */}
              <div>
                <label className="text-sm text-gray-600 mb-1 block">
                  素材名称
                </label>
                <Input
                  placeholder="请输入素材名称"
                  value={nameQuery}
                  onChange={(e) => setNameQuery(e.target.value)}
                />
              </div>

              {/* 素材状态 */}
              <div>
                <label className="text-sm text-gray-600 mb-1 block">
                  素材状态
                </label>
                <Select
                  value={materialStatusFilter}
                  onValueChange={setMaterialStatusFilter}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="请选择" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    <SelectItem value="active">
                      使用中
                    </SelectItem>
                    <SelectItem value="inactive">
                      未启用
                    </SelectItem>
                    <SelectItem value="disabled">
                      已停用
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* 推送状态 */}
              <div>
                <label className="text-sm text-gray-600 mb-1 block">
                  推送状态
                </label>
                <Select
                  value={pushStatusFilter}
                  onValueChange={setPushStatusFilter}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="请选择" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    <SelectItem value="not_pushed">
                      未推送
                    </SelectItem>
                    <SelectItem value="pushing">
                      推送中
                    </SelectItem>
                    <SelectItem value="pushed">
                      已推送
                    </SelectItem>
                    <SelectItem value="failed">
                      推送失败
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* 素材标签 */}
              <div>
                <label className="text-sm text-gray-600 mb-1 block">
                  素材标签
                </label>
                <Select
                  value={tagFilter}
                  onValueChange={setTagFilter}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="请选择" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    {allTags.map((tag) => (
                      <SelectItem key={tag} value={tag}>
                        {tag}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* 第二行 */}
              {/* 制作时间 - 占据两列 */}
              <div className="col-span-2">
                <label className="text-sm text-gray-600 mb-1 block">
                  制作时间
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left",
                          !dateFrom && "text-gray-400",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateFrom
                          ? format(dateFrom, "yyyy-MM-dd")
                          : "开始日期"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent
                      className="w-auto p-0"
                      align="start"
                    >
                      <Calendar
                        mode="single"
                        selected={dateFrom}
                        onSelect={setDateFrom}
                        locale={zhCN}
                      />
                    </PopoverContent>
                  </Popover>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left",
                          !dateTo && "text-gray-400",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateTo
                          ? format(dateTo, "yyyy-MM-dd")
                          : "结束日期"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent
                      className="w-auto p-0"
                      align="start"
                    >
                      <Calendar
                        mode="single"
                        selected={dateTo}
                        onSelect={setDateTo}
                        locale={zhCN}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* 推送时间 - 占据两列 */}
              <div className="col-span-2">
                <label className="text-sm text-gray-600 mb-1 block">
                  推送时间
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left",
                          !pushDateFrom && "text-gray-400",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {pushDateFrom
                          ? format(pushDateFrom, "yyyy-MM-dd")
                          : "开始日期"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent
                      className="w-auto p-0"
                      align="start"
                    >
                      <Calendar
                        mode="single"
                        selected={pushDateFrom}
                        onSelect={setPushDateFrom}
                        locale={zhCN}
                      />
                    </PopoverContent>
                  </Popover>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left",
                          !pushDateTo && "text-gray-400",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {pushDateTo
                          ? format(pushDateTo, "yyyy-MM-dd")
                          : "结束日期"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent
                      className="w-auto p-0"
                      align="start"
                    >
                      <Calendar
                        mode="single"
                        selected={pushDateTo}
                        onSelect={setPushDateTo}
                        locale={zhCN}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end items-center">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleResetFilters}
                >
                  <RotateCcw className="mr-2 h-4 w-4" />
                  重置
                </Button>
                <Button onClick={handleQuery}>查询</Button>
              </div>
            </div>
          </div>
        </TabsContent>
      </div>

      {/* 区域3: 列表 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <TabsContent value="my-materials" className="mt-0">
          <div className="space-y-4">
            {/* Upload and Batch Push Buttons */}
            <div className="flex justify-start gap-3">
              <Button onClick={handleUpload}>
                <Upload className="mr-2 h-4 w-4" />
                {getUploadButtonText()}
              </Button>
              {onNavigateToCreateTask && (
                <Button
                  onClick={onNavigateToCreateTask}
                  variant="default"
                >
                  <Send className="mr-2 h-4 w-4" />
                  批量推送
                </Button>
              )}
            </div>

            {/* Table */}
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="w-28">
                      缩略图
                    </TableHead>
                    <TableHead>素材名称</TableHead>
                    <TableHead>素材包</TableHead>
                    <TableHead>制作类型</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>推送状态</TableHead>
                    <TableHead>产品</TableHead>
                    <TableHead>标签（包+专属）</TableHead>
                    <TableHead>创意人</TableHead>
                    <TableHead
                      className="cursor-pointer select-none hover:bg-gray-100"
                      onClick={() => {
                        setCreatedAtSort(
                          createdAtSort === "asc"
                            ? "desc"
                            : createdAtSort === "desc"
                              ? null
                              : "asc",
                        );
                        setPushTimeSort(null);
                      }}
                    >
                      <div className="flex items-center">
                        制作时间
                        {createdAtSort === null && (
                          <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />
                        )}
                        {createdAtSort === "asc" && (
                          <ArrowUp className="ml-2 h-4 w-4 inline-block" />
                        )}
                        {createdAtSort === "desc" && (
                          <ArrowDown className="ml-2 h-4 w-4 inline-block" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer select-none hover:bg-gray-100"
                      onClick={() => {
                        setPushTimeSort(
                          pushTimeSort === "asc"
                            ? "desc"
                            : pushTimeSort === "desc"
                              ? null
                              : "asc",
                        );
                        setCreatedAtSort(null);
                      }}
                    >
                      <div className="flex items-center">
                        推送时间
                        {pushTimeSort === null && (
                          <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />
                        )}
                        {pushTimeSort === "asc" && (
                          <ArrowUp className="ml-2 h-4 w-4 inline-block" />
                        )}
                        {pushTimeSort === "desc" && (
                          <ArrowDown className="ml-2 h-4 w-4 inline-block" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="w-24">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedMaterials.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={12}
                        className="text-center py-12 text-gray-500"
                      >
                        <div className="flex flex-col items-center gap-2">
                          <div className="text-4xl">📦</div>
                          <div>
                            暂无
                            {getMaterialTypeName(materialType)}
                            素材
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    paginatedMaterials.map((material) => (
                      <TableRow
                        key={material.id}
                        className="hover:bg-gray-50"
                      >
                        <TableCell>
                          {shouldShowThumbnail && (
                            <div
                              className="relative w-20 h-15 bg-gray-100 rounded overflow-hidden flex-shrink-0 cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all"
                              onClick={() =>
                                handleThumbnailClick(material)
                              }
                            >
                              <img
                                src={getThumbnailUrl(material)}
                                alt={material.name}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/20 transition-colors">
                                {material.type === "video" ? (
                                  <Video className="h-6 w-6 text-white" />
                                ) : (
                                  <ImageIcon className="h-6 w-6 text-white" />
                                )}
                              </div>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="max-w-xs">
                            <div className="font-medium">
                              {material.name}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="max-w-xs">
                            <div className="text-sm font-medium text-gray-900">
                              {material.packageName}
                            </div>
                            <div className="text-xs text-gray-500">
                              {material.packageNumber}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          <Badge variant="outline" className="text-xs">
                            {material.productionType}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {getMaterialStatusBadge(
                            getDisplayMaterialStatus(material),
                          )}
                        </TableCell>
                        <TableCell>
                          {getPushStatusBadge(
                            material.pushStatus,
                          )}
                        </TableCell>
                        <TableCell className="text-sm">
                          {material.product}
                        </TableCell>
                        <TableCell>
                          <MaterialTagsCell material={material} />
                        </TableCell>
                        <TableCell className="text-sm">
                          {material.designer}
                        </TableCell>
                        <TableCell className="text-sm text-gray-500">
                          {format(
                            new Date(material.createdAt),
                            "yyyy-MM-dd HH:mm",
                            {
                              locale: zhCN,
                            },
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-gray-500">
                          {material.pushStatus === "pushed" &&
                          material.lastPushTime
                            ? format(
                                new Date(material.lastPushTime),
                                "yyyy-MM-dd HH:mm",
                                {
                                  locale: zhCN,
                                },
                              )
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Button
                              size="sm"
                              variant="link"
                              onClick={() =>
                                handleEditClick(material)
                              }
                              className="h-auto p-0 text-blue-600 hover:text-blue-700"
                            >
                              <Edit className="mr-1 h-3.5 w-3.5" />
                              标签
                            </Button>
                            {material.pushStatus ===
                              "not_pushed" && (
                              <>
                                <Button
                                  size="sm"
                                  variant="link"
                                  onClick={() =>
                                    handleModifyClick(material)
                                  }
                                  className="h-auto p-0 text-blue-600 hover:text-blue-700"
                                >
                                  <Upload className="mr-1 h-3.5 w-3.5" />
                                  修改
                                </Button>
                                <Button
                                  size="sm"
                                  variant="link"
                                  onClick={() =>
                                    handleDeleteClick(material)
                                  }
                                  className="h-auto p-0 text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="mr-1 h-3.5 w-3.5" />
                                  删除
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                只有 {totalPages} 页，共{" "}
                {filteredMaterials.length} 条素材
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    setCurrentPage((p) => Math.max(1, p - 1))
                  }
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                {Array.from(
                  { length: totalPages },
                  (_, i) => i + 1,
                ).map((page) => (
                  <Button
                    key={page}
                    variant={
                      currentPage === page
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => setCurrentPage(page)}
                    className="min-w-[2rem]"
                  >
                    {page}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    setCurrentPage((p) =>
                      Math.min(totalPages, p + 1),
                    )
                  }
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent
          value="featured-materials"
          className="mt-0"
        >
          <div className="space-y-4">
            {/* 全部素材表格 - 没有上传按钮，没有操作列 */}
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="w-28">
                      缩略图
                    </TableHead>
                    <TableHead>素材名称</TableHead>
                    <TableHead>素材包</TableHead>
                    <TableHead>制作类型</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>推送状态</TableHead>
                    <TableHead>产品</TableHead>
                    <TableHead>标签（包+专属）</TableHead>
                    <TableHead>创意人</TableHead>
                    <TableHead
                      className="cursor-pointer select-none hover:bg-gray-100"
                      onClick={() => {
                        setCreatedAtSort(
                          createdAtSort === "asc"
                            ? "desc"
                            : createdAtSort === "desc"
                              ? null
                              : "asc",
                        );
                        setPushTimeSort(null);
                      }}
                    >
                      <div className="flex items-center">
                        制作时间
                        {createdAtSort === null && (
                          <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />
                        )}
                        {createdAtSort === "asc" && (
                          <ArrowUp className="ml-2 h-4 w-4 inline-block" />
                        )}
                        {createdAtSort === "desc" && (
                          <ArrowDown className="ml-2 h-4 w-4 inline-block" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer select-none hover:bg-gray-100"
                      onClick={() => {
                        setPushTimeSort(
                          pushTimeSort === "asc"
                            ? "desc"
                            : pushTimeSort === "desc"
                              ? null
                              : "asc",
                        );
                        setCreatedAtSort(null);
                      }}
                    >
                      <div className="flex items-center">
                        推送时间
                        {pushTimeSort === null && (
                          <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />
                        )}
                        {pushTimeSort === "asc" && (
                          <ArrowUp className="ml-2 h-4 w-4 inline-block" />
                        )}
                        {pushTimeSort === "desc" && (
                          <ArrowDown className="ml-2 h-4 w-4 inline-block" />
                        )}
                      </div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedMaterials.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={11}
                        className="text-center py-12 text-gray-500"
                      >
                        <div className="flex flex-col items-center gap-2">
                          <div className="text-4xl">📦</div>
                          <div>
                            暂无
                            {getMaterialTypeName(materialType)}
                            素材
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    paginatedMaterials.map((material) => (
                      <TableRow
                        key={material.id}
                        className="hover:bg-gray-50"
                      >
                        <TableCell>
                          {shouldShowThumbnail && (
                            <div className="relative w-20 h-15 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                              <img
                                src={getThumbnailUrl(material)}
                                alt={material.name}
                                className="w-full h-full object-cover"
                                onClick={() =>
                                  handleThumbnailClick(material)
                                }
                              />
                              <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                {material.type === "video" ? (
                                  <Video className="h-6 w-6 text-white" />
                                ) : (
                                  <ImageIcon className="h-6 w-6 text-white" />
                                )}
                              </div>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="max-w-xs">
                            <div className="font-medium">
                              {material.name}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="max-w-xs">
                            <div className="text-sm font-medium text-gray-900">
                              {material.packageName}
                            </div>
                            <div className="text-xs text-gray-500">
                              {material.packageNumber}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          <Badge variant="outline" className="text-xs">
                            {material.productionType}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {getMaterialStatusBadge(
                            getDisplayMaterialStatus(material),
                          )}
                        </TableCell>
                        <TableCell>
                          {getPushStatusBadge(
                            material.pushStatus,
                          )}
                        </TableCell>
                        <TableCell className="text-sm">
                          {material.product}
                        </TableCell>
                        <TableCell>
                          <MaterialTagsCell material={material} />
                        </TableCell>
                        <TableCell className="text-sm">
                          {material.designer}
                        </TableCell>
                        <TableCell className="text-sm text-gray-500">
                          {format(
                            new Date(material.createdAt),
                            "yyyy-MM-dd HH:mm",
                            {
                              locale: zhCN,
                            },
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-gray-500">
                          {material.pushStatus === "pushed" &&
                          material.lastPushTime
                            ? format(
                                new Date(material.lastPushTime),
                                "yyyy-MM-dd HH:mm",
                                {
                                  locale: zhCN,
                                },
                              )
                            : "-"}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                只有 {totalPages} 页，共{" "}
                {filteredMaterials.length} 条素材
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    setCurrentPage((p) => Math.max(1, p - 1))
                  }
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                {Array.from(
                  { length: totalPages },
                  (_, i) => i + 1,
                ).map((page) => (
                  <Button
                    key={page}
                    variant={
                      currentPage === page
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => setCurrentPage(page)}
                    className="min-w-[2rem]"
                  >
                    {page}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    setCurrentPage((p) =>
                      Math.min(totalPages, p + 1),
                    )
                  }
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>
      </div>

      {/* Edit Dialog - 素材标签编辑 */}
      <Dialog
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>编辑素材标签</DialogTitle>
            <DialogDescription>修改素材专属标签</DialogDescription>
          </DialogHeader>

          {editingMaterial && (
            <div className="space-y-4">
              {/* 素材基本信息 */}
              <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600 w-24">素材名称：</span>
                  <span className="text-sm font-medium text-gray-900">{editingMaterial.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600 w-24">所属产品：</span>
                  <span className="text-sm text-gray-900">{editingMaterial.product}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600 w-24">素材包：</span>
                  <span className="text-sm text-gray-900">{editingMaterial.packageName}</span>
                </div>
              </div>

              {/* 素材包标签（只读） */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  素材包标签 <span className="text-gray-500 font-normal">（从素材包继承，不可修改）</span>
                </label>
                <div className="flex flex-wrap gap-2 bg-gray-50 rounded-lg p-3 min-h-[48px]">
                  {editingMaterial.tags && editingMaterial.tags.length > 0 ? (
                    editingMaterial.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="px-3 py-1.5 bg-blue-100 text-blue-700 rounded-md text-sm font-medium"
                      >
                        {tag}
                      </span>
                    ))
                  ) : (
                    <span className="text-sm text-gray-400">无</span>
                  )}
                </div>
              </div>

              {/* 素材专属标签（可编辑） */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  素材专属标签 <span className="text-red-500">*</span>
                </label>
                <MaterialTagSelector
                  selectedTags={editingMaterialTags}
                  onChange={setEditingMaterialTags}
                />
              </div>

              {/* 说明 */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-sm text-blue-800">
                  <strong>说明：</strong>
                  素材包标签会自动应用到所有素材，素材专属标签仅应用于当前素材。在素材库中，两类标签会合并显示。
                </p>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsEditDialogOpen(false);
                setEditingMaterialTags([]);
              }}
            >
              取消
            </Button>
            <Button
              onClick={() => {
                if (editingMaterial) {
                  // 更新素材的专属标签
                  const allTags = [
                    ...editingMaterial.tags,
                    ...editingMaterialTags
                  ];
                  toast.success(
                    `素材专属标签已更新为"${editingMaterialTags.join(', ') || '无'}"，完整标签：${allTags.join(', ')}`
                  );
                }
                setIsEditDialogOpen(false);
                setEditingMaterialTags([]);
              }}
            >
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>确认删除</DialogTitle>
            <DialogDescription>
              此操作无法撤销，确定要删除该素材吗？
            </DialogDescription>
          </DialogHeader>

          {deletingMaterial && (
            <div className="space-y-2 py-4">
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">
                  素材名称：
                </span>
                <span className="text-sm font-medium">
                  {deletingMaterial.name}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">
                  产品：
                </span>
                <span className="text-sm">
                  {deletingMaterial.product}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">
                  创意人：
                </span>
                <span className="text-sm">
                  {deletingMaterial.designer}
                </span>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              取消
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirmDelete}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              确认删除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog
        open={isPreviewOpen}
        onOpenChange={setIsPreviewOpen}
      >
        <DialogContent className="max-w-7xl w-full h-[90vh] p-0">
          <div className="relative w-full h-full bg-black">
            {/* Close Button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 z-50 text-white hover:bg-white/20"
              onClick={() => setIsPreviewOpen(false)}
            >
              <X className="h-6 w-6" />
            </Button>

            {/* Title */}
            {previewMaterial && (
              <div className="absolute top-4 left-4 z-50 text-white">
                <h3 className="text-lg font-medium">
                  {previewMaterial.name}
                </h3>
                <p className="text-sm text-gray-300">
                  {previewMaterial.product}
                </p>
              </div>
            )}

            {/* Content */}
            <div className="w-full h-full flex items-center justify-center">
              {previewMaterial &&
              previewMaterial.type === "video" ? (
                <video
                  controls
                  autoPlay
                  className="max-w-full max-h-full"
                  src={getFullFileUrl(previewMaterial)}
                >
                  您的浏览器不支持视频播放
                </video>
              ) : previewMaterial &&
                previewMaterial.type === "image" ? (
                <img
                  src={getFullFileUrl(previewMaterial)}
                  alt={previewMaterial.name}
                  className="max-w-full max-h-full object-contain"
                />
              ) : null}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Tabs>
  );
}