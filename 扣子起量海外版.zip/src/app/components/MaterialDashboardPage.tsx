import { useState } from 'react';
import { Settings, RotateCcw, Download, ArrowUpDown, ArrowUp, ArrowDown, CalendarIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { Calendar } from './ui/calendar';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';
import { cn } from './ui/utils';
import { ColumnConfigDialog } from './ColumnConfigDialog';

// 维度定义
interface Dimension {
  id: string;
  name: string;
  description: string;
  type: 'dimension';
}

// 指标定义
interface Metric {
  id: string;
  name: string;
  description: string;
  type: 'atomic' | 'composite' | 'derived';
  formula?: string;
}

// 列配置
interface ColumnConfig {
  id: string;
  visible: boolean;
  order: number;
}

// 素材数据
interface MaterialData {
  id: string;
  materialName: string;
  app: string;
  network: string;
  country: string;
  productionType: string;
  creator: string;
  creativePerson: string;
  materialType: string;
  cost: number;
  im: number;
  clk: number;
  act: number;
  cpi: number;
  ctr: number;
  cvr: number;
  ipm: number;
  cpm: number;
  ad: number;
  iap: number;
  d0_roi: number;
}

// 维度列表
const dimensions: Dimension[] = [
  { id: 'app', name: '应用', description: '包别名', type: 'dimension' },
  { id: 'network', name: 'network', description: '渠道', type: 'dimension' },
  { id: 'country', name: '国家', description: '国家', type: 'dimension' },
  { id: 'productionType', name: '制作类型', description: '素材制作类型', type: 'dimension' },
  { id: 'creator', name: '制作人', description: '素材制作的设计师', type: 'dimension' },
  { id: 'creativePerson', name: '创意人', description: '素材关联的创意人', type: 'dimension' },
  { id: 'materialType', name: '素材类型', description: '视频、图片、H5', type: 'dimension' },
];

// 原子指标
const atomicMetrics: Metric[] = [
  { id: 'cost', name: 'Cost($)', description: '广告投放花费', type: 'atomic' },
  { id: 'im', name: 'IM', description: '投放展示量', type: 'atomic' },
  { id: 'clk', name: 'CLK', description: '投放点击量', type: 'atomic' },
  { id: 'act', name: 'Act', description: '激活数', type: 'atomic' },
];

// 复合指标
const compositeMetrics: Metric[] = [
  { id: 'cpi', name: 'CPI_1($)', description: '激活成本(美元)', type: 'composite', formula: 'Cost($)/Act' },
  { id: 'ctr', name: 'CTR', description: '点击率', type: 'composite', formula: 'CLK/ IM' },
  { id: 'cvr', name: 'CVR', description: '转化率', type: 'composite', formula: 'Act /CLK' },
  { id: 'ipm', name: 'IPM_1', description: '千次展示转化', type: 'composite', formula: '(Act/IM)*1000' },
  { id: 'cpm', name: 'CPM($)', description: '千次展示花费', type: 'composite', formula: 'Cost($) / IM*1000' },
];

// 衍生指标
const derivedMetrics: Metric[] = [
  { id: 'ad', name: 'ad($)', description: '当日预估广告收入(美元)', type: 'derived', formula: '原始名ad_rev($)' },
  { id: 'iap', name: 'iap_1', description: '累计iap收入(开发者收入,扣除平台分成和增值税后的收入)', type: 'derived' },
  { id: 'iap_uv', name: 'iap_uv', description: '订阅用户数', type: 'derived' },
  { id: 'd0_roi', name: 'D0_ROI', description: 'D0回报率', type: 'derived', formula: '(ad+iap_1)/Cost' },
  { id: 'ivr', name: 'IVR', description: '展示转化率', type: 'derived', formula: 'Act / IM' },
  { id: 'retention2', name: '激活次留', description: '触发激活事件的新用户的次日留存', type: 'derived' },
  { id: 'retention7', name: '激活7留', description: '触发激活事件的新用户的7日留存', type: 'derived' },
  { id: 'retention14', name: '激活14留', description: '触发激活事件的新用户的14日留存', type: 'derived' },
];

// Mock 数据
const mockMaterialData: MaterialData[] = [
  {
    id: '1',
    materialName: 'Bingo Bonus 新年推广视频_001',
    app: 'Bingo Bonus',
    network: 'Facebook',
    country: 'US',
    productionType: '0-1制作',
    creator: '张设计',
    creativePerson: '张设计',
    materialType: '视频',
    cost: 15680.50,
    im: 1250000,
    clk: 85000,
    act: 12500,
    cpi: 1.25,
    ctr: 6.8,
    cvr: 14.7,
    ipm: 10.0,
    cpm: 12.54,
    ad: 18500.00,
    iap: 5200.00,
    d0_roi: 1.51,
  },
  {
    id: '2',
    materialName: 'Yazzy GO! 海外市场素材_视频A',
    app: 'Yazzy GO!',
    network: 'Google Ads',
    country: 'UK',
    productionType: '1-N制作',
    creator: '李设计',
    creativePerson: '李设计',
    materialType: '视频',
    cost: 22340.20,
    im: 1850000,
    clk: 120000,
    act: 18000,
    cpi: 1.24,
    ctr: 6.5,
    cvr: 15.0,
    ipm: 9.7,
    cpm: 12.07,
    ad: 28000.00,
    iap: 7800.00,
    d0_roi: 1.60,
  },
  {
    id: '3',
    materialName: 'Fishberry Story 情人节活动图片_001',
    app: 'Fishberry Story',
    network: 'TikTok',
    country: 'CA',
    productionType: '0-1制作',
    creator: '王设计',
    creativePerson: '王设计',
    materialType: '图片',
    cost: 9820.00,
    im: 980000,
    clk: 65000,
    act: 9500,
    cpi: 1.03,
    ctr: 6.6,
    cvr: 14.6,
    ipm: 9.7,
    cpm: 10.02,
    ad: 12500.00,
    iap: 3200.00,
    d0_roi: 1.60,
  },
  {
    id: '4',
    materialName: 'CabCare 春节专题H5_互动版',
    app: 'CabCare',
    network: 'Facebook',
    country: 'AU',
    productionType: '1-N制作',
    creator: '赵设计',
    creativePerson: '赵设计',
    materialType: 'H5',
    cost: 18950.75,
    im: 1650000,
    clk: 145000,
    act: 22000,
    cpi: 0.86,
    ctr: 8.8,
    cvr: 15.2,
    ipm: 13.3,
    cpm: 11.49,
    ad: 32000.00,
    iap: 9500.00,
    d0_roi: 2.19,
  },
  {
    id: '5',
    materialName: 'Mahjong Go 新手引导视频_简化版',
    app: 'Mahjong Go',
    network: 'Google Ads',
    country: 'US',
    productionType: '0-1制作',
    creator: '孙设计',
    creativePerson: '孙设计',
    materialType: '视频',
    cost: 6540.30,
    im: 780000,
    clk: 42000,
    act: 5800,
    cpi: 1.13,
    ctr: 5.4,
    cvr: 13.8,
    ipm: 7.4,
    cpm: 8.39,
    ad: 7200.00,
    iap: 2100.00,
    d0_roi: 1.42,
  },
];

export function MaterialDashboardPage() {
  // 筛选条件
  const [materialNameQuery, setMaterialNameQuery] = useState('');
  const [launchDateFrom, setLaunchDateFrom] = useState<Date>();
  const [launchDateTo, setLaunchDateTo] = useState<Date>();
  const [networkFilter, setNetworkFilter] = useState<string>('all');
  const [productFilter, setProductFilter] = useState<string>('all');
  const [countryFilter, setCountryFilter] = useState<string>('all');
  const [creationDateFrom, setCreationDateFrom] = useState<Date>();
  const [creationDateTo, setCreationDateTo] = useState<Date>();
  const [creatorFilter, setCreatorFilter] = useState<string>('all');
  const [materialTypeFilter, setMaterialTypeFilter] = useState<string>('all');
  const [productionTypeFilter, setProductionTypeFilter] = useState<string>('all');

  // 已应用的筛选条件
  const [appliedFilters, setAppliedFilters] = useState({
    materialNameQuery: '',
    launchDateFrom: undefined as Date | undefined,
    launchDateTo: undefined as Date | undefined,
    networkFilter: 'all',
    productFilter: 'all',
    countryFilter: 'all',
    creationDateFrom: undefined as Date | undefined,
    creationDateTo: undefined as Date | undefined,
    creatorFilter: 'all',
    materialTypeFilter: 'all',
    productionTypeFilter: 'all',
  });

  // 列配置
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false);
  const [columnConfigs, setColumnConfigs] = useState<ColumnConfig[]>(() => {
    // 默认显示所有维度和部分核心指标
    const configs: ColumnConfig[] = [];
    let order = 0;
    
    // 添加维度
    dimensions.forEach(dim => {
      configs.push({ id: dim.id, visible: true, order: order++ });
    });
    
    // 添加原子指标
    atomicMetrics.forEach(metric => {
      configs.push({ id: metric.id, visible: true, order: order++ });
    });
    
    // 添加复合指标
    compositeMetrics.forEach(metric => {
      configs.push({ id: metric.id, visible: true, order: order++ });
    });
    
    // 添加衍生指标
    derivedMetrics.forEach(metric => {
      configs.push({ id: metric.id, visible: false, order: order++ });
    });
    
    return configs;
  });

  // 临时列配置（用于对话框中编辑）
  const [tempColumnConfigs, setTempColumnConfigs] = useState<ColumnConfig[]>(columnConfigs);

  // 排序
  type SortOrder = 'asc' | 'desc' | null;
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortOrder, setSortOrder] = useState<SortOrder>(null);

  // 分页
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  // 获取所有可选项
  const allNetworks = Array.from(new Set(mockMaterialData.map(m => m.network)));
  const allProducts = Array.from(new Set(mockMaterialData.map(m => m.app)));
  const allCountries = Array.from(new Set(mockMaterialData.map(m => m.country)));
  const allCreators = Array.from(new Set(mockMaterialData.map(m => m.creator)));
  const allMaterialTypes = Array.from(new Set(mockMaterialData.map(m => m.materialType)));
  const allProductionTypes = Array.from(new Set(mockMaterialData.map(m => m.productionType)));

  // 获取列定义
  const getColumnDef = (id: string) => {
    const dim = dimensions.find(d => d.id === id);
    if (dim) return dim;
    
    const metric = [...atomicMetrics, ...compositeMetrics, ...derivedMetrics].find(m => m.id === id);
    return metric;
  };

  // 筛选和排序数据
  const filteredData = (() => {
    let result = mockMaterialData.filter(item => {
      // 素材名称筛选
      if (appliedFilters.materialNameQuery) {
        if (!item.materialName.toLowerCase().includes(appliedFilters.materialNameQuery.toLowerCase())) {
          return false;
        }
      }

      // 渠道筛选
      if (appliedFilters.networkFilter !== 'all' && item.network !== appliedFilters.networkFilter) {
        return false;
      }

      // 产品筛选
      if (appliedFilters.productFilter !== 'all' && item.app !== appliedFilters.productFilter) {
        return false;
      }

      // 国家筛选
      if (appliedFilters.countryFilter !== 'all' && item.country !== appliedFilters.countryFilter) {
        return false;
      }

      // 制作人筛选
      if (appliedFilters.creatorFilter !== 'all' && item.creator !== appliedFilters.creatorFilter) {
        return false;
      }

      // 素材类型筛选
      if (appliedFilters.materialTypeFilter !== 'all' && item.materialType !== appliedFilters.materialTypeFilter) {
        return false;
      }

      // 制作类型筛选
      if (appliedFilters.productionTypeFilter !== 'all' && item.productionType !== appliedFilters.productionTypeFilter) {
        return false;
      }

      return true;
    });

    // 排序
    if (sortColumn && sortOrder) {
      result.sort((a, b) => {
        const aVal = (a as any)[sortColumn];
        const bVal = (b as any)[sortColumn];
        
        if (typeof aVal === 'number' && typeof bVal === 'number') {
          return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
        }
        
        const aStr = String(aVal);
        const bStr = String(bVal);
        return sortOrder === 'asc' 
          ? aStr.localeCompare(bStr) 
          : bStr.localeCompare(aStr);
      });
    }

    return result;
  })();

  // 分页
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const paginatedData = filteredData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // 处理查询
  const handleQuery = () => {
    setAppliedFilters({
      materialNameQuery,
      launchDateFrom,
      launchDateTo,
      networkFilter,
      productFilter,
      countryFilter,
      creationDateFrom,
      creationDateTo,
      creatorFilter,
      materialTypeFilter,
      productionTypeFilter,
    });
    setCurrentPage(1);
    toast.success('查询完成');
  };

  // 重置筛选
  const handleResetFilters = () => {
    setMaterialNameQuery('');
    setLaunchDateFrom(undefined);
    setLaunchDateTo(undefined);
    setNetworkFilter('all');
    setProductFilter('all');
    setCountryFilter('all');
    setCreationDateFrom(undefined);
    setCreationDateTo(undefined);
    setCreatorFilter('all');
    setMaterialTypeFilter('all');
    setProductionTypeFilter('all');
    setAppliedFilters({
      materialNameQuery: '',
      launchDateFrom: undefined,
      launchDateTo: undefined,
      networkFilter: 'all',
      productFilter: 'all',
      countryFilter: 'all',
      creationDateFrom: undefined,
      creationDateTo: undefined,
      creatorFilter: 'all',
      materialTypeFilter: 'all',
      productionTypeFilter: 'all',
    });
    setCurrentPage(1);
    toast.success('筛选条件已重置');
  };

  // 处理排序
  const handleSort = (columnId: string) => {
    if (sortColumn === columnId) {
      if (sortOrder === 'asc') {
        setSortOrder('desc');
      } else if (sortOrder === 'desc') {
        setSortColumn(null);
        setSortOrder(null);
      }
    } else {
      setSortColumn(columnId);
      setSortOrder('asc');
    }
  };

  // 打开列配置对话框
  const handleOpenConfig = () => {
    setTempColumnConfigs([...columnConfigs]);
    setIsConfigDialogOpen(true);
  };

  // 保存列配置
  const handleSaveConfig = (configs: ColumnConfig[]) => {
    setColumnConfigs(configs);
    toast.success('列配置已保存');
  };

  // 切换列可见性
  const toggleColumnVisibility = (columnId: string) => {
    setTempColumnConfigs(prev =>
      prev.map(col =>
        col.id === columnId ? { ...col, visible: !col.visible } : col
      )
    );
  };

  // 移动列
  const moveColumn = (fromIndex: number, toIndex: number) => {
    const newConfigs = [...tempColumnConfigs];
    const [movedItem] = newConfigs.splice(fromIndex, 1);
    newConfigs.splice(toIndex, 0, movedItem);
    
    // 重新分配order
    newConfigs.forEach((config, index) => {
      config.order = index;
    });
    
    setTempColumnConfigs(newConfigs);
  };

  // 导出数据
  const handleExport = () => {
    toast.success('数据导出功能开发中');
  };

  // 获取可见列（按order排序）
  const visibleColumns = columnConfigs
    .filter(col => col.visible)
    .sort((a, b) => a.order - b.order);

  // 准备列定义数据
  const columnDefs = [
    ...dimensions.map(d => ({ ...d, category: '属性' })),
    ...atomicMetrics.map(m => ({ ...m, category: '基础数据' })),
    ...compositeMetrics.map(m => ({ ...m, category: '标签' })),
    ...derivedMetrics.map(m => ({ ...m, category: '标签' })),
  ];

  // 渲染单元格值
  const renderCellValue = (columnId: string, data: MaterialData) => {
    const value = (data as any)[columnId];
    
    // 百分比格式
    if (['ctr', 'cvr'].includes(columnId)) {
      return `${value.toFixed(2)}%`;
    }
    
    // 货币格式
    if (['cost', 'cpi', 'cpm', 'ad', 'iap'].includes(columnId)) {
      return `$${value.toFixed(2)}`;
    }
    
    // 数值格式
    if (['d0_roi', 'ipm'].includes(columnId)) {
      return value.toFixed(2);
    }
    
    // 整数格式
    if (['im', 'clk', 'act'].includes(columnId)) {
      return value.toLocaleString();
    }
    
    return value;
  };

  return (
    <div className="space-y-4">
      {/* 筛选条件区域 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-6">
          {/* 第一行：投放时间、投放渠道、投放产品、投放国家 */}
          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-1">
              <label className="text-sm text-gray-600 mb-1 block">投放时间</label>
              <div className="flex gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'flex-1 justify-start text-left text-sm',
                        !launchDateFrom && 'text-gray-400'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {launchDateFrom ? format(launchDateFrom, 'yyyy-MM-dd') : '开始日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={launchDateFrom}
                      onSelect={setLaunchDateFrom}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'flex-1 justify-start text-left text-sm',
                        !launchDateTo && 'text-gray-400'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {launchDateTo ? format(launchDateTo, 'yyyy-MM-dd') : '结束日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={launchDateTo}
                      onSelect={setLaunchDateTo}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">投放渠道</label>
              <Select value={networkFilter} onValueChange={setNetworkFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allNetworks.map(network => (
                    <SelectItem key={network} value={network}>
                      {network}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">投放产品</label>
              <Select value={productFilter} onValueChange={setProductFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allProducts.map(product => (
                    <SelectItem key={product} value={product}>
                      {product}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">投放国家</label>
              <Select value={countryFilter} onValueChange={setCountryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allCountries.map(country => (
                    <SelectItem key={country} value={country}>
                      {country}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* 第二行：制作时间、制作人、素材类型、制作类型 */}
          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-1">
              <label className="text-sm text-gray-600 mb-1 block">制作时间</label>
              <div className="flex gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'flex-1 justify-start text-left text-sm',
                        !creationDateFrom && 'text-gray-400'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {creationDateFrom ? format(creationDateFrom, 'yyyy-MM-dd') : '开始日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={creationDateFrom}
                      onSelect={setCreationDateFrom}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'flex-1 justify-start text-left text-sm',
                        !creationDateTo && 'text-gray-400'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {creationDateTo ? format(creationDateTo, 'yyyy-MM-dd') : '结束日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={creationDateTo}
                      onSelect={setCreationDateTo}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">制作人</label>
              <Select value={creatorFilter} onValueChange={setCreatorFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allCreators.map(creator => (
                    <SelectItem key={creator} value={creator}>
                      {creator}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">素材类型</label>
              <Select value={materialTypeFilter} onValueChange={setMaterialTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allMaterialTypes.map(type => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">制作类型</label>
              <Select value={productionTypeFilter} onValueChange={setProductionTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allProductionTypes.map(type => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* 第三行：素材名称搜索 */}
          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-2">
              <label className="text-sm text-gray-600 mb-1 block">素材名称</label>
              <Input
                placeholder="请输入素材名称"
                value={materialNameQuery}
                onChange={(e) => setMaterialNameQuery(e.target.value)}
              />
            </div>
          </div>

          {/* 操作按钮 */}
          <div className="flex justify-end items-center">
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleResetFilters}>
                <RotateCcw className="mr-2 h-4 w-4" />
                重置
              </Button>
              <Button onClick={handleQuery}>查询</Button>
            </div>
          </div>
        </div>
      </div>

      {/* 数据表格区域 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-4">
          {/* 工具栏 */}
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-600">
              共 {filteredData.length} 条素材数据
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleExport}>
                <Download className="mr-2 h-4 w-4" />
                导出数据
              </Button>
              <Button variant="outline" size="sm" onClick={handleOpenConfig}>
                <Settings className="mr-2 h-4 w-4" />
                列配置
              </Button>
            </div>
          </div>

          {/* 表格 */}
          <div className="border border-gray-200 rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  {/* 素材名称列（固定） */}
                  <TableHead
                    className="sticky left-0 bg-gray-50 z-10 min-w-[300px] cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => handleSort('materialName')}
                  >
                    <div className="flex items-center">
                      素材名
                      {sortColumn === 'materialName' ? (
                        sortOrder === 'asc' ? (
                          <ArrowUp className="ml-2 h-4 w-4 inline-block" />
                        ) : (
                          <ArrowDown className="ml-2 h-4 w-4 inline-block" />
                        )
                      ) : (
                        <ArrowUpDown className="ml-2 h-4 w-4 inline-block text-gray-400" />
                      )}
                    </div>
                  </TableHead>

                  {/* 动态列 */}
                  {visibleColumns.map(col => {
                    const colDef = getColumnDef(col.id);
                    if (!colDef) return null;

                    return (
                      <TableHead
                        key={col.id}
                        className="cursor-pointer select-none hover:bg-gray-100 min-w-[120px]"
                        onClick={() => handleSort(col.id)}
                      >
                        <div className="flex items-center">
                          {colDef.name}
                          {sortColumn === col.id ? (
                            sortOrder === 'asc' ? (
                              <ArrowUp className="ml-2 h-4 w-4 inline-block" />
                            ) : (
                              <ArrowDown className="ml-2 h-4 w-4 inline-block" />
                            )
                          ) : (
                            <ArrowUpDown className="ml-2 h-4 w-4 inline-block text-gray-400" />
                          )}
                        </div>
                      </TableHead>
                    );
                  })}
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedData.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={visibleColumns.length + 1}
                      className="text-center py-12 text-gray-500"
                    >
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-4xl">📊</div>
                        <div>暂无数据</div>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedData.map((row) => (
                    <TableRow key={row.id} className="hover:bg-gray-50">
                      {/* 素材名称列（固定） */}
                      <TableCell className="sticky left-0 bg-white font-medium">
                        {row.materialName}
                      </TableCell>

                      {/* 动态列 */}
                      {visibleColumns.map(col => (
                        <TableCell key={col.id}>
                          {renderCellValue(col.id, row)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* 分页 */}
          {filteredData.length > 0 && (
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                第 {(currentPage - 1) * itemsPerPage + 1}-
                {Math.min(currentPage * itemsPerPage, filteredData.length)} 条/共{' '}
                {filteredData.length} 条
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  上一页
                </Button>
                <span className="text-sm">
                  第 {currentPage} 页 / 共 {totalPages} 页
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  下一页
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 列配置对话框 */}
      <ColumnConfigDialog
        open={isConfigDialogOpen}
        onOpenChange={setIsConfigDialogOpen}
        columnDefs={columnDefs}
        columnConfigs={columnConfigs}
        onSave={handleSaveConfig}
      />
    </div>
  );
}