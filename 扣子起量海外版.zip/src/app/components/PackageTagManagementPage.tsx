import { useState, useMemo } from 'react';
import { Plus, Search, Edit2, Power, PowerOff, History } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { toast } from 'sonner';
import { cn } from './ui/utils';
import { packageTags as initialPackageTags, packageTagCategories as categories, type PackageTagCategory } from '../lib/packageTags';

// 标签类型定义
export type TagStatus = 'active' | 'inactive';

export interface Tag {
  id: string;
  name: string;
  description: string;
  category: PackageTagCategory;
  status: TagStatus;
  usageCount: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface TagOperation {
  id: string;
  action: '创建' | '编辑' | '启用' | '停用';
  tagName: string;
  tagCategory: PackageTagCategory;
  operator: string;
  timestamp: string;
  details?: string;
}

// 从共享数据源初始化标签数据，添加额外的字段
const initializeTags = (): Tag[] => {
  const now = new Date().toISOString();
  return initialPackageTags.map((tag, index) => ({
    ...tag,
    usageCount: Math.floor(Math.random() * 50),
    createdBy: '系统管理员',
    createdAt: now,
    updatedAt: now,
  }));
};

// 模拟操作历史数据
const initializeOperations = (): TagOperation[] => {
  const operations: TagOperation[] = [];
  const actions: Array<'创建' | '编辑' | '启用' | '停用'> = ['创建', '编辑', '启用', '停用'];
  const operators = ['张三', '李四', '王五', '系统管理员'];
  
  for (let i = 1; i <= 20; i++) {
    const action = actions[Math.floor(Math.random() * actions.length)];
    const category = categories[Math.floor(Math.random() * categories.length)];
    
    operations.push({
      id: `op-${i}`,
      action,
      tagName: `测试素材包标签-${i}`,
      tagCategory: category,
      operator: operators[Math.floor(Math.random() * operators.length)],
      timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      details: action === '编辑' ? '修改了标签描述' : undefined,
    });
  }
  
  return operations.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
};

export function PackageTagManagementPage() {
  const [selectedCategory, setSelectedCategory] = useState<PackageTagCategory>('前贴');
  const [searchQuery, setSearchQuery] = useState('');
  const [tags, setTags] = useState<Tag[]>(initializeTags());
  const [operations, setOperations] = useState<TagOperation[]>(initializeOperations());
  const [showHistory, setShowHistory] = useState(false);
  
  // 对话框状态
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);
  
  // 表单状态
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: selectedCategory,
  });
  
  // 过滤和搜索标签
  const filteredTags = useMemo(() => {
    return tags.filter(tag => {
      const matchesCategory = tag.category === selectedCategory;
      const matchesSearch = searchQuery === '' || 
        tag.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tag.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [tags, selectedCategory, searchQuery]);
  
  // 统计数据
  const categoryStats = useMemo(() => {
    const stats: Record<string, { total: number; active: number }> = {};
    categories.forEach(cat => {
      const categoryTags = tags.filter(t => t.category === cat);
      stats[cat] = {
        total: categoryTags.length,
        active: categoryTags.filter(t => t.status === 'active').length,
      };
    });
    return stats;
  }, [tags]);
  
  // 处理添加标签
  const handleAddTag = () => {
    if (!formData.name.trim()) {
      toast.error('请输入标签名称');
      return;
    }
    
    const newTag: Tag = {
      id: `pkg-tag-${Date.now()}`,
      name: formData.name,
      description: formData.description,
      category: formData.category as PackageTagCategory,
      status: 'active',
      usageCount: 0,
      createdBy: '当前用户',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    setTags([...tags, newTag]);
    
    // 添加操作记录
    const newOperation: TagOperation = {
      id: `op-${Date.now()}`,
      action: '创建',
      tagName: formData.name,
      tagCategory: formData.category as PackageTagCategory,
      operator: '当前用户',
      timestamp: new Date().toISOString(),
    };
    setOperations([newOperation, ...operations]);
    
    toast.success('素材包标签创建成功');
    setIsAddDialogOpen(false);
    setFormData({ name: '', description: '', category: selectedCategory });
  };
  
  // 处理编辑标签
  const handleEditTag = () => {
    if (!editingTag || !formData.name.trim()) {
      toast.error('请输入标签名称');
      return;
    }
    
    const updateTags = tags.map(tag => 
      tag.id === editingTag.id 
        ? { ...tag, name: formData.name, description: formData.description, updatedAt: new Date().toISOString() }
        : tag
    );
    
    setTags(updateTags);
    
    // 添加操作记录
    const newOperation: TagOperation = {
      id: `op-${Date.now()}`,
      action: '编辑',
      tagName: formData.name,
      tagCategory: editingTag.category,
      operator: '当前用户',
      timestamp: new Date().toISOString(),
      details: '修改了标签信息',
    };
    setOperations([newOperation, ...operations]);
    
    toast.success('素材包标签更新成功');
    setIsEditDialogOpen(false);
    setEditingTag(null);
    setFormData({ name: '', description: '', category: selectedCategory });
  };
  
  // 切换标签状态
  const handleToggleStatus = (tag: Tag) => {
    const newStatus: TagStatus = tag.status === 'active' ? 'inactive' : 'active';
    
    const updateTags = tags.map(t => 
      t.id === tag.id 
        ? { ...t, status: newStatus, updatedAt: new Date().toISOString() }
        : t
    );
    
    setTags(updateTags);
    
    // 添加操作记录
    const newOperation: TagOperation = {
      id: `op-${Date.now()}`,
      action: newStatus === 'active' ? '启用' : '停用',
      tagName: tag.name,
      tagCategory: tag.category,
      operator: '当前用户',
      timestamp: new Date().toISOString(),
    };
    setOperations([newOperation, ...operations]);
    
    toast.success(`标签已${newStatus === 'active' ? '启用' : '停用'}`);
  };
  
  // 打开编辑对话框
  const openEditDialog = (tag: Tag) => {
    setEditingTag(tag);
    setFormData({
      name: tag.name,
      description: tag.description,
      category: tag.category,
    });
    setIsEditDialogOpen(true);
  };
  
  // 打开添加对话框
  const openAddDialog = () => {
    setFormData({
      name: '',
      description: '',
      category: selectedCategory,
    });
    setIsAddDialogOpen(true);
  };
  
  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">素材包标签管理</h1>
          <p className="text-sm text-gray-500 mt-1">
            管理素材包标签，支持增删改查及操作记录追溯
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowHistory(!showHistory)}
        >
          <History className="h-4 w-4 mr-2" />
          {showHistory ? '隐藏' : '显示'}操作历史
        </Button>
      </div>
      
      <div className="grid grid-cols-12 gap-6">
        {/* 左侧分类导航 */}
        <div className="col-span-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">标签分类</CardTitle>
              <CardDescription className="text-xs">
                共 {categories.length} 个分类
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[600px] overflow-y-auto">
                <div className="space-y-1 p-2">
                  {categories.map(category => {
                    const stats = categoryStats[category] || { total: 0, active: 0 };
                    return (
                      <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={cn(
                          'w-full text-left px-3 py-2.5 rounded-md transition-colors',
                          'flex items-center justify-between group',
                          selectedCategory === category
                            ? 'bg-blue-50 text-blue-700'
                            : 'hover:bg-gray-100 text-gray-700'
                        )}
                      >
                        <span className="font-medium">{category}</span>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs">
                            {stats.active}/{stats.total}
                          </Badge>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* 右侧内容区 */}
        <div className={cn(
          'transition-all duration-300',
          showHistory ? 'col-span-5' : 'col-span-9'
        )}>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>{selectedCategory}</CardTitle>
                  <CardDescription>
                    共 {filteredTags.length} 个标签
                  </CardDescription>
                </div>
                <Button onClick={openAddDialog}>
                  <Plus className="h-4 w-4 mr-2" />
                  添加标签
                </Button>
              </div>
              {/* 搜索框 */}
              <div className="mt-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="搜索标签名称或描述..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>标签名称</TableHead>
                      <TableHead>说明</TableHead>
                      <TableHead className="text-center">使用次数</TableHead>
                      <TableHead className="text-center">状态</TableHead>
                      <TableHead>创建人</TableHead>
                      <TableHead>创建时间</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTags.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                          暂无标签数据
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredTags.map(tag => (
                        <TableRow key={tag.id}>
                          <TableCell className="font-medium">{tag.name}</TableCell>
                          <TableCell className="max-w-xs truncate text-gray-600 text-sm">
                            {tag.description}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant="outline">{tag.usageCount}</Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant={tag.status === 'active' ? 'default' : 'secondary'}>
                              {tag.status === 'active' ? '启用' : '停用'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-gray-600">{tag.createdBy}</TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {new Date(tag.createdAt).toLocaleDateString('zh-CN')}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openEditDialog(tag)}
                              >
                                <Edit2 className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleToggleStatus(tag)}
                              >
                                {tag.status === 'active' ? (
                                  <PowerOff className="h-3.5 w-3.5 text-red-500" />
                                ) : (
                                  <Power className="h-3.5 w-3.5 text-green-500" />
                                )}
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* 操作历史面板 */}
        {showHistory && (
          <div className="col-span-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">操作历史</CardTitle>
                <CardDescription className="text-xs">
                  最近 {operations.length} 条操作记录
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-[600px] overflow-y-auto">
                  <div className="space-y-3 p-4">
                    {operations.map(op => (
                      <div
                        key={op.id}
                        className="border-l-2 border-blue-200 pl-4 pb-3"
                      >
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Badge
                                variant={
                                  op.action === '创建' ? 'default' :
                                  op.action === '编辑' ? 'secondary' :
                                  op.action === '启用' ? 'default' : 'destructive'
                                }
                                className="text-xs"
                              >
                                {op.action}
                              </Badge>
                              <span className="text-sm font-medium">{op.tagName}</span>
                            </div>
                            <div className="text-xs text-gray-500 space-y-0.5">
                              <div>分类：{op.tagCategory}</div>
                              <div>操作人：{op.operator}</div>
                              {op.details && <div className="text-gray-400">备注：{op.details}</div>}
                            </div>
                          </div>
                        </div>
                        <div className="text-xs text-gray-400 mt-2">
                          {new Date(op.timestamp).toLocaleString('zh-CN', {
                            month: '2-digit',
                            day: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
      
      {/* 添加标签对话框 */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>添加素材包标签</DialogTitle>
            <DialogDescription>
              为 {selectedCategory} 分类添加新标签
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="tag-name">标签名称 *</Label>
              <Input
                id="tag-name"
                placeholder="请输入标签名称"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tag-category">所属分类</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value as PackageTagCategory })}
              >
                <SelectTrigger id="tag-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="tag-description">标签说明</Label>
              <Textarea
                id="tag-description"
                placeholder="请输入标签说明（选填）"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleAddTag}>
              确认添加
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* 编辑标签对话框 */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>编辑素材包标签</DialogTitle>
            <DialogDescription>
              修改标签信息
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-tag-name">标签名称 *</Label>
              <Input
                id="edit-tag-name"
                placeholder="请输入标签名称"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-tag-description">标签说明</Label>
              <Textarea
                id="edit-tag-description"
                placeholder="请输入标签说明（选填）"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleEditTag}>
              确认修改
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}