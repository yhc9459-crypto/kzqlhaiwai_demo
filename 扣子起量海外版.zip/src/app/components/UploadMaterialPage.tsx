import { useState, useCallback } from 'react';
import { MaterialType } from '../types/material';
import { mockProductMappings } from '../lib/mockData';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './ui/dialog';
import { toast } from 'sonner';
import { Upload, X, FileVideo, FileImage, FileCode, AlertCircle } from 'lucide-react';
import { cn } from './ui/utils';

interface UploadMaterialPageProps {
  materialType: MaterialType;
  onBack: () => void;
}

interface UploadFile {
  id: string;
  file: File;
  name: string;
  size: number;
  progress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
}

// 当前登录用户
const CURRENT_USER = '张三';

// 创意人列表
const CREATIVE_STAFF = [
  '设计师本人', // 新增设计师本人选项
  '薛聪',
  '范依依',
  '于慧琛',
  '增长小助手3',
  '曹婉婷',
  '马倩茹',
  '孟豪',
  '郭禧辰',
  '李楠',
];

// 素材标签选项
const MATERIAL_TAGS = [
  '原创',
  '纯剪辑/去logo',
  '拼接/混剪',
  '原创-片头',
  '改尺寸/语言',
  'H5试玩',
  'AI数字人',
  'AI生图',
];

// Mock 素材包列表（包含完整信息）
const mockMaterialPackages = [
  { 
    id: '1', 
    number: 'MP-20260120-0001', 
    name: 'Bingo Bonus 新年活动素材包',
    product: 'Bingo Bonus',
    productionType: '0-1制作' as const,
    creativePerson: '薛聪',
    tags: ['原创', 'H5试玩']
  },
  { 
    id: '2', 
    number: 'MP-20260118-0002', 
    name: 'Yazzy GO! 海外推广包',
    product: 'Yazzy GO!',
    productionType: '1-N制作' as const,
    creativePerson: '范依依',
    tags: ['纯剪辑/去logo', '改尺寸/语言']
  },
  { 
    id: '3', 
    number: 'MP-20260115-0003', 
    name: 'Fishberry Story 情人节素材',
    product: 'Fishberry Story',
    productionType: '0-1制作' as const,
    creativePerson: '于慧琛',
    tags: ['原创', 'AI生图']
  },
];

export function UploadMaterialPage({ materialType, onBack }: UploadMaterialPageProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([]);
  const [tags, setTags] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  // 素材包选择
  const [materialPackage, setMaterialPackage] = useState<string>('');
  
  // 从素材包继承的信息（不可编辑）
  const selectedPackageInfo = mockMaterialPackages.find(pkg => pkg.id === materialPackage);

  // 获取素材类型配置
  const getTypeConfig = () => {
    switch (materialType) {
      case 'video':
        return {
          title: '上传视频',
          icon: FileVideo,
          accept: '.mp4,.mov',
          maxSize: 1024, // 1GB in MB
          formats: 'mp4、mov',
          description: '素材上传需对尺寸、码率等进行分类，约1-3分钟可用于投放',
        };
      case 'image':
        return {
          title: '上传图片',
          icon: FileImage,
          accept: '.jpg,.jpeg,.png,.gif',
          maxSize: 10, // 10MB
          formats: 'jpg、jpeg、png、gif',
          description: '图片尺寸建议不小于800x600，支持常见图片格式',
        };
      case 'html5':
        return {
          title: '上传H5',
          icon: FileCode,
          accept: '.zip',
          maxSize: 50, // 50MB
          formats: 'zip',
          description: 'H5素材需打包为zip格式，包含完整的HTML、CSS、JS文件',
        };
    }
  };

  const typeConfig = getTypeConfig();
  const TypeIcon = typeConfig.icon;

  // 文件大小格式化
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  // 验证文件
  const validateFile = (file: File): string | null => {
    // 检查文件大小
    const maxSizeInBytes = typeConfig.maxSize * 1024 * 1024;
    if (file.size > maxSizeInBytes) {
      return `文件大小不能超过${typeConfig.maxSize >= 1024 ? (typeConfig.maxSize / 1024) + 'G' : typeConfig.maxSize + 'MB'}`;
    }

    // 检查文件类型
    const fileExt = '.' + file.name.split('.').pop()?.toLowerCase();
    const acceptedExts = typeConfig.accept.split(',');
    if (!acceptedExts.includes(fileExt)) {
      return `只支持${typeConfig.formats}格式`;
    }

    return null;
  };

  // 处理文件选择
  const handleFileSelect = useCallback((files: FileList | null) => {
    if (!files || files.length === 0) return;

    const fileArray = Array.from(files);
    
    // 检查文件数量限制
    if (uploadFiles.length + fileArray.length > 100) {
      toast.error('一次最多上传100个文件');
      return;
    }

    const newUploadFiles: UploadFile[] = [];

    fileArray.forEach((file) => {
      const error = validateFile(file);
      newUploadFiles.push({
        id: `file_${Date.now()}_${Math.random()}`,
        file,
        name: file.name,
        size: file.size,
        progress: 0,
        status: error ? 'error' : 'pending',
        error: error || undefined,
      });
    });

    setUploadFiles((prev) => [...prev, ...newUploadFiles]);

    const errorCount = newUploadFiles.filter((f) => f.status === 'error').length;
    if (errorCount > 0) {
      toast.error(`${errorCount}个文件验证失败，请检查文件格式和大小`);
    } else {
      toast.success(`已添加${newUploadFiles.length}个文件`);
    }
  }, [uploadFiles.length, typeConfig]);

  // 拖拽处理
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  }, [handleFileSelect]);

  // 移除文件
  const handleRemoveFile = (fileId: string) => {
    setUploadFiles((prev) => prev.filter((f) => f.id !== fileId));
    toast.info('已移除文件');
  };

  // 表单验证
  const validateForm = (): boolean => {
    if (!materialPackage) {
      toast.error('请选择素材包');
      return false;
    }
    if (!selectedPackageInfo?.product) {
      toast.error('请选择归属产品');
      return false;
    }
    if (!selectedPackageInfo?.creativePerson) {
      toast.error('请选择创意人');
      return false;
    }
    if (!tags) {
      toast.error('请选择素材标签');
      return false;
    }
    if (uploadFiles.length === 0) {
      toast.error('请至少上传一个文件');
      return false;
    }
    const hasError = uploadFiles.some((f) => f.status === 'error');
    if (hasError) {
      toast.error('存在验证失败的文件，请移除后再提交');
      return false;
    }
    return true;
  };

  // 模拟上传
  const simulateUpload = (fileId: string): Promise<void> => {
    return new Promise((resolve) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 30;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          setUploadFiles((prev) =>
            prev.map((f) =>
              f.id === fileId
                ? { ...f, progress: 100, status: 'success' as const }
                : f
            )
          );
          resolve();
        } else {
          setUploadFiles((prev) =>
            prev.map((f) =>
              f.id === fileId
                ? { ...f, progress: Math.round(progress), status: 'uploading' as const }
                : f
            )
          );
        }
      }, 200);
    });
  };

  // 提交上传
  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsUploading(true);

    try {
      // 模拟并发上传
      const pendingFiles = uploadFiles.filter((f) => f.status === 'pending');
      await Promise.all(pendingFiles.map((f) => simulateUpload(f.id)));

      toast.success(`成功上传${uploadFiles.length}个素材文件`);
      
      // 延迟后返回
      setTimeout(() => {
        onBack();
      }, 1000);
    } catch (error) {
      toast.error('上传失败，请重试');
      setIsUploading(false);
    }
  };

  // 取消上传
  const handleCancel = () => {
    if (uploadFiles.length > 0 || tags) {
      if (confirm('确定要取消上传吗？已填写的信息将丢失。')) {
        onBack();
      }
    } else {
      onBack();
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* 顶部标题 */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-medium">{typeConfig.title}</h1>
          <Button variant="ghost" size="sm" onClick={handleCancel}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* 内容区域 */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* 上传区域 */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="space-y-4">
              <div>
                <Label className="text-red-600">* 上传文件：</Label>
              </div>

              {/* 拖拽上传区 */}
              <div
                className={cn(
                  'border-2 border-dashed rounded-lg p-12 text-center transition-colors',
                  isDragging
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-300 hover:border-gray-400'
                )}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <div className="flex flex-col items-center gap-4">
                  <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center">
                    <Upload className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-gray-600 mb-2">
                      将文件拖到此处{' '}
                      <label className="text-blue-600 cursor-pointer hover:text-blue-700">
                        点击此处上传
                        <input
                          type="file"
                          multiple
                          accept={typeConfig.accept}
                          className="hidden"
                          onChange={(e) => handleFileSelect(e.target.files)}
                          disabled={isUploading}
                        />
                      </label>
                    </p>
                    <div className="text-sm text-gray-500 space-y-1">
                      <p>1. 支持上传文件数文件数，一次上传文件个数不超过100个</p>
                      <p>
                        2. 支持{materialType === 'video' ? '视频' : materialType === 'image' ? '图片' : 'H5'}格式：
                        {typeConfig.formats}，单文件大小不超过
                        {typeConfig.maxSize >= 1024
                          ? `${typeConfig.maxSize / 1024}G`
                          : `${typeConfig.maxSize}MB`}
                      </p>
                      <p>3. {typeConfig.description}</p>
                    </div>
                  </div>
                  <Button
                    variant="default"
                    onClick={() => document.querySelector('input[type="file"]')?.dispatchEvent(new MouseEvent('click'))}
                    disabled={isUploading}
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    上传文件
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* 表单信息 */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            {/* 第一行：素材包选择 */}
            <div className="space-y-2 mb-4">
              <Label className="text-red-600">* 所属素材包：</Label>
              <Select
                value={materialPackage}
                onValueChange={setMaterialPackage}
                disabled={isUploading}
              >
                <SelectTrigger>
                  <SelectValue placeholder="请选择素材包" />
                </SelectTrigger>
                <SelectContent>
                  {mockMaterialPackages.map((pkg) => (
                    <SelectItem key={pkg.id} value={pkg.id}>
                      {pkg.number} - {pkg.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* 从素材包继承的信息展示（只读） */}
            {selectedPackageInfo && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <div className="text-sm text-gray-700 space-y-2">
                  <div className="flex items-center gap-6">
                    <span><strong>所属产品：</strong>{selectedPackageInfo.product}</span>
                    <span><strong>制作类型：</strong>{selectedPackageInfo.productionType}</span>
                    <span><strong>关联创意人：</strong>{selectedPackageInfo.creativePerson}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <strong>素材包标签：</strong>
                    {selectedPackageInfo.tags.map((tag, index) => (
                      <span key={index} className="px-2 py-0.5 bg-white text-blue-700 border border-blue-300 rounded text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 素材标签选择 */}
            <div className="space-y-2">
              <Label className="text-red-600">* 素材标签：</Label>
              <Select
                value={tags}
                onValueChange={setTags}
                disabled={isUploading || !materialPackage}
              >
                <SelectTrigger>
                  <SelectValue placeholder={materialPackage ? "请选择素材标签" : "请先选择素材包"} />
                </SelectTrigger>
                <SelectContent>
                  {MATERIAL_TAGS.map((tag) => (
                    <SelectItem key={tag} value={tag}>
                      {tag}
                      {selectedPackageInfo?.tags.includes(tag) && (
                        <span className="ml-2 text-xs text-gray-500">(已在素材包中)</span>
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedPackageInfo && tags && !selectedPackageInfo.tags.includes(tags) && (
                <p className="text-xs text-amber-600 mt-1">
                  ⚠️ 该标签不在素材包标签中，将作为该素材的独有标签记录
                </p>
              )}
            </div>
          </div>

          {/* 文件列表 */}
          {uploadFiles.length > 0 && (
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>已选择文件（{uploadFiles.length}/100）</Label>
                  {!isUploading && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setUploadFiles([]);
                        toast.info('已清空文件列表');
                      }}
                    >
                      清空
                    </Button>
                  )}
                </div>
                <div className="border border-gray-200 rounded-lg divide-y max-h-96 overflow-y-auto">
                  {uploadFiles.map((uploadFile) => (
                    <div
                      key={uploadFile.id}
                      className="p-3 flex items-center gap-3 hover:bg-gray-50"
                    >
                      <div className="flex-shrink-0">
                        <TypeIcon className="h-8 w-8 text-gray-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {uploadFile.name}
                          </p>
                          <span className="text-xs text-gray-500 ml-2">
                            {formatFileSize(uploadFile.size)}
                          </span>
                        </div>
                        {uploadFile.status === 'error' ? (
                          <div className="flex items-center gap-1 text-red-600">
                            <AlertCircle className="h-3 w-3" />
                            <span className="text-xs">{uploadFile.error}</span>
                          </div>
                        ) : uploadFile.status === 'uploading' ? (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-xs text-gray-500">
                              <span>上传中...</span>
                              <span>{uploadFile.progress}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-1.5">
                              <div
                                className="bg-blue-600 h-1.5 rounded-full transition-all"
                                style={{ width: `${uploadFile.progress}%` }}
                              />
                            </div>
                          </div>
                        ) : uploadFile.status === 'success' ? (
                          <p className="text-xs text-green-600">上传成功</p>
                        ) : (
                          <p className="text-xs text-gray-500">等待上传</p>
                        )}
                      </div>
                      {!isUploading && uploadFile.status !== 'uploading' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveFile(uploadFile.id)}
                          className="flex-shrink-0"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 底部操作按钮 */}
      <div className="bg-white border-t border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto flex justify-end gap-3">
          <Button variant="outline" onClick={handleCancel} disabled={isUploading}>
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={isUploading}>
            {isUploading ? '上传中...' : '上传并保存'}
          </Button>
        </div>
      </div>
    </div>
  );
}