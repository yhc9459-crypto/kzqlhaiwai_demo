import { useState, useMemo } from 'react';
import { Material, MaterialType } from '../types/material';
import { mockMaterials, mockProductMappings } from '../lib/mockData';
import { getMaterialTypeName } from '../lib/xmpService';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Alert, AlertDescription } from './ui/alert';
import { toast } from 'sonner';
import { ArrowLeft, AlertCircle, CloudUpload, Image as ImageIcon, Video, Play, Code } from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { cn } from './ui/utils';

interface CreateTaskPageProps {
  onBack: () => void;
  defaultMaterialType?: MaterialType | null;
  packageId?: string | null; // 新增：素材包ID参数
}

export function CreateTaskPage({ onBack, defaultMaterialType, packageId }: CreateTaskPageProps) {
  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [selectedMaterialType, setSelectedMaterialType] = useState<MaterialType | ''>(defaultMaterialType || '');
  const [selectedMaterialIds, setSelectedMaterialIds] = useState<Set<string>>(new Set());
  // 删除 pushChannel 状态变量
  const [materials] = useState<Material[]>(mockMaterials);

  // 判断是否为素材包推送模式
  const isPackageMode = !!packageId;

  // 获取素材包信息
  const packageInfo = useMemo(() => {
    if (!isPackageMode) return null;
    const packageMaterials = materials.filter(m => m.packageNumber && m.packageNumber.includes('MP-20260120-0001')); // Mock: 根据packageId获取
    if (packageMaterials.length === 0) return null;
    return {
      packageNumber: packageMaterials[0].packageNumber,
      packageName: packageMaterials[0].packageName,
      product: packageMaterials[0].product,
    };
  }, [isPackageMode, materials]);

  // F2: 只展示未推送的素材 + 新增：只展示审核通过的素材
  const availableMaterials = useMemo(() => {
    if (isPackageMode) {
      // 素材包模式：显示该素材包内所有未推送且审核通过的素材
      return materials.filter(
        (m) =>
          m.packageNumber === packageInfo?.packageNumber &&
          m.pushStatus === 'not_pushed' &&
          m.reviewStatus === 'approved' // 新增：只显示审核通过的素材
      );
    } else {
      // 普通模式：需要选择产品和素材类型
      if (!selectedProduct || !selectedMaterialType) return [];

      const productName = mockProductMappings.find((p) => p.productId === selectedProduct)
        ?.productName;

      return materials.filter(
        (m) =>
          m.product === productName &&
          m.type === selectedMaterialType &&
          m.pushStatus === 'not_pushed' && // F2: 只显示未推送的素材
          m.reviewStatus === 'approved' // 新增：只显示审核通过的素材
      );
    }
  }, [materials, selectedProduct, selectedMaterialType, isPackageMode, packageInfo]);

  // 按类型分组素材（仅在素材包模式下使用）
  const groupedMaterials = useMemo(() => {
    if (!isPackageMode) return null;
    
    const video = availableMaterials.filter(m => m.type === 'video');
    const image = availableMaterials.filter(m => m.type === 'image');
    const html5 = availableMaterials.filter(m => m.type === 'html5');
    
    return { video, image, html5 };
  }, [isPackageMode, availableMaterials]);

  // 统计已选素材的类型数量
  const selectedCounts = useMemo(() => {
    const selected = Array.from(selectedMaterialIds).map(id => 
      availableMaterials.find(m => m.id === id)
    ).filter(Boolean) as Material[];
    
    return {
      video: selected.filter(m => m.type === 'video').length,
      image: selected.filter(m => m.type === 'image').length,
      html5: selected.filter(m => m.type === 'html5').length,
      total: selected.length,
    };
  }, [selectedMaterialIds, availableMaterials]);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const ids = new Set(availableMaterials.slice(0, 50).map((m) => m.id)); // F2: 最多50条
      setSelectedMaterialIds(ids);
    } else {
      setSelectedMaterialIds(new Set());
    }
  };

  // 新增：按类型全选（素材包模式）
  const handleSelectAllByType = (type: MaterialType, checked: boolean) => {
    const typeMateirals = availableMaterials.filter(m => m.type === type);
    const newSelected = new Set(selectedMaterialIds);
    
    if (checked) {
      typeMateirals.forEach(m => {
        if (newSelected.size < 50) {
          newSelected.add(m.id);
        }
      });
      if (newSelected.size >= 50) {
        toast.error('单次最多只能选择50条素材');
      }
    } else {
      typeMateirals.forEach(m => newSelected.delete(m.id));
    }
    
    setSelectedMaterialIds(newSelected);
  };

  const handleSelectOne = (id: string, checked: boolean) => {
    const newSelected = new Set(selectedMaterialIds);
    if (checked) {
      // F2: 限制最多50条
      if (newSelected.size >= 50) {
        toast.error('单次最多只能选择50条素材');
        return;
      }
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedMaterialIds(newSelected);
  };

  const handleCreateTask = () => {
    // F2: 验证选择数量
    if (selectedMaterialIds.size === 0) {
      toast.error('请至少选择一条素材');
      return;
    }

    if (selectedMaterialIds.size > 50) {
      toast.error('单次最多只能选择50条素材');
      return;
    }

    // 创建推送任务（按类型分别创建）
    const taskMessages: string[] = [];
    if (selectedCounts.video > 0) {
      taskMessages.push(`视频推送任务：${selectedCounts.video}个素材`);
    }
    if (selectedCounts.image > 0) {
      taskMessages.push(`图片推送任务：${selectedCounts.image}个素材`);
    }
    if (selectedCounts.html5 > 0) {
      taskMessages.push(`HTML5推送任务：${selectedCounts.html5}个素材`);
    }

    toast.success(
      <div>
        <div className="font-medium">推送任务创建成功！</div>
        <div className="text-sm mt-1">
          {taskMessages.map((msg, index) => (
            <div key={index}>• {msg}</div>
          ))}
        </div>
      </div>
    );
    
    onBack();
  };

  const canSubmit = isPackageMode 
    ? selectedMaterialIds.size > 0
    : selectedProduct && 
      selectedMaterialType && 
      selectedMaterialIds.size > 0;

  // 获取缩略图URL（根据素材ID生成不同的占位图）
  const getThumbnailUrl = (material: Material) => {
    const seed = material.id;
    const width = 80;
    const height = 60;
    
    if (material.type === 'video') {
      // 视频缩略图使用nature主题
      return `https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    } else if (material.type === 'image') {
      // 图片缩略图使用photo主题
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    }
    return '';
  };

  // 判断是否显示缩略图列
  const shouldShowThumbnail = selectedMaterialType === 'video' || selectedMaterialType === 'image';

  // 渲染素材类型图标
  const getTypeIcon = (type: MaterialType) => {
    switch (type) {
      case 'video':
        return <Play className="w-4 h-4 text-purple-600" />;
      case 'image':
        return <ImageIcon className="w-4 h-4 text-blue-600" />;
      case 'html5':
        return <Code className="w-4 h-4 text-green-600" />;
    }
  };

  // 渲染素材类型标签
  const getTypeLabel = (type: MaterialType) => {
    switch (type) {
      case 'video':
        return '视频素材';
      case 'image':
        return '图片素材';
      case 'html5':
        return 'HTML5素材';
    }
  };

  // 渲染分组素材列表（素材包模式）
  const renderGroupedMaterials = () => {
    if (!groupedMaterials) return null;

    const types: MaterialType[] = ['video', 'image', 'html5'];
    
    return (
      <div className="space-y-4">
        {types.map(type => {
          const materials = groupedMaterials[type];
          if (materials.length === 0) return null;

          const selectedInType = materials.filter(m => selectedMaterialIds.has(m.id)).length;

          return (
            <div key={type} className="border border-gray-200 rounded-lg overflow-hidden">
              {/* 类型标题栏 */}
              <div className="bg-gray-50 px-4 py-3 flex items-center justify-between border-b border-gray-200">
                <div className="flex items-center gap-3">
                  <Checkbox
                    checked={selectedInType === materials.length && materials.length > 0}
                    onCheckedChange={(checked) => handleSelectAllByType(type, !!checked)}
                    disabled={materials.length === 0}
                  />
                  <div className="flex items-center gap-2">
                    {getTypeIcon(type)}
                    <span className="font-medium text-gray-900">{getTypeLabel(type)}</span>
                    <span className="text-sm text-gray-500">
                      ({selectedInType}/{materials.length})
                    </span>
                  </div>
                </div>
              </div>

              {/* 素材列表 */}
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="w-12"></TableHead>
                    {(type === 'video' || type === 'image') && <TableHead className="w-24">缩略图</TableHead>}
                    <TableHead>素材名称</TableHead>
                    <TableHead>设计师</TableHead>
                    <TableHead>素材组</TableHead>
                    <TableHead>创建时间</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {materials.map((material) => (
                    <TableRow key={material.id} className="hover:bg-gray-50">
                      <TableCell>
                        <Checkbox
                          checked={selectedMaterialIds.has(material.id)}
                          onCheckedChange={(checked) =>
                            handleSelectOne(material.id, !!checked)
                          }
                          disabled={
                            !selectedMaterialIds.has(material.id) &&
                            selectedMaterialIds.size >= 50
                          }
                        />
                      </TableCell>
                      {(type === 'video' || type === 'image') && (
                        <TableCell>
                          <div className="relative w-20 h-15 bg-gray-100 rounded overflow-hidden">
                            <img
                              src={getThumbnailUrl(material)}
                              alt={material.name}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                              {material.type === 'video' ? (
                                <Video className="h-6 w-6 text-white" />
                              ) : (
                                <ImageIcon className="h-6 w-6 text-white" />
                              )}
                            </div>
                          </div>
                        </TableCell>
                      )}
                      <TableCell>{material.name}</TableCell>
                      <TableCell>{material.designer}</TableCell>
                      <TableCell>{material.materialGroup || '-'}</TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {format(new Date(material.createdAt), 'yyyy-MM-dd HH:mm', {
                          locale: zhCN,
                        })}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="mb-6">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              返回
            </Button>
            <h2 className="text-lg font-medium">
              {isPackageMode ? '批量推送素材' : '创建推送任务'}
            </h2>
          </div>

          {isPackageMode ? (
            // 素材包模式的提示和信息
            <>
              <Alert className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  从素材包 <span className="font-medium text-blue-600">{packageInfo?.packageName}</span> 推送素材。系统已自动筛选未推送的素材，请勾选需要推送的素材。单次最多可选择50条素材。
                </AlertDescription>
              </Alert>

              {/* 选择数量提示和按钮 */}
              <div className="mb-4 flex items-center justify-between bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center gap-6">
                  <div className="text-sm">
                    <span className="text-gray-600">已选择 </span>
                    <span className="text-blue-600 font-bold text-lg">{selectedCounts.total}</span>
                    <span className="text-gray-600"> / 50 条素材</span>
                    {selectedCounts.total >= 50 && (
                      <span className="text-red-600 ml-2">已达上限）</span>
                    )}
                  </div>
                  {(selectedCounts.video > 0 || selectedCounts.image > 0 || selectedCounts.html5 > 0) && (
                    <div className="flex items-center gap-3 text-sm text-gray-600">
                      {selectedCounts.video > 0 && (
                        <div className="flex items-center gap-1">
                          <Play className="w-4 h-4 text-purple-600" />
                          <span>{selectedCounts.video}</span>
                        </div>
                      )}
                      {selectedCounts.image > 0 && (
                        <div className="flex items-center gap-1">
                          <ImageIcon className="w-4 h-4 text-blue-600" />
                          <span>{selectedCounts.image}</span>
                        </div>
                      )}
                      {selectedCounts.html5 > 0 && (
                        <div className="flex items-center gap-1">
                          <Code className="w-4 h-4 text-green-600" />
                          <span>{selectedCounts.html5}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                <Button onClick={handleCreateTask} disabled={!canSubmit} size="lg">
                  <CloudUpload className="mr-2 h-4 w-4" />
                  创建推送任务
                </Button>
              </div>
            </>
          ) : (
            // 普通模式的UI
            <>
              <Alert className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  请先选择产品和素材类型，系统将展示符合条件且未推送的素材列表。单次任务最多可选择50条素材。
                </AlertDescription>
              </Alert>

              {/* F2: 选择产品和素材类型 */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="text-sm text-gray-600 mb-1 block">
                    选择产品 <span className="text-red-500">*</span>
                  </label>
                  <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                    <SelectTrigger>
                      <SelectValue placeholder="请选择产品" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockProductMappings.map((product) => (
                        <SelectItem key={product.productId} value={product.productId}>
                          {product.productName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm text-gray-600 mb-1 block">
                    素材类型 <span className="text-red-500">*</span>
                  </label>
                  <Select
                    value={selectedMaterialType}
                    onValueChange={(value) => {
                      setSelectedMaterialType(value as MaterialType);
                      setSelectedMaterialIds(new Set()); // 清空已选择的素材
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="请选择素材类型" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="video">视频</SelectItem>
                      <SelectItem value="image">图片</SelectItem>
                      <SelectItem value="html5">HTML5</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* F2: 选择数量提示 */}
              {selectedProduct && selectedMaterialType && (
                <div className="mb-4 flex items-center justify-between">
                  <div className="text-sm text-gray-600">
                    已选择 <span className="text-blue-600 font-medium">{selectedMaterialIds.size}</span> / 50 条素材
                    {selectedMaterialIds.size >= 50 && (
                      <span className="text-red-600 ml-2">（已达上限）</span>
                    )}
                  </div>
                  <Button onClick={handleCreateTask} disabled={!canSubmit}>
                    <CloudUpload className="mr-2 h-4 w-4" />
                    创建推送任务
                  </Button>
                </div>
              )}
            </>
          )}
        </div>

        {/* 素材列表 */}
        {isPackageMode ? (
          // 素材包模式：按类型分组显示
          availableMaterials.length === 0 ? (
            <div className="border border-gray-200 rounded-lg p-12 text-center text-gray-500">
              <div className="flex flex-col items-center gap-2">
                <div className="text-4xl">📭</div>
                <div>该素材包内暂无未推送的素材</div>
                <div className="text-sm text-gray-400">
                  所有素材已推送或正在推送中
                </div>
              </div>
            </div>
          ) : (
            renderGroupedMaterials()
          )
        ) : (
          // 普通模式：单类型列表显示
          selectedProduct && selectedMaterialType && (
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="w-12">
                      <Checkbox
                        checked={
                          selectedMaterialIds.size === availableMaterials.length &&
                          availableMaterials.length > 0
                        }
                        onCheckedChange={handleSelectAll}
                        disabled={availableMaterials.length === 0}
                      />
                    </TableHead>
                    {shouldShowThumbnail && <TableHead className="w-24">缩略图</TableHead>}
                    <TableHead>素材名称</TableHead>
                    <TableHead>设计师</TableHead>
                    <TableHead>素材组</TableHead>
                    <TableHead>创建时间</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {availableMaterials.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={shouldShowThumbnail ? 6 : 5} className="text-center py-12 text-gray-500">
                        <div className="flex flex-col items-center gap-2">
                          <div className="text-4xl">📭</div>
                          <div>所选条件下暂无未推送的素材</div>
                          <div className="text-sm text-gray-400">
                            请更换产品或素材类型，或先上传新的素材
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    availableMaterials.map((material) => (
                      <TableRow key={material.id} className="hover:bg-gray-50">
                        <TableCell>
                          <Checkbox
                            checked={selectedMaterialIds.has(material.id)}
                            onCheckedChange={(checked) =>
                              handleSelectOne(material.id, !!checked)
                            }
                            disabled={
                              !selectedMaterialIds.has(material.id) &&
                              selectedMaterialIds.size >= 50
                            }
                          />
                        </TableCell>
                        {shouldShowThumbnail && (
                          <TableCell>
                            <div className="relative w-20 h-15 bg-gray-100 rounded overflow-hidden">
                              <img
                                src={getThumbnailUrl(material)}
                                alt={material.name}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                {material.type === 'video' ? (
                                  <Video className="h-6 w-6 text-white" />
                                ) : (
                                  <ImageIcon className="h-6 w-6 text-white" />
                                )}
                              </div>
                            </div>
                          </TableCell>
                        )}
                        <TableCell>{material.name}</TableCell>
                        <TableCell>{material.designer}</TableCell>
                        <TableCell>{material.materialGroup || '-'}</TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {format(new Date(material.createdAt), 'yyyy-MM-dd HH:mm', {
                            locale: zhCN,
                          })}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )
        )}
      </div>
    </div>
  );
}