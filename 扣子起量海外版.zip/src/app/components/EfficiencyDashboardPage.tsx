import { TrendingUp, Construction } from 'lucide-react';

export function EfficiencyDashboardPage() {
  return (
    <div className="h-full flex items-center justify-center bg-white rounded-lg border border-gray-200">
      <div className="text-center space-y-6 p-12">
        {/* 图标 */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-24 h-24 bg-green-50 rounded-full flex items-center justify-center">
              <TrendingUp className="w-12 h-12 text-green-500" />
            </div>
            <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
              <Construction className="w-5 h-5 text-orange-600" />
            </div>
          </div>
        </div>

        {/* 标题 */}
        <div className="space-y-2">
          <h2 className="text-2xl font-medium text-gray-900">人效看板</h2>
          <p className="text-gray-500">Efficiency Dashboard</p>
        </div>

        {/* 状态信息 */}
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-50 text-yellow-700 rounded-full text-sm">
            <Construction className="w-4 h-4" />
            <span className="font-medium">页面开发中</span>
          </div>
          
          <p className="text-sm text-gray-400 max-w-md mx-auto">
            该功能正在紧张开发中，敬请期待...
          </p>
        </div>

        {/* 功能预告 */}
        <div className="mt-8 p-6 bg-gray-50 rounded-lg text-left max-w-md mx-auto">
          <h3 className="text-sm font-medium text-gray-700 mb-3">功能预告</h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-start gap-2">
              <span className="text-green-500 mt-0.5">•</span>
              <span>设计师素材产出统计</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 mt-0.5">•</span>
              <span>团队素材推送效率分析</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 mt-0.5">•</span>
              <span>人均素材产出趋势图</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 mt-0.5">•</span>
              <span>素材质量评分对比</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
