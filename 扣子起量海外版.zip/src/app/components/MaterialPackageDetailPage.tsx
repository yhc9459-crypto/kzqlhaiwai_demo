import { useState, useMemo } from 'react';
import { 
  ChevronLeft, 
  Upload, 
  Filter, 
  X, 
  Check,
  Play,
  Image as ImageIcon,
  Code,
  Edit,
  CalendarIcon,
  RotateCcw,
  Send,
  Video,
  Pause,
  Ban,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  Trash2,
  Eye
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from './ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { Calendar } from './ui/calendar';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { cn } from './ui/utils';
import { Material, MaterialType, PushStatus, ReviewStatus, UsageStatus } from '../types/material';
import { mockMaterials } from '../lib/mockData';
import { getReviewStatusBadge, getUsageStatusBadge } from '../lib/reviewHelpers';

// 素材标签选项
const MATERIAL_TAGS = [
  '原创',
  '纯剪辑/去logo',
  '拼接/混剪',
  '原创-片头',
  '改尺寸/语言',
  'H5试玩',
  'AI数字人',
  'AI生图',
];

interface MaterialPackageDetailPageProps {
  packageId: string;
  onBack: () => void;
  onNavigateToUpload: (packageName: string) => void;
  onNavigateToBatchPush?: () => void; // 旧版
  onNavigateToCreateTask?: () => void; // 新版统一命名
}

export function MaterialPackageDetailPage({ packageId, onBack, onNavigateToUpload, onNavigateToBatchPush, onNavigateToCreateTask }: MaterialPackageDetailPageProps) {
  // 筛选条件状态
  const [pushStatusFilter, setPushStatusFilter] = useState<string>('all');
  const [materialTypeFilter, setMaterialTypeFilter] = useState<string>('all');
  const [reviewStatusFilter, setReviewStatusFilter] = useState<string>('all'); // 新增：审核状态筛选
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();

  // 已应用的筛选条件
  const [appliedFilters, setAppliedFilters] = useState({
    pushStatusFilter: 'all',
    materialTypeFilter: 'all',
    reviewStatusFilter: 'all', // 新增
    dateFrom: undefined as Date | undefined,
    dateTo: undefined as Date | undefined,
  });

  // 编辑对话框状态
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editedTags, setEditedTags] = useState<string[]>([]);

  // 预览对话框状态
  const [previewMaterial, setPreviewMaterial] = useState<Material | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  
  // 审核相关对话框状态
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [rejectMaterial, setRejectMaterial] = useState<Material | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [viewRejectMaterial, setViewRejectMaterial] = useState<Material | null>(null);
  const [isViewRejectReasonOpen, setIsViewRejectReasonOpen] = useState(false);

  // Mock 素材包信息
  const [packageInfo, setPackageInfo] = useState({
    packageNumber: 'MP-20260120-0001',
    packageName: 'Bingo Bonus 新年活动素材包',
    product: 'Bingo Bonus',
    productionType: '0-1制作' as '0-1制作' | '1-N制作',
    creativePerson: '薛聪',
    materialTags: ['原创', 'H5试玩'], // 改为数组支持多选
    creatorName: '张设计',
    createdAt: '2026-01-20',
    materialCount: 5,
  });

  // 过滤出属于当前素材包的素材
  const packageMaterials = mockMaterials.filter(m => m.packageNumber === packageInfo.packageNumber);

  // 获取质量分最高的素材数据（仅在当前素材包中）
  const highestQualityMaterial = packageMaterials.reduce((prev, current) => 
    ((prev.qualityScore || 0) > (current.qualityScore || 0)) ? prev : current
  , packageMaterials[0] || { qualityScore: 0, cost: 0, ctr: 0, roi: 0, name: '-' } as any);

  // 统计各类型素材数量（仅在当前素材包中）
  const materialCounts = {
    video: packageMaterials.filter(m => m.type === 'video').length,
    image: packageMaterials.filter(m => m.type === 'image').length,
    html5: packageMaterials.filter(m => m.type === 'html5').length,
    total: packageMaterials.length,
  };

  const getStatusBadge = (status: Material['pushStatus']) => {
    const badges = {
      not_pushed: { text: '未推送', className: 'bg-gray-100 text-gray-700' },
      pushing: { text: '推送中', className: 'bg-orange-100 text-orange-700' },
      pushed: { text: '已推送', className: 'bg-green-100 text-green-700' },
    };
    const badge = badges[status] || badges.not_pushed; // 默认值防止undefined
    return (
      <span className={cn('px-2 py-1 rounded text-xs', badge.className)}>
        {badge.text}
      </span>
    );
  };

  // 获取素材状态标签（与素材库列表保持一致）
  const getMaterialStatusBadge = (status: Material['status']) => {
    switch (status) {
      case 'active':
        return (
          <Badge className="bg-green-600">
            <Play className="mr-1 h-3 w-3" />
            使用中
          </Badge>
        );
      case 'inactive':
        return (
          <Badge variant="secondary">
            <Pause className="mr-1 h-3 w-3" />
            未启用
          </Badge>
        );
      case 'disabled':
        return (
          <Badge variant="destructive">
            <Ban className="mr-1 h-3 w-3" />
            已停用
          </Badge>
        );
    }
  };

  // 根据推送状态动态获取素材状态（与素材库列表保持一致）
  const getDisplayMaterialStatus = (material: Material): Material['status'] => {
    // 推送状态为"推送中"时，强制显示为"未启用"
    if (material.pushStatus === 'pushing') {
      return 'inactive';
    }
    // 推送状态为"未推送"时，强制显示为"未启用"
    if (material.pushStatus === 'not_pushed') {
      return 'inactive';
    }
    // 其他情况返回实际状态
    return material.status;
  };

  const getTypeIcon = (type: Material['type']) => {
    switch (type) {
      case 'video':
        return <Video className="w-4 h-4 text-purple-600" />;
      case 'image':
        return <ImageIcon className="w-4 h-4 text-blue-600" />;
      case 'html5':
        return <Code className="w-4 h-4 text-green-600" />;
    }
  };

  // 查询处理
  const handleQuery = () => {
    setAppliedFilters({
      pushStatusFilter,
      materialTypeFilter,
      reviewStatusFilter, // 新增
      dateFrom,
      dateTo,
    });
    toast.success('查询完成');
  };

  // 重置处理
  const handleResetFilters = () => {
    setPushStatusFilter('all');
    setMaterialTypeFilter('all');
    setReviewStatusFilter('all'); // 新增
    setDateFrom(undefined);
    setDateTo(undefined);
    setAppliedFilters({
      pushStatusFilter: 'all',
      materialTypeFilter: 'all',
      reviewStatusFilter: 'all', // 新增
      dateFrom: undefined,
      dateTo: undefined,
    });
    toast.success('筛选条件已重置');
  };

  // 筛选素材列表
  const filteredMaterials = mockMaterials.filter((material) => {
    // 首先只显示属于当前素材包的素材
    if (material.packageNumber !== packageInfo.packageNumber) return false;
    
    // 推送状态筛选
    if (appliedFilters.pushStatusFilter !== 'all') {
      if (material.pushStatus !== appliedFilters.pushStatusFilter) return false;
    }

    // 素材类型筛选
    if (appliedFilters.materialTypeFilter !== 'all') {
      if (material.type !== appliedFilters.materialTypeFilter) return false;
    }

    // 审核状态筛选
    if (appliedFilters.reviewStatusFilter !== 'all') {
      if (material.reviewStatus !== appliedFilters.reviewStatusFilter) return false;
    }

    // 创建时间筛选
    if (appliedFilters.dateFrom || appliedFilters.dateTo) {
      const materialDate = new Date(material.createdAt);
      if (appliedFilters.dateFrom && materialDate < appliedFilters.dateFrom) return false;
      if (appliedFilters.dateTo && materialDate > appliedFilters.dateTo) return false;
    }

    return true;
  });

  // 打开编辑对话框
  const handleOpenEdit = () => {
    setEditedTags(packageInfo.materialTags);
    setIsEditDialogOpen(true);
  };

  // 保存编辑
  const handleSaveEdit = () => {
    setPackageInfo({
      ...packageInfo,
      materialTags: editedTags,
    });
    setIsEditDialogOpen(false);
    toast.success(`素材标签已更新为"${editedTags.join(', ')}"，包内${materialCounts.total}个素材已同步更新`);
  };

  // 打开预览对话框
  const handleOpenPreview = (material: Material) => {
    setPreviewMaterial(material);
    setIsPreviewOpen(true);
  };

  // 获取缩略图URL
  const getThumbnailUrl = (material: Material) => {
    const seed = material.id;
    const width = 80;
    const height = 60;

    if (material.type === 'video') {
      return `https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    } else if (material.type === 'image') {
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    }
    return '';
  };

  // 获取完整文件URL（用于全屏预览）
  const getFullFileUrl = (material: Material) => {
    const seed = material.id;

    if (material.type === 'video') {
      return `https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4`;
    } else if (material.type === 'image') {
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&h=1080&fit=crop&seed=${seed}`;
    }
    return '';
  };

  // 查看驳回原因
  const handleViewRejectReason = (material: Material) => {
    setViewRejectMaterial(material);
    setIsViewRejectReasonOpen(true);
  };

  // 删除素材
  const handleDeleteMaterial = (material: Material) => {
    if (material.pushStatus !== 'not_pushed') {
      toast.error('只能删除未推送的素材');
      return;
    }
    // 实际应用中会调用API删除
    toast.success(`素材 "${material.name}" 已删除`);
  };

  // 修改素材
  const handleEditMaterial = (material: Material) => {
    if (material.pushStatus !== 'not_pushed') {
      toast.error('只能修改未推送的素材');
      return;
    }
    // 实际应用中会跳转到素材编辑页面
    toast.info(`跳转到素材编辑页面：${material.name}`);
  };

  // 修改标签
  const handleEditTags = (material: Material) => {
    if (material.pushStatus !== 'not_pushed') {
      toast.error('只能修改未推送素材的标签');
      return;
    }
    // 实际应用中会打开标签编辑对话框
    toast.info(`修改素材标签：${material.name}`);
  };

  return (
    <div className="space-y-4">
      {/* 返回按钮 */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 text-sm"
      >
        <ChevronLeft className="w-4 h-4" />
        返回素材包列表
      </button>

      {/* 素材包信息卡片 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-xl font-semibold text-gray-900">{packageInfo.packageName}</h2>
              <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                {packageInfo.packageNumber}
              </span>
            </div>
            <div className="flex items-center gap-6 text-sm text-gray-600">
              <span>创建人：{packageInfo.creatorName}</span>
              <span>创建时间：{packageInfo.createdAt}</span>
              <span>
                素材数量：{materialCounts.total} 
                <span className="text-gray-400 ml-2">
                  (视频 {materialCounts.video} | 图片 {materialCounts.image} | H5 {materialCounts.html5})
                </span>
              </span>
              <span>所属产品：{packageInfo.product}</span>
              <span>制作类型：{packageInfo.productionType}</span>
              <span>关联创意人：{packageInfo.creativePerson}</span>
              <span className="flex items-center gap-2">
                素材标签：
                {packageInfo.materialTags.map((tag, index) => (
                  <span key={index} className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">
                    {tag}
                  </span>
                ))}
                <button
                  onClick={handleOpenEdit}
                  className="ml-1 text-blue-600 hover:text-blue-700"
                  title="编辑素材标签"
                >
                  <Edit className="w-3 h-3" />
                </button>
              </span>
            </div>
          </div>
          <div className="flex gap-3">
            {onNavigateToBatchPush && (
              <Button
                onClick={onNavigateToBatchPush}
                variant="default"
              >
                <Send className="w-4 h-4 mr-2" />
                批量推送
              </Button>
            )}
            {onNavigateToCreateTask && (
              <Button
                onClick={onNavigateToCreateTask}
                variant="default"
              >
                <Send className="w-4 h-4 mr-2" />
                创建任务
              </Button>
            )}
            <Button
              onClick={() => onNavigateToUpload(packageInfo.packageName)}
            >
              <Upload className="w-4 h-4 mr-2" />
              上传素材
            </Button>
          </div>
        </div>
      </div>

      {/* 筛选条件区域 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-6">
          {/* 筛选条件 - 一行四列布局 */}
          <div className="grid grid-cols-4 gap-4">
            {/* 推送状态 */}
            <div>
              <label className="text-sm text-gray-600 mb-1 block">
                推送状态
              </label>
              <Select value={pushStatusFilter} onValueChange={setPushStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="not_pushed">未推送</SelectItem>
                  <SelectItem value="pushing">推送中</SelectItem>
                  <SelectItem value="pushed">已推送</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* 素材类型 */}
            <div>
              <label className="text-sm text-gray-600 mb-1 block">
                素材类型
              </label>
              <Select value={materialTypeFilter} onValueChange={setMaterialTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="video">视频</SelectItem>
                  <SelectItem value="image">图片</SelectItem>
                  <SelectItem value="html5">H5试玩</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* 审核状态 */}
            <div>
              <label className="text-sm text-gray-600 mb-1 block">
                审核状态
              </label>
              <Select value={reviewStatusFilter} onValueChange={setReviewStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="pending">待审核</SelectItem>
                  <SelectItem value="approved">已通过</SelectItem>
                  <SelectItem value="rejected">已拒绝</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* 创建时间 - 占据两列 */}
            <div className="col-span-2">
              <label className="text-sm text-gray-600 mb-1 block">
                创建时间
              </label>
              <div className="grid grid-cols-2 gap-4">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left',
                        !dateFrom && 'text-gray-400'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateFrom ? format(dateFrom, 'yyyy-MM-dd') : '开始日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateFrom}
                      onSelect={setDateFrom}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left',
                        !dateTo && 'text-gray-400'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateTo ? format(dateTo, 'yyyy-MM-dd') : '结束日期'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateTo}
                      onSelect={setDateTo}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>

          {/* 操作按钮 */}
          <div className="flex justify-end items-center">
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleResetFilters}>
                <RotateCcw className="mr-2 h-4 w-4" />
                重置
              </Button>
              <Button onClick={handleQuery}>查询</Button>
            </div>
          </div>
        </div>
      </div>

      {/* 素材列表 */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="px-4 py-3 text-left font-medium text-gray-900 w-20">预览图</th>
                <th className="px-4 py-3 text-left font-medium text-gray-900">素材名称</th>
                <th className="px-4 py-3 text-center font-medium text-gray-900">类型</th>
                <th className="px-4 py-3 text-center font-medium text-gray-900">审核状态</th>
                <th className="px-4 py-3 text-center font-medium text-gray-900">使用状态</th>
                <th className="px-4 py-3 text-center font-medium text-gray-900">推送状态</th>
                <th className="px-4 py-3 text-left font-medium text-gray-900">制作人</th>
                <th className="px-4 py-3 text-left font-medium text-gray-900">创建时间</th>
                <th className="px-4 py-3 text-center font-medium text-gray-900">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredMaterials.map((material, index) => (
                <tr
                  key={material.id}
                  className={cn(
                    'border-b border-gray-100 hover:bg-gray-50',
                    index % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'
                  )}
                >
                  {/* 预览图列 */}
                  <td className="px-4 py-3">
                    {(material.type === 'video' || material.type === 'image') ? (
                      <div
                        className="relative w-20 h-15 bg-gray-100 rounded overflow-hidden flex-shrink-0 cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all"
                        onClick={() => handleOpenPreview(material)}
                      >
                        <img
                          src={getThumbnailUrl(material)}
                          alt={material.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/20 transition-colors">
                          {material.type === 'video' ? (
                            <Video className="h-6 w-6 text-white" />
                          ) : (
                            <ImageIcon className="h-6 w-6 text-white" />
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="w-20 h-15 bg-gray-100 rounded flex items-center justify-center">
                        <Code className="w-6 h-6 text-gray-400" />
                      </div>
                    )}
                  </td>

                  {/* 素材名称列 */}
                  <td className="px-4 py-3">
                    <span 
                      className="text-gray-900 font-medium cursor-pointer hover:text-blue-600 hover:underline"
                      onClick={() => handleOpenPreview(material)}
                    >
                      {material.name}
                    </span>
                  </td>

                  {/* 素材类型列 */}
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1.5">
                      {getTypeIcon(material.type)}
                      <span className="text-gray-700">
                        {material.type === 'video' ? '视频' : material.type === 'image' ? '图片' : 'H5'}
                      </span>
                    </div>
                  </td>

                  {/* 审核状态列 */}
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-2">
                      {getReviewStatusBadge(material.reviewStatus)}
                      {material.reviewStatus === 'rejected' && material.reviewComment && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-orange-500 hover:text-orange-600"
                                onClick={() => handleViewRejectReason(material)}
                              >
                                <AlertCircle className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>查看驳回原因</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                    </div>
                  </td>

                  {/* 使用状态列 */}
                  <td className="px-4 py-3 text-center">
                    {getUsageStatusBadge(material.usageStatus)}
                  </td>

                  {/* 推送状态列 */}
                  <td className="px-4 py-3 text-center">{getStatusBadge(material.pushStatus)}</td>

                  {/* 制作人列 */}
                  <td className="px-4 py-3 text-gray-700">{material.creator || material.designer}</td>

                  {/* 创建时间列 */}
                  <td className="px-4 py-3 text-gray-700">{material.createdAt}</td>

                  {/* 操作列 */}
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      {material.pushStatus === 'not_pushed' ? (
                        <>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-gray-500 hover:text-purple-600"
                                  onClick={() => handleEditTags(material)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>修改标签</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-gray-500 hover:text-blue-600"
                                  onClick={() => handleEditMaterial(material)}
                                >
                                  <Upload className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>修改素材</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-gray-500 hover:text-red-600"
                                  onClick={() => handleDeleteMaterial(material)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>删除素材</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </>
                      ) : (
                        <span className="text-xs text-gray-400">-</span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 编辑素材标签对话框 */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>编辑素材标签</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                素材标签 <span className="text-red-500">*</span>
              </label>
              <div className="space-y-2 max-h-60 overflow-y-auto border border-gray-200 rounded-md p-3">
                {MATERIAL_TAGS.map((tag) => (
                  <div key={tag} className="flex items-center">
                    <Checkbox
                      id={tag}
                      checked={editedTags.includes(tag)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setEditedTags([...editedTags, tag]);
                        } else {
                          setEditedTags(editedTags.filter((t) => t !== tag));
                        }
                      }}
                    />
                    <label
                      htmlFor={tag}
                      className="ml-2 text-sm text-gray-900 cursor-pointer"
                    >
                      {tag}
                    </label>
                  </div>
                ))}
              </div>
              {editedTags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-2">
                  <span className="text-xs text-gray-500">已选择：</span>
                  {editedTags.map((tag, index) => (
                    <span key={index} className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <p className="text-sm text-amber-800">
                <strong>注意：</strong>修改素材标签后，该素材包内的所有 {materialCounts.total} 个素材将同步更新为新的标签。
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleSaveEdit} disabled={editedTags.length === 0}>
              确认修改
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 预览素材对话框 */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-7xl w-full h-[90vh] p-0">
          <DialogHeader className="sr-only">
            <DialogTitle>预览素材</DialogTitle>
            <DialogDescription>
              {previewMaterial ? `${previewMaterial.name} - ${previewMaterial.product}` : '素材预览'}
            </DialogDescription>
          </DialogHeader>
          <div className="relative w-full h-full bg-black">
            {/* Close Button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 z-50 text-white hover:bg-white/20"
              onClick={() => setIsPreviewOpen(false)}
            >
              <X className="h-6 w-6" />
            </Button>

            {/* Title */}
            {previewMaterial && (
              <div className="absolute top-4 left-4 z-50 text-white">
                <h3 className="text-lg font-medium">
                  {previewMaterial.name}
                </h3>
                <p className="text-sm text-gray-300">
                  {previewMaterial.product}
                </p>
              </div>
            )}

            {/* Content */}
            <div className="w-full h-full flex items-center justify-center">
              {previewMaterial &&
              previewMaterial.type === 'video' ? (
                <video
                  controls
                  autoPlay
                  className="max-w-full max-h-full"
                  src={getFullFileUrl(previewMaterial)}
                >
                  您的浏览器不支持视频播放
                </video>
              ) : previewMaterial &&
                previewMaterial.type === 'image' ? (
                <img
                  src={getFullFileUrl(previewMaterial)}
                  alt={previewMaterial.name}
                  className="max-w-full max-h-full object-contain"
                />
              ) : null}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 查看驳回原因对话框 */}
      <Dialog open={isViewRejectReasonOpen} onOpenChange={setIsViewRejectReasonOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>驳回原因</DialogTitle>
            <DialogDescription>
              素材名称：{viewRejectMaterial?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-sm text-red-800">
                {viewRejectMaterial?.reviewComment || '暂无驳回原因'}
              </p>
              {viewRejectMaterial?.reviewedBy && (
                <p className="text-xs text-red-600 mt-2">
                  审核人：{viewRejectMaterial.reviewedBy} | 
                  审核时间：{viewRejectMaterial.reviewedAt}
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsViewRejectReasonOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}