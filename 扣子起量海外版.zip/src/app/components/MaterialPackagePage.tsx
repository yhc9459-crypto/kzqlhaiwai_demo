import { useState } from 'react';
import { Package, Upload, FileVideo, FileImage, FileCode, RotateCcw, ArrowUpDown, ArrowUp, ArrowDown, CalendarIcon, Video, Image as ImageIcon, X } from 'lucide-react';
import { cn } from './ui/utils';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { Calendar } from './ui/calendar';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { mockMaterials } from '../lib/mockData';
import { Material } from '../types/material';

// 素材包数据类型
interface MaterialPackage {
  id: string;
  packageNumber: string;
  packageName: string;
  product: string;
  productionType: '0-1制作' | '1-N制作' | 'N-N制作';
  materialCount: number;
  videoCount: number;
  imageCount: number;
  html5Count: number;
  tags: string[];  // 包标签
  creatorName: string;
  creativePerson: string; // 关联创意人
  createdAt: string;
}

// Mock 数据 - 只包含当前登录用户（张设计）创建的素材包
const mockPackages: MaterialPackage[] = [
  {
    id: '1',
    packageNumber: 'MP-20260120-0001',
    packageName: 'Bingo Bonus 新年活动素材包',
    product: 'Bingo Bonus',
    productionType: '0-1制作',
    materialCount: 8,
    videoCount: 3,
    imageCount: 4,
    html5Count: 1,
    tags: ['节日活动', '高转化'],
    creatorName: '张设计',
    creativePerson: '张设计',
    createdAt: '2026-01-20 10:30:00',
  },
  {
    id: '6',
    packageNumber: 'MP-20260108-0006',
    packageName: 'Bingo Bonus 冬季素材',
    product: 'Bingo Bonus',
    productionType: '1-N制作',
    materialCount: 7,
    videoCount: 3,
    imageCount: 3,
    html5Count: 1,
    tags: ['季节营销'],
    creatorName: '张设计',
    creativePerson: '张设计',
    createdAt: '2026-01-08 14:20:00',
  },
];

interface MaterialPackagePageProps {
  onNavigateToDetail: (packageId: string) => void;
  onNavigateToCreate: () => void;
  onNavigateToUpload?: (packageId: string, packageName: string) => void;
  onNavigateToCreateTask?: (packageId: string) => void;
}

export function MaterialPackagePage({ 
  onNavigateToDetail, 
  onNavigateToCreate,
  onNavigateToUpload,
  onNavigateToCreateTask,
}: MaterialPackagePageProps) {
  // 移除标签页状态，因为只显示本人素材包
  // const [activeTab, setActiveTab] = useState<string>('my-packages');
  
  // 筛选条件
  const [packageNameQuery, setPackageNameQuery] = useState('');
  const [packageNumberQuery, setPackageNumberQuery] = useState('');
  const [productFilter, setProductFilter] = useState<string>('all');
  const [productionTypeFilter, setProductionTypeFilter] = useState<string>('all');
  const [creatorFilter, setCreatorFilter] = useState<string>('all');
  const [creativePersonFilter, setCreativePersonFilter] = useState<string>('all'); // 关联创意人筛选
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  
  // 已应用的筛选条件
  const [appliedFilters, setAppliedFilters] = useState({
    packageNameQuery: '',
    packageNumberQuery: '',
    productFilter: 'all',
    productionTypeFilter: 'all',
    creatorFilter: 'all',
    creativePersonFilter: 'all', // 关联创意人筛选
    dateFrom: undefined as Date | undefined,
    dateTo: undefined as Date | undefined,
  });
  
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // 排序状态
  type SortOrder = 'asc' | 'desc' | null;
  const [createdAtSort, setCreatedAtSort] = useState<SortOrder>(null);
  
  // 预览状态
  const [previewMaterial, setPreviewMaterial] = useState<Material | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // 获取素材包的封面素材（优先视频，其次图片）
  const getPackageCoverMaterial = (packageNumber: string): Material | null => {
    const materials = mockMaterials.filter(m => m.packageNumber === packageNumber);
    
    // 优先选择视频
    const videoMaterial = materials.find(m => m.type === 'video');
    if (videoMaterial) return videoMaterial;
    
    // 其次选择图片
    const imageMaterial = materials.find(m => m.type === 'image');
    if (imageMaterial) return imageMaterial;
    
    // 都没有返回null
    return null;
  };

  // 检查素材包是否有未通过的素材
  const hasRejectedMaterials = (packageNumber: string): boolean => {
    const materials = mockMaterials.filter(m => m.packageNumber === packageNumber);
    return materials.some(m => m.reviewStatus === 'rejected');
  };

  // 获取缩略图URL
  const getThumbnailUrl = (material: Material) => {
    const seed = material.id;
    const width = 80;
    const height = 60;

    if (material.type === 'video') {
      return `https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    } else if (material.type === 'image') {
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    }
    return '';
  };

  // 获取完整文件URL（用于全屏预览）
  const getFullFileUrl = (material: Material) => {
    const seed = material.id;

    if (material.type === 'video') {
      return `https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4`;
    } else if (material.type === 'image') {
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&h=1080&fit=crop&seed=${seed}`;
    }
    return '';
  };

  // 处理缩略图点击
  const handleThumbnailClick = (e: React.MouseEvent, packageNumber: string) => {
    e.stopPropagation(); // 阻止行点击事件
    const coverMaterial = getPackageCoverMaterial(packageNumber);
    if (coverMaterial) {
      setPreviewMaterial(coverMaterial);
      setIsPreviewOpen(true);
    }
  };

  // 获取所有产品
  const allProducts = Array.from(new Set(mockPackages.map(pkg => pkg.product)));
  
  // 获取所有创建人
  const allCreators = Array.from(new Set(mockPackages.map(pkg => pkg.creatorName)));

  // 获取所有关联创意人
  const allCreativePersons = Array.from(new Set(mockPackages.map(pkg => pkg.creativePerson)));

  // 筛选和排序
  const filteredPackages = (() => {
    let result = mockPackages.filter(pkg => {
      // 素材包名称筛选
      if (appliedFilters.packageNameQuery) {
        const searchLower = appliedFilters.packageNameQuery.toLowerCase();
        if (!pkg.packageName.toLowerCase().includes(searchLower)) return false;
      }
      
      // 素材包编号筛选
      if (appliedFilters.packageNumberQuery) {
        const searchLower = appliedFilters.packageNumberQuery.toLowerCase();
        if (!pkg.packageNumber.toLowerCase().includes(searchLower)) return false;
      }
      
      // 所属产品筛选
      if (appliedFilters.productFilter !== 'all') {
        if (pkg.product !== appliedFilters.productFilter) return false;
      }
      
      // 素材制作类型筛选
      if (appliedFilters.productionTypeFilter !== 'all') {
        if (pkg.productionType !== appliedFilters.productionTypeFilter) return false;
      }
      
      // 创建人筛选
      if (appliedFilters.creatorFilter !== 'all') {
        if (pkg.creatorName !== appliedFilters.creatorFilter) return false;
      }
      
      // 关联创意人筛选
      if (appliedFilters.creativePersonFilter !== 'all') {
        if (pkg.creativePerson !== appliedFilters.creativePersonFilter) return false;
      }
      
      // 创建时间筛选
      if (appliedFilters.dateFrom || appliedFilters.dateTo) {
        const pkgDate = new Date(pkg.createdAt);
        if (appliedFilters.dateFrom && pkgDate < appliedFilters.dateFrom) return false;
        if (appliedFilters.dateTo && pkgDate > appliedFilters.dateTo) return false;
      }
      
      return true;
    });

    // 应用排序
    if (createdAtSort) {
      result.sort((a, b) => {
        const dateA = new Date(a.createdAt).getTime();
        const dateB = new Date(b.createdAt).getTime();
        return createdAtSort === 'asc' ? dateA - dateB : dateB - dateA;
      });
    }

    return result;
  })();

  // 分页
  const totalPages = Math.ceil(filteredPackages.length / itemsPerPage);
  const paginatedPackages = filteredPackages.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleQuery = () => {
    setAppliedFilters({
      packageNameQuery,
      packageNumberQuery,
      productFilter,
      productionTypeFilter,
      creatorFilter,
      creativePersonFilter, // 关联创意人筛选
      dateFrom,
      dateTo,
    });
    setCurrentPage(1);
    toast.success('查询完成');
  };

  const handleResetFilters = () => {
    setPackageNameQuery('');
    setPackageNumberQuery('');
    setProductFilter('all');
    setProductionTypeFilter('all');
    setCreatorFilter('all');
    setCreativePersonFilter('all'); // 关联创意人筛选
    setDateFrom(undefined);
    setDateTo(undefined);
    setAppliedFilters({
      packageNameQuery: '',
      packageNumberQuery: '',
      productFilter: 'all',
      productionTypeFilter: 'all',
      creatorFilter: 'all',
      creativePersonFilter: 'all', // 关联创意人筛选
      dateFrom: undefined,
      dateTo: undefined,
    });
    setCurrentPage(1);
    toast.success('筛选条件已重置');
  };

  const renderFilters = () => (
    <div className="space-y-6">
      {/* 筛选条件 - 两行四列布局 */}
      <div className="grid grid-cols-4 gap-4">
        {/* 第一行 */}
        {/* 素材包名称 */}
        <div>
          <label className="text-sm text-gray-600 mb-1 block">
            素材包名称
          </label>
          <Input
            placeholder="请输入素材包名称"
            value={packageNameQuery}
            onChange={(e) => setPackageNameQuery(e.target.value)}
          />
        </div>

        {/* 素材包编号 */}
        <div>
          <label className="text-sm text-gray-600 mb-1 block">
            素材包编号
          </label>
          <Input
            placeholder="请输入素材包编号"
            value={packageNumberQuery}
            onChange={(e) => setPackageNumberQuery(e.target.value)}
          />
        </div>

        {/* 所属产品 */}
        <div>
          <label className="text-sm text-gray-600 mb-1 block">
            所属产品
          </label>
          <Select value={productFilter} onValueChange={setProductFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allProducts.map((product) => (
                <SelectItem key={product} value={product}>
                  {product}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* 素材制作类型 */}
        <div>
          <label className="text-sm text-gray-600 mb-1 block">
            素材制作类型
          </label>
          <Select value={productionTypeFilter} onValueChange={setProductionTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="0-1制作">0-1制作</SelectItem>
              <SelectItem value="1-N制作">1-N制作</SelectItem>
              <SelectItem value="N-N制作">N-N制作</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 第二行 */}
        {/* 创建人 */}
        <div>
          <label className="text-sm text-gray-600 mb-1 block">
            创建人
          </label>
          <Select value={creatorFilter} onValueChange={setCreatorFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allCreators.map((creator) => (
                <SelectItem key={creator} value={creator}>
                  {creator}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* 关联创意人 */}
        <div>
          <label className="text-sm text-gray-600 mb-1 block">
            关联创意人
          </label>
          <Select value={creativePersonFilter} onValueChange={setCreativePersonFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allCreativePersons.map((creativePerson) => (
                <SelectItem key={creativePerson} value={creativePerson}>
                  {creativePerson}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* 创建时间 - 占据两列 */}
        <div className="col-span-2">
          <label className="text-sm text-gray-600 mb-1 block">
            创建时间
          </label>
          <div className="grid grid-cols-2 gap-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left',
                    !dateFrom && 'text-gray-400'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateFrom ? format(dateFrom, 'yyyy-MM-dd') : '开始日期'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dateFrom}
                  onSelect={setDateFrom}
                  locale={zhCN}
                />
              </PopoverContent>
            </Popover>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left',
                    !dateTo && 'text-gray-400'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateTo ? format(dateTo, 'yyyy-MM-dd') : '结束日期'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dateTo}
                  onSelect={setDateTo}
                  locale={zhCN}
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </div>

      {/* 操作按钮 */}
      <div className="flex justify-end items-center">
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleResetFilters}>
            <RotateCcw className="mr-2 h-4 w-4" />
            重置
          </Button>
          <Button onClick={handleQuery}>查询</Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* 筛选条件区域 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        {renderFilters()}
      </div>

      {/* 列表区域 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-4">
          {/* 创建素材包按钮 */}
          <div className="flex justify-start gap-3">
            <Button onClick={onNavigateToCreate}>
              <Upload className="mr-2 h-4 w-4" />
              创建素材包
            </Button>
          </div>

          {/* 表格 */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="w-24">缩略图</TableHead>
                  <TableHead>素材包编号</TableHead>
                  <TableHead>素材包名称</TableHead>
                  <TableHead>所属产品</TableHead>
                  <TableHead>制作类型</TableHead>
                  <TableHead className="text-center">素材数量</TableHead>
                  <TableHead>包标签</TableHead>
                  <TableHead>创建人</TableHead>
                  <TableHead>关联创意人</TableHead>
                  <TableHead
                    className="cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setCreatedAtSort(
                        createdAtSort === 'asc'
                          ? 'desc'
                          : createdAtSort === 'desc'
                            ? null
                            : 'asc'
                      );
                    }}
                  >
                    <div className="flex items-center">
                      创建时间
                      {createdAtSort === null && (
                        <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />
                      )}
                      {createdAtSort === 'asc' && (
                        <ArrowUp className="ml-2 h-4 w-4 inline-block" />
                      )}
                      {createdAtSort === 'desc' && (
                        <ArrowDown className="ml-2 h-4 w-4 inline-block" />
                      )}
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedPackages.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={10}
                      className="text-center py-12 text-gray-500"
                    >
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-4xl">📦</div>
                        <div>暂无素材包</div>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedPackages.map((pkg) => (
                    <TableRow
                      key={pkg.id}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => onNavigateToDetail(pkg.id)}
                    >
                      <TableCell>
                        {getPackageCoverMaterial(pkg.packageNumber) ? (
                          <div
                            className="relative w-20 h-15 bg-gray-100 rounded overflow-hidden cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all"
                            onClick={(e) => handleThumbnailClick(e, pkg.packageNumber)}
                          >
                            <img
                              src={getThumbnailUrl(getPackageCoverMaterial(pkg.packageNumber)!)}
                              alt={pkg.packageName}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/20 transition-colors">
                              {getPackageCoverMaterial(pkg.packageNumber)!.type === 'video' ? (
                                <Video className="h-6 w-6 text-white" />
                              ) : (
                                <ImageIcon className="h-6 w-6 text-white" />
                              )}
                            </div>
                            {/* 未通过角标 */}
                            {hasRejectedMaterials(pkg.packageNumber) && (
                              <div className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-medium px-1.5 py-0.5 rounded-bl-md shadow-lg">
                                未通过
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="w-20 h-15 bg-gray-100 rounded flex items-center justify-center text-gray-400 text-xs">
                            无缩略图
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="text-blue-600 font-medium">
                        {pkg.packageNumber}
                      </TableCell>
                      <TableCell>{pkg.packageName}</TableCell>
                      <TableCell>{pkg.product}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{pkg.productionType}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-3">
                          <div className="flex items-center gap-1 text-xs">
                            <FileVideo className="w-3.5 h-3.5 text-purple-600" />
                            <span className="text-gray-700">{pkg.videoCount}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <FileImage className="w-3.5 h-3.5 text-blue-600" />
                            <span className="text-gray-700">{pkg.imageCount}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <FileCode className="w-3.5 h-3.5 text-green-600" />
                            <span className="text-gray-700">{pkg.html5Count}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {pkg.tags.map(tag => (
                            <Badge key={tag} variant="secondary">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>{pkg.creatorName}</TableCell>
                      <TableCell>{pkg.creativePerson}</TableCell>
                      <TableCell>{pkg.createdAt}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* 分页 */}
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              第 {(currentPage - 1) * itemsPerPage + 1}-
              {Math.min(currentPage * itemsPerPage, filteredPackages.length)} 条/共{' '}
              {filteredPackages.length} 条
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
              >
                上一页
              </Button>
              <span className="text-sm">
                第 {currentPage} 页 / 共 {totalPages} 页
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
              >
                下一页
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* 预览素材对话框 */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-7xl w-full h-[90vh] p-0" aria-describedby={undefined}>
          <DialogTitle className="sr-only">
            {previewMaterial ? `预览素材：${previewMaterial.name}` : '预览素材'}
          </DialogTitle>
          <div className="relative w-full h-full bg-black">
            {/* Close Button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 z-50 text-white hover:bg-white/20"
              onClick={() => setIsPreviewOpen(false)}
            >
              <X className="h-6 w-6" />
            </Button>

            {/* Title */}
            {previewMaterial && (
              <div className="absolute top-4 left-4 z-50 text-white">
                <h3 className="text-lg font-medium">
                  {previewMaterial.name}
                </h3>
                <p className="text-sm text-gray-300">
                  {previewMaterial.product}
                </p>
              </div>
            )}

            {/* Content */}
            <div className="w-full h-full flex items-center justify-center">
              {previewMaterial &&
              previewMaterial.type === 'video' ? (
                <video
                  controls
                  autoPlay
                  className="max-w-full max-h-full"
                  src={getFullFileUrl(previewMaterial)}
                >
                  您的浏览器不支持视频播放
                </video>
              ) : previewMaterial &&
                previewMaterial.type === 'image' ? (
                <img
                  src={getFullFileUrl(previewMaterial)}
                  alt={previewMaterial.name}
                  className="max-w-full max-h-full object-contain"
                />
              ) : null}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}