import { useState } from 'react';
import { Package, Upload, FileVideo, FileImage, FileCode, RotateCcw, ArrowUpDown, ArrowUp, ArrowDown, CalendarIcon, Video, Image as ImageIcon, X } from 'lucide-react';
import { cn } from './ui/utils';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { Calendar } from './ui/calendar';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { mockMaterials } from '../lib/mockData';
import { Material } from '../types/material';

// 素材包数据类型
interface MaterialPackage {
  id: string;
  packageNumber: string;
  packageName: string;
  product: string;
  productionType: '0-1制作' | '1-N制作' | 'N-N制作';
  materialCount: number;
  videoCount: number;
  imageCount: number;
  html5Count: number;
  tags: string[];  // 包标签
  creatorName: string;
  creativePerson: string; // 关联创意人
  createdAt: string;
}

// Mock 数据 - 包含所有用户创建的素材包
const mockAllPackages: MaterialPackage[] = [
  {
    id: '1',
    packageNumber: 'MP-20260120-0001',
    packageName: 'Bingo Bonus 新年活动素材包',
    product: 'Bingo Bonus',
    productionType: '0-1制作',
    materialCount: 8,
    videoCount: 3,
    imageCount: 4,
    html5Count: 1,
    tags: ['节日活动', '高转化'],
    creatorName: '张设计',
    creativePerson: '张设计',
    createdAt: '2026-01-20 10:30:00',
  },
  {
    id: '2',
    packageNumber: 'MP-20260118-0002',
    packageName: 'Yazzy GO! 海外推广包',
    product: 'Yazzy GO!',
    productionType: '1-N制作',
    materialCount: 12,
    videoCount: 5,
    imageCount: 6,
    html5Count: 1,
    tags: ['海外市场', '多语言'],
    creatorName: '李设计',
    creativePerson: '李设计',
    createdAt: '2026-01-18 09:15:00',
  },
  {
    id: '3',
    packageNumber: 'MP-20260115-0003',
    packageName: 'Fishberry Story 情人节素材',
    product: 'Fishberry Story',
    productionType: '0-1制作',
    materialCount: 6,
    videoCount: 2,
    imageCount: 3,
    html5Count: 1,
    tags: ['节日活动', '原创'],
    creatorName: '王设计',
    creativePerson: '王设计',
    createdAt: '2026-01-15 16:45:00',
  },
  {
    id: '4',
    packageNumber: 'MP-20260112-0004',
    packageName: 'CabCare 春节专题包',
    product: 'CabCare',
    productionType: '1-N制作',
    materialCount: 10,
    videoCount: 4,
    imageCount: 5,
    html5Count: 1,
    tags: ['节日活动', '衍生素材'],
    creatorName: '赵设计',
    creativePerson: '赵设计',
    createdAt: '2026-01-12 11:20:00',
  },
  {
    id: '5',
    packageNumber: 'MP-20260110-0005',
    packageName: 'Mahjong Go 新手引导包',
    product: 'Mahjong Go',
    productionType: '0-1制作',
    materialCount: 5,
    videoCount: 3,
    imageCount: 2,
    html5Count: 0,
    tags: ['新手引导', '教程类'],
    creatorName: '孙设计',
    creativePerson: '孙设计',
    createdAt: '2026-01-10 14:30:00',
  },
  {
    id: '6',
    packageNumber: 'MP-20260108-0006',
    packageName: 'Bingo Bonus 冬季素材',
    product: 'Bingo Bonus',
    productionType: '1-N制作',
    materialCount: 7,
    videoCount: 3,
    imageCount: 3,
    html5Count: 1,
    tags: ['季节营销'],
    creatorName: '张设计',
    creativePerson: '张设计',
    createdAt: '2026-01-08 14:20:00',
  },
];

interface AllMaterialPackagePageProps {
  onNavigateToDetail: (packageId: string) => void;
  onNavigateToCreate: () => void;
  onNavigateToUpload: (packageId: string, packageName: string) => void;
  onNavigateToCreateTask: (packageId: string) => void;
}

export function AllMaterialPackagePage({
  onNavigateToDetail,
  onNavigateToCreate,
  onNavigateToUpload,
  onNavigateToCreateTask,
}: AllMaterialPackagePageProps) {
  // 筛选条件
  const [packageNameQuery, setPackageNameQuery] = useState('');
  const [packageNumberQuery, setPackageNumberQuery] = useState('');
  const [createDateFrom, setCreateDateFrom] = useState<Date>();
  const [createDateTo, setCreateDateTo] = useState<Date>();
  const [productFilter, setProductFilter] = useState<string>('all');
  const [productionTypeFilter, setProductionTypeFilter] = useState<string>('all');
  const [tagFilter, setTagFilter] = useState<string>('all');
  const [creatorFilter, setCreatorFilter] = useState<string>('all');
  const [creativePersonFilter, setCreativePersonFilter] = useState<string>('all'); // 关联创意人筛选

  // 已应用的筛选条件
  const [appliedFilters, setAppliedFilters] = useState({
    packageNameQuery: '',
    packageNumberQuery: '',
    createDateFrom: undefined as Date | undefined,
    createDateTo: undefined as Date | undefined,
    productFilter: 'all',
    productionTypeFilter: 'all',
    tagFilter: 'all',
    creatorFilter: 'all',
    creativePersonFilter: 'all', // 关联创意人筛选
  });

  // 分页
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // 排序状态
  type SortOrder = 'asc' | 'desc' | null;
  const [createdAtSort, setCreatedAtSort] = useState<SortOrder>(null);

  // 预览状态
  const [previewMaterial, setPreviewMaterial] = useState<Material | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // 获取素材包的封面素材（优先视频，其次图片）
  const getPackageCoverMaterial = (packageNumber: string): Material | null => {
    const materials = mockMaterials.filter(m => m.packageNumber === packageNumber);
    
    // 优先选择视频
    const videoMaterial = materials.find(m => m.type === 'video');
    if (videoMaterial) return videoMaterial;
    
    // 其次选择图片
    const imageMaterial = materials.find(m => m.type === 'image');
    if (imageMaterial) return imageMaterial;
    
    // 都没有返回null
    return null;
  };

  // 检查素材包是否有待审核的素材
  const hasPendingMaterials = (packageNumber: string): boolean => {
    const materials = mockMaterials.filter(m => m.packageNumber === packageNumber);
    return materials.some(m => m.reviewStatus === 'pending');
  };

  // 获取缩略图URL
  const getThumbnailUrl = (material: Material) => {
    const seed = material.id;
    const width = 80;
    const height = 60;

    if (material.type === 'video') {
      return `https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    } else if (material.type === 'image') {
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=${width}&h=${height}&fit=crop&seed=${seed}`;
    }
    return '';
  };

  // 获取完整文件URL（用于全屏预览）
  const getFullFileUrl = (material: Material) => {
    const seed = material.id;

    if (material.type === 'video') {
      return `https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4`;
    } else if (material.type === 'image') {
      return `https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&h=1080&fit=crop&seed=${seed}`;
    }
    return '';
  };

  // 处理缩略图点击
  const handleThumbnailClick = (e: React.MouseEvent, packageNumber: string) => {
    e.stopPropagation(); // 阻止行点击事件
    const coverMaterial = getPackageCoverMaterial(packageNumber);
    if (coverMaterial) {
      setPreviewMaterial(coverMaterial);
      setIsPreviewOpen(true);
    }
  };

  // 获取所有可选项
  const allProducts = Array.from(new Set(mockAllPackages.map(pkg => pkg.product)));
  const allTags = Array.from(new Set(mockAllPackages.flatMap(pkg => pkg.tags)));
  const allCreators = Array.from(new Set(mockAllPackages.map(pkg => pkg.creatorName)));
  const allCreativePersons = Array.from(new Set(mockAllPackages.map(pkg => pkg.creativePerson)));

  // 筛选和排序逻辑
  const filteredPackages = (() => {
    let result = mockAllPackages.filter(pkg => {
      // 素材包名称筛选
      if (appliedFilters.packageNameQuery) {
        if (!pkg.packageName.toLowerCase().includes(appliedFilters.packageNameQuery.toLowerCase())) {
          return false;
        }
      }

      // 素材包编号筛选
      if (appliedFilters.packageNumberQuery) {
        if (!pkg.packageNumber.toLowerCase().includes(appliedFilters.packageNumberQuery.toLowerCase())) {
          return false;
        }
      }

      // 创建时间筛选
      if (appliedFilters.createDateFrom) {
        const pkgDate = new Date(pkg.createdAt);
        if (pkgDate < appliedFilters.createDateFrom) {
          return false;
        }
      }
      if (appliedFilters.createDateTo) {
        const pkgDate = new Date(pkg.createdAt);
        if (pkgDate > appliedFilters.createDateTo) {
          return false;
        }
      }

      // 产品筛选
      if (appliedFilters.productFilter !== 'all' && pkg.product !== appliedFilters.productFilter) {
        return false;
      }

      // 制作类型筛选
      if (appliedFilters.productionTypeFilter !== 'all' && pkg.productionType !== appliedFilters.productionTypeFilter) {
        return false;
      }

      // 包标签筛选
      if (appliedFilters.tagFilter !== 'all' && !pkg.tags.includes(appliedFilters.tagFilter)) {
        return false;
      }

      // 创建人筛选
      if (appliedFilters.creatorFilter !== 'all' && pkg.creatorName !== appliedFilters.creatorFilter) {
        return false;
      }

      // 关联创意人筛选
      if (appliedFilters.creativePersonFilter !== 'all' && pkg.creativePerson !== appliedFilters.creativePersonFilter) {
        return false;
      }

      return true;
    });

    // 排序
    if (createdAtSort) {
      result.sort((a, b) => {
        const aDate = new Date(a.createdAt);
        const bDate = new Date(b.createdAt);

        return createdAtSort === 'asc'
          ? aDate.getTime() - bDate.getTime()
          : bDate.getTime() - aDate.getTime();
      });
    }

    return result;
  })();

  // 分页
  const totalPages = Math.ceil(filteredPackages.length / itemsPerPage);
  const paginatedPackages = filteredPackages.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleQuery = () => {
    setAppliedFilters({
      packageNameQuery,
      packageNumberQuery,
      createDateFrom,
      createDateTo,
      productFilter,
      productionTypeFilter,
      tagFilter,
      creatorFilter,
      creativePersonFilter, // 关联创意人筛选
    });
    setCurrentPage(1);
    toast.success('查询完成');
  };

  const handleResetFilters = () => {
    setPackageNameQuery('');
    setPackageNumberQuery('');
    setCreateDateFrom(undefined);
    setCreateDateTo(undefined);
    setProductFilter('all');
    setProductionTypeFilter('all');
    setTagFilter('all');
    setCreatorFilter('all');
    setCreativePersonFilter('all'); // 关联创意人筛选
    setAppliedFilters({
      packageNameQuery: '',
      packageNumberQuery: '',
      createDateFrom: undefined,
      createDateTo: undefined,
      productFilter: 'all',
      productionTypeFilter: 'all',
      tagFilter: 'all',
      creatorFilter: 'all',
      creativePersonFilter: 'all', // 关联创意人筛选
    });
    setCurrentPage(1);
    toast.success('筛选条件已重置');
  };

  const handleSort = (columnId: string) => {
    if (columnId === 'createdAt') {
      if (createdAtSort === 'asc') {
        setCreatedAtSort('desc');
      } else if (createdAtSort === 'desc') {
        setCreatedAtSort(null);
      } else {
        setCreatedAtSort('asc');
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* 筛选条件区域 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-6">
          {/* 第一行 */}
          <div className="grid grid-cols-4 gap-4">
            <div>
              <label className="text-sm text-gray-600 mb-1 block">素材包名称</label>
              <Input
                placeholder="请输入"
                value={packageNameQuery}
                onChange={(e) => setPackageNameQuery(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">素材包编号</label>
              <Input
                placeholder="请输入"
                value={packageNumberQuery}
                onChange={(e) => setPackageNumberQuery(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">创建时间</label>
              <div className="grid grid-cols-2 gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left text-sm',
                        !createDateFrom && 'text-gray-400'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {createDateFrom ? format(createDateFrom, 'yyyy-MM-dd') : '开始'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={createDateFrom}
                      onSelect={setCreateDateFrom}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left text-sm',
                        !createDateTo && 'text-gray-400'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {createDateTo ? format(createDateTo, 'yyyy-MM-dd') : '结束'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={createDateTo}
                      onSelect={setCreateDateTo}
                      locale={zhCN}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">产品</label>
              <Select value={productFilter} onValueChange={setProductFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allProducts.map((product) => (
                    <SelectItem key={product} value={product}>
                      {product}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* 第二行 */}
          <div className="grid grid-cols-4 gap-4">
            <div>
              <label className="text-sm text-gray-600 mb-1 block">制作类型</label>
              <Select value={productionTypeFilter} onValueChange={setProductionTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="0-1制作">0-1制作</SelectItem>
                  <SelectItem value="1-N制作">1-N制作</SelectItem>
                  <SelectItem value="N-N制作">N-N制作</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">包标签</label>
              <Select value={tagFilter} onValueChange={setTagFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allTags.map((tag) => (
                    <SelectItem key={tag} value={tag}>
                      {tag}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">创建人</label>
              <Select value={creatorFilter} onValueChange={setCreatorFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allCreators.map((creator) => (
                    <SelectItem key={creator} value={creator}>
                      {creator}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-600 mb-1 block">关联创意人</label>
              <Select value={creativePersonFilter} onValueChange={setCreativePersonFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  {allCreativePersons.map((creativePerson) => (
                    <SelectItem key={creativePerson} value={creativePerson}>
                      {creativePerson}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* 操作按钮 */}
          <div className="flex justify-end items-center">
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleResetFilters}>
                <RotateCcw className="mr-2 h-4 w-4" />
                重置
              </Button>
              <Button onClick={handleQuery}>查询</Button>
            </div>
          </div>
        </div>
      </div>

      {/* 表格区域 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-4">
          {/* 工具栏 */}
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-600">
              共 {filteredPackages.length} 个素材包
            </div>
            <div className="flex gap-2">
              <Button onClick={onNavigateToCreate}>
                <Package className="mr-2 h-4 w-4" />
                创建素材包
              </Button>
            </div>
          </div>

          {/* 表格 */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="w-24">缩略图</TableHead>
                  <TableHead>素材包编号</TableHead>
                  <TableHead>素材包名称</TableHead>
                  <TableHead>所属产品</TableHead>
                  <TableHead>制作类型</TableHead>
                  <TableHead className="text-center">素材数量</TableHead>
                  <TableHead>包标签</TableHead>
                  <TableHead>创建人</TableHead>
                  <TableHead>关联创意人</TableHead>
                  <TableHead
                    className="cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => handleSort('createdAt')}
                  >
                    <div className="flex items-center">
                      创建时间
                      {createdAtSort === null && (
                        <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />
                      )}
                      {createdAtSort === 'asc' && (
                        <ArrowUp className="ml-2 h-4 w-4 inline-block" />
                      )}
                      {createdAtSort === 'desc' && (
                        <ArrowDown className="ml-2 h-4 w-4 inline-block" />
                      )}
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedPackages.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={10}
                      className="text-center py-12 text-gray-500"
                    >
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-4xl">📦</div>
                        <div>暂无素材包</div>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedPackages.map((pkg) => (
                    <TableRow
                      key={pkg.id}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => onNavigateToDetail(pkg.id)}
                    >
                      <TableCell>
                        {getPackageCoverMaterial(pkg.packageNumber) ? (
                          <div
                            className="relative w-20 h-15 bg-gray-100 rounded overflow-hidden cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all"
                            onClick={(e) => handleThumbnailClick(e, pkg.packageNumber)}
                          >
                            <img
                              src={getThumbnailUrl(getPackageCoverMaterial(pkg.packageNumber)!)}
                              alt={pkg.packageName}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/20 transition-colors">
                              {getPackageCoverMaterial(pkg.packageNumber)!.type === 'video' ? (
                                <Video className="h-6 w-6 text-white" />
                              ) : (
                                <ImageIcon className="h-6 w-6 text-white" />
                              )}
                            </div>
                            {/* 待审核角标 */}
                            {hasPendingMaterials(pkg.packageNumber) && (
                              <div className="absolute top-0 right-0 bg-blue-500 text-white text-[10px] font-medium px-1.5 py-0.5 rounded-bl-md shadow-lg">
                                待审核
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="w-20 h-15 bg-gray-100 rounded flex items-center justify-center text-gray-400 text-xs">
                            无缩略图
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="text-blue-600 font-medium">
                        {pkg.packageNumber}
                      </TableCell>
                      <TableCell>{pkg.packageName}</TableCell>
                      <TableCell>{pkg.product}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{pkg.productionType}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-3">
                          <div className="flex items-center gap-1 text-xs">
                            <FileVideo className="w-3.5 h-3.5 text-purple-600" />
                            <span className="text-gray-700">{pkg.videoCount}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <FileImage className="w-3.5 h-3.5 text-blue-600" />
                            <span className="text-gray-700">{pkg.imageCount}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <FileCode className="w-3.5 h-3.5 text-green-600" />
                            <span className="text-gray-700">{pkg.html5Count}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {pkg.tags.map(tag => (
                            <Badge key={tag} variant="secondary">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>{pkg.creatorName}</TableCell>
                      <TableCell>{pkg.creativePerson}</TableCell>
                      <TableCell>{pkg.createdAt}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* 分页 */}
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              第 {(currentPage - 1) * itemsPerPage + 1} -{' '}
              {Math.min(currentPage * itemsPerPage, filteredPackages.length)} 条，共{' '}
              {filteredPackages.length} 条
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                上一页
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                下一页
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* 预览Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-4xl w-full">
          <DialogTitle className="sr-only">素材预览</DialogTitle>
          <div className="relative w-full">
            <button
              onClick={() => setIsPreviewOpen(false)}
              className="absolute top-2 right-2 z-10 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            >
              <X className="h-5 w-5 text-white" />
            </button>
            {previewMaterial && (
              <div className="w-full">
                {previewMaterial.type === 'video' ? (
                  <video
                    src={getFullFileUrl(previewMaterial)}
                    controls
                    autoPlay
                    className="w-full h-auto max-h-[70vh] rounded"
                  >
                    您的浏览器不支持视频播放。
                  </video>
                ) : (
                  <img
                    src={getFullFileUrl(previewMaterial)}
                    alt={previewMaterial.name}
                    className="w-full h-auto max-h-[70vh] object-contain rounded"
                  />
                )}
                <div className="mt-4 text-center text-sm text-gray-600">
                  {previewMaterial.name}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}