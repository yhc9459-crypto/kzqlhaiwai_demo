import { ChevronRight, Search, Bell, Moon, Settings as SettingsIcon, User } from 'lucide-react';

interface Breadcrumb {
  label: string;
  href: string;
}

interface HeaderProps {
  breadcrumbs: Breadcrumb[];
}

export function Header({ breadcrumbs }: HeaderProps) {
  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6">
      {/* Breadcrumbs */}
      <div className="flex items-center gap-2 text-sm">
        {breadcrumbs.map((crumb, index) => (
          <div key={index} className="flex items-center gap-2">
            {index > 0 && <ChevronRight className="h-4 w-4 text-gray-400" />}
            <span
              className={
                index === breadcrumbs.length - 1
                  ? 'text-gray-900 font-medium'
                  : 'text-gray-500 hover:text-gray-700 cursor-pointer'
              }
            >
              {crumb.label}
            </span>
          </div>
        ))}
      </div>

      {/* Right side actions */}
      <div className="flex items-center gap-4">
        {/* Search */}
        <button className="p-2 hover:bg-gray-100 rounded-lg">
          <Search className="h-5 w-5 text-gray-600" />
        </button>

        {/* Language */}
        <button className="px-2 py-1 hover:bg-gray-100 rounded text-sm text-gray-600">
          简体中文
        </button>

        {/* Notifications */}
        <button className="p-2 hover:bg-gray-100 rounded-lg relative">
          <Bell className="h-5 w-5 text-gray-600" />
        </button>

        {/* Settings */}
        <button className="p-2 hover:bg-gray-100 rounded-lg">
          <SettingsIcon className="h-5 w-5 text-gray-600" />
        </button>

        {/* Theme toggle */}
        <button className="p-2 hover:bg-gray-100 rounded-lg">
          <Moon className="h-5 w-5 text-gray-600" />
        </button>

        {/* User avatar */}
        <button className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center hover:bg-blue-600">
          <User className="h-5 w-5 text-white" />
        </button>
      </div>
    </header>
  );
}
