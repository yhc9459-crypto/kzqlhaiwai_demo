import { useState } from 'react';
import { X, Check } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { cn } from './ui/utils';
import { packageTagCategories, getTagsByCategory, type PackageTagCategory } from '../lib/packageTags';

interface PackageTagSelectorProps {
  selectedTags: string[];
  onChange: (tags: string[]) => void;
  placeholder?: string;
}

export function PackageTagSelector({ selectedTags, onChange, placeholder = '请选择素材包标签' }: PackageTagSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<PackageTagCategory>('前贴');

  // 获取当前分类的标签
  const currentCategoryTags = getTagsByCategory(selectedCategory);

  // 切换标签选中状态
  const toggleTag = (tagName: string) => {
    if (selectedTags.includes(tagName)) {
      onChange(selectedTags.filter((t) => t !== tagName));
    } else {
      onChange([...selectedTags, tagName]);
    }
  };

  // 删除标签
  const removeTag = (tagName: string) => {
    onChange(selectedTags.filter((t) => t !== tagName));
  };

  return (
    <div>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn(
              "w-full justify-start text-left font-normal",
              !selectedTags.length && "text-gray-500"
            )}
          >
            {selectedTags.length === 0 ? placeholder : `已选择 ${selectedTags.length} 个标签`}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[600px] p-0" align="start">
          <div className="flex h-[400px]">
            {/* 左侧分类列表 */}
            <div className="w-32 border-r border-gray-200 bg-gray-50">
              <div className="p-2">
                <div className="text-xs font-medium text-gray-500 px-2 py-1 mb-1">标签分类</div>
                <div className="space-y-0.5">
                  {packageTagCategories.map((category) => {
                    const categoryTags = getTagsByCategory(category);
                    const selectedCount = categoryTags.filter(tag => selectedTags.includes(tag.name)).length;
                    return (
                      <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={cn(
                          'w-full text-left px-2 py-1.5 rounded text-sm transition-colors',
                          selectedCategory === category
                            ? 'bg-blue-100 text-blue-700 font-medium'
                            : 'hover:bg-gray-100 text-gray-700'
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <span>{category}</span>
                          {selectedCount > 0 && (
                            <span className="text-xs bg-blue-500 text-white rounded-full px-1.5 py-0.5 min-w-[18px] text-center">
                              {selectedCount}
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* 右侧标签列表 */}
            <div className="flex-1 overflow-y-auto">
              <div className="p-4">
                <div className="text-sm font-medium text-gray-700 mb-3">
                  {selectedCategory} ({currentCategoryTags.length})
                </div>
                <TooltipProvider delayDuration={200}>
                  <div className="grid grid-cols-2 gap-2">
                    {currentCategoryTags.map((tag) => {
                      const isSelected = selectedTags.includes(tag.name);
                      return (
                        <Tooltip key={tag.id}>
                          <TooltipTrigger asChild>
                            <button
                              onClick={() => toggleTag(tag.name)}
                              className={cn(
                                'flex items-center gap-2 px-3 py-2 rounded-md border text-sm transition-all',
                                isSelected
                                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-700'
                              )}
                            >
                              <div className={cn(
                                'w-4 h-4 rounded border flex items-center justify-center flex-shrink-0',
                                isSelected
                                  ? 'border-blue-500 bg-blue-500'
                                  : 'border-gray-300'
                              )}>
                                {isSelected && <Check className="w-3 h-3 text-white" />}
                              </div>
                              <span className="flex-1 text-left truncate">{tag.name}</span>
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="bottom" className="max-w-xs">
                            <p className="text-xs">{tag.description}</p>
                          </TooltipContent>
                        </Tooltip>
                      );
                    })}
                  </div>
                </TooltipProvider>
                {currentCategoryTags.length === 0 && (
                  <div className="text-center py-8 text-gray-400 text-sm">
                    该分类暂无可用标签
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 底部操作栏 */}
          <div className="border-t border-gray-200 p-3 bg-gray-50">
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-500">
                已选择 {selectedTags.length} 个标签
              </span>
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onChange([])}
                  disabled={selectedTags.length === 0}
                >
                  清空
                </Button>
                <Button
                  size="sm"
                  onClick={() => setIsOpen(false)}
                >
                  确定
                </Button>
              </div>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      {/* 已选择的标签展示 */}
      {selectedTags.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-2">
          {selectedTags.map((tagName) => (
            <Badge key={tagName} variant="secondary" className="px-2 py-1">
              {tagName}
              <button
                onClick={() => removeTag(tagName)}
                className="ml-1 hover:text-red-600"
                aria-label={`删除${tagName}`}
              >
                <X className="w-3 h-3" />
              </button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}