import { useState } from 'react';
import { ArrowLeft, RotateCcw, CalendarIcon, ArrowUpDown, ArrowUp, ArrowDown, Video, Image as ImageIcon } from 'lucide-react';
import { cn } from './ui/utils';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { Calendar } from './ui/calendar';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';
import { DesignerDashboardFilters } from './DesignerDashboardPage';
import { Badge } from './ui/badge';

// 素材数据类型（设计师看板）
interface DesignerMaterialData {
  id: string;
  name: string;
  type: 'video' | 'image' | 'html5';
  packageNumber: string;
  product: string;
  productionType: string;
  creator: string;
  creativePerson: string;
  // 投放数据指标
  cost: number;        // 花费
  im: number;          // 展示量
  clk: number;         // 点击量
  act: number;         // 激活数
  cpi: number;         // CPI
  ctr: number;         // CTR
  cvr: number;         // CVR
  ivr: number;         // IVR
  ipm: number;         // IPM
  cpm: number;         // CPM
  ad: number;          // 广告收入
  iap: number;         // IAP收入
  iapUv: number;       // 订阅用户数
  d0Roi: number;       // D0 ROI
  retention2: number;  // 激活次留
  retention7: number;  // 激活7留
  retention14: number; // 激活14留
}

// Mock素材数据
const mockMaterialsData: DesignerMaterialData[] = [
  {
    id: 'm1',
    name: 'bingo_newyear_en_1080x1920',
    type: 'video',
    packageNumber: 'MP-20260120-0001',
    product: 'Bingo Bonus',
    productionType: '0-1制作',
    creator: '张设计',
    creativePerson: '张设计',
    cost: 8500.50,
    im: 125000,
    clk: 10500,
    act: 5200,
    cpi: 1.63,
    ctr: 8.4,
    cvr: 49.5,
    ivr: 4.16,
    ipm: 41.6,
    cpm: 68.0,
    ad: 12500.00,
    iap: 3200.00,
    iapUv: 85,
    d0Roi: 1.85,
    retention2: 45.2,
    retention7: 28.5,
    retention14: 18.3,
  },
  {
    id: 'm2',
    name: 'bingo_newyear_zh_1080x1920',
    type: 'video',
    packageNumber: 'MP-20260120-0001',
    product: 'Bingo Bonus',
    productionType: '0-1制作',
    creator: '张设计',
    creativePerson: '张设计',
    cost: 6200.30,
    im: 98000,
    clk: 7800,
    act: 3800,
    cpi: 1.63,
    ctr: 8.0,
    cvr: 48.7,
    ivr: 3.88,
    ipm: 38.8,
    cpm: 63.3,
    ad: 9200.00,
    iap: 2100.00,
    iapUv: 62,
    d0Roi: 1.82,
    retention2: 42.8,
    retention7: 26.3,
    retention14: 16.5,
  },
  {
    id: 'm3',
    name: 'bingo_newyear_ja_1080x1920',
    type: 'video',
    packageNumber: 'MP-20260120-0001',
    product: 'Bingo Bonus',
    productionType: '0-1制作',
    creator: '张设计',
    creativePerson: '张设计',
    cost: 4800.20,
    im: 78000,
    clk: 5900,
    act: 2600,
    cpi: 1.85,
    ctr: 7.6,
    cvr: 44.1,
    ivr: 3.33,
    ipm: 33.3,
    cpm: 61.5,
    ad: 6800.00,
    iap: 1500.00,
    iapUv: 45,
    d0Roi: 1.73,
    retention2: 38.5,
    retention7: 24.1,
    retention14: 15.2,
  },
];

interface DesignerPackageDetailPageProps {
  packageId: string;
  initialFilters: DesignerDashboardFilters;
  onBack: () => void;
}

export function DesignerPackageDetailPage({ packageId, initialFilters, onBack }: DesignerPackageDetailPageProps) {
  // 筛选条件（从父页面传递过来）
  const [dateFrom, setDateFrom] = useState<Date | undefined>(initialFilters.dateFrom);
  const [dateTo, setDateTo] = useState<Date | undefined>(initialFilters.dateTo);
  const [materialNameQuery, setMaterialNameQuery] = useState('');
  const [productFilter, setProductFilter] = useState<string>(initialFilters.productFilter);
  const [productionTypeFilter, setProductionTypeFilter] = useState<string>(initialFilters.productionTypeFilter);
  const [networkFilter, setNetworkFilter] = useState<string>(initialFilters.networkFilter);
  const [countryFilter, setCountryFilter] = useState<string>(initialFilters.countryFilter);
  const [creatorFilter, setCreatorFilter] = useState<string>(initialFilters.creatorFilter);
  const [creativePersonFilter, setCreativePersonFilter] = useState<string>(initialFilters.creativePersonFilter);
  const [materialTypeFilter, setMaterialTypeFilter] = useState<string>(initialFilters.materialTypeFilter);

  // 已应用的筛选条件
  const [appliedFilters, setAppliedFilters] = useState({
    dateFrom: initialFilters.dateFrom,
    dateTo: initialFilters.dateTo,
    materialNameQuery: '',
    productFilter: initialFilters.productFilter,
    productionTypeFilter: initialFilters.productionTypeFilter,
    networkFilter: initialFilters.networkFilter,
    countryFilter: initialFilters.countryFilter,
    creatorFilter: initialFilters.creatorFilter,
    creativePersonFilter: initialFilters.creativePersonFilter,
    materialTypeFilter: initialFilters.materialTypeFilter,
  });

  // 分页
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // 排序状态
  type SortOrder = 'asc' | 'desc' | null;
  const [costSort, setCostSort] = useState<SortOrder>(null);
  const [actSort, setActSort] = useState<SortOrder>(null);
  const [d0RoiSort, setD0RoiSort] = useState<SortOrder>(null);
  const [retention2Sort, setRetention2Sort] = useState<SortOrder>(null);
  const [retention7Sort, setRetention7Sort] = useState<SortOrder>(null);
  const [retention14Sort, setRetention14Sort] = useState<SortOrder>(null);

  // 获取素材包信息
  const packageData = {
    packageNumber: 'MP-20260120-0001',
    packageName: 'Bingo Bonus 新年活动素材包',
    product: 'Bingo Bonus',
    productionType: '0-1制作',
    tags: ['原创', 'AI数字人', '改尺寸/语言'],
  };

  // 筛选和排序素材数据
  const filteredMaterials = (() => {
    let result = mockMaterialsData.filter(material => {
      if (appliedFilters.materialNameQuery) {
        if (!material.name.toLowerCase().includes(appliedFilters.materialNameQuery.toLowerCase())) return false;
      }
      if (appliedFilters.productFilter !== 'all') {
        if (material.product !== appliedFilters.productFilter) return false;
      }
      if (appliedFilters.productionTypeFilter !== 'all') {
        if (material.productionType !== appliedFilters.productionTypeFilter) return false;
      }
      if (appliedFilters.creatorFilter !== 'all') {
        if (material.creator !== appliedFilters.creatorFilter) return false;
      }
      if (appliedFilters.creativePersonFilter !== 'all') {
        if (material.creativePerson !== appliedFilters.creativePersonFilter) return false;
      }
      if (appliedFilters.materialTypeFilter !== 'all') {
        if (material.type !== appliedFilters.materialTypeFilter) return false;
      }
      return true;
    });

    // 应用排序
    if (costSort) {
      result.sort((a, b) => costSort === 'asc' ? a.cost - b.cost : b.cost - a.cost);
    } else if (actSort) {
      result.sort((a, b) => actSort === 'asc' ? a.act - b.act : b.act - a.act);
    } else if (d0RoiSort) {
      result.sort((a, b) => d0RoiSort === 'asc' ? a.d0Roi - b.d0Roi : b.d0Roi - a.d0Roi);
    } else if (retention2Sort) {
      result.sort((a, b) => retention2Sort === 'asc' ? a.retention2 - b.retention2 : b.retention2 - a.retention2);
    } else if (retention7Sort) {
      result.sort((a, b) => retention7Sort === 'asc' ? a.retention7 - b.retention7 : b.retention7 - a.retention7);
    } else if (retention14Sort) {
      result.sort((a, b) => retention14Sort === 'asc' ? a.retention14 - b.retention14 : b.retention14 - a.retention14);
    }

    return result;
  })();

  // 获取素材包中花费最高的素材（从筛选后的素材中选择）
  const topMaterial = filteredMaterials.length > 0 
    ? filteredMaterials.reduce((max, current) => 
        current.cost > max.cost ? current : max
      , filteredMaterials[0])
    : null;

  // 分页
  const totalPages = Math.ceil(filteredMaterials.length / itemsPerPage);
  const paginatedMaterials = filteredMaterials.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const allProducts = Array.from(new Set(mockMaterialsData.map(m => m.product)));
  const allCreators = Array.from(new Set(mockMaterialsData.map(m => m.creator)));
  const allCreativePersons = Array.from(new Set(mockMaterialsData.map(m => m.creativePerson)));

  const handleQuery = () => {
    setAppliedFilters({
      dateFrom,
      dateTo,
      materialNameQuery,
      productFilter,
      productionTypeFilter,
      networkFilter,
      countryFilter,
      creatorFilter,
      creativePersonFilter,
      materialTypeFilter,
    });
    setCurrentPage(1);
    toast.success('查询完成');
  };

  const handleResetFilters = () => {
    setDateFrom(initialFilters.dateFrom);
    setDateTo(initialFilters.dateTo);
    setMaterialNameQuery('');
    setProductFilter(initialFilters.productFilter);
    setProductionTypeFilter(initialFilters.productionTypeFilter);
    setNetworkFilter(initialFilters.networkFilter);
    setCountryFilter(initialFilters.countryFilter);
    setCreatorFilter(initialFilters.creatorFilter);
    setCreativePersonFilter(initialFilters.creativePersonFilter);
    setMaterialTypeFilter(initialFilters.materialTypeFilter);
    setAppliedFilters({
      dateFrom: initialFilters.dateFrom,
      dateTo: initialFilters.dateTo,
      materialNameQuery: '',
      productFilter: initialFilters.productFilter,
      productionTypeFilter: initialFilters.productionTypeFilter,
      networkFilter: initialFilters.networkFilter,
      countryFilter: initialFilters.countryFilter,
      creatorFilter: initialFilters.creatorFilter,
      creativePersonFilter: initialFilters.creativePersonFilter,
      materialTypeFilter: initialFilters.materialTypeFilter,
    });
    setCurrentPage(1);
    toast.success('筛选条件已重置');
  };

  const renderFilters = () => (
    <div className="space-y-6">
      {/* 第一行 */}
      <div className="grid grid-cols-4 gap-4">
        <div>
          <label className="text-sm text-gray-600 mb-1 block">日期</label>
          <div className="grid grid-cols-2 gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn('w-full justify-start text-left text-sm', !dateFrom && 'text-gray-400')}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateFrom ? format(dateFrom, 'yyyy-MM-dd') : '开始'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} locale={zhCN} />
              </PopoverContent>
            </Popover>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn('w-full justify-start text-left text-sm', !dateTo && 'text-gray-400')}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateTo ? format(dateTo, 'yyyy-MM-dd') : '结束'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={dateTo} onSelect={setDateTo} locale={zhCN} />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">素材名称</label>
          <Input placeholder="请输入" value={materialNameQuery} onChange={(e) => setMaterialNameQuery(e.target.value)} />
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">应用</label>
          <Select value={productFilter} onValueChange={setProductFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allProducts.map((product) => (
                <SelectItem key={product} value={product}>{product}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">network</label>
          <Select value={networkFilter} onValueChange={setNetworkFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="facebook">Facebook</SelectItem>
              <SelectItem value="google">Google Ads</SelectItem>
              <SelectItem value="tiktok">TikTok</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* 第二行 */}
      <div className="grid grid-cols-4 gap-4">
        <div>
          <label className="text-sm text-gray-600 mb-1 block">国家</label>
          <Select value={countryFilter} onValueChange={setCountryFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="US">美国</SelectItem>
              <SelectItem value="UK">英国</SelectItem>
              <SelectItem value="JP">日本</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">制作类型</label>
          <Select value={productionTypeFilter} onValueChange={setProductionTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="0-1制作">0-1制作</SelectItem>
              <SelectItem value="1-N制作">1-N制作</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">制作人</label>
          <Select value={creatorFilter} onValueChange={setCreatorFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allCreators.map((creator) => (
                <SelectItem key={creator} value={creator}>{creator}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-600 mb-1 block">创意人</label>
          <Select value={creativePersonFilter} onValueChange={setCreativePersonFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              {allCreativePersons.map((person) => (
                <SelectItem key={person} value={person}>{person}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* 第三行 */}
      <div className="grid grid-cols-4 gap-4">
        <div>
          <label className="text-sm text-gray-600 mb-1 block">素材类型</label>
          <Select value={materialTypeFilter} onValueChange={setMaterialTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="请选择" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="video">视频</SelectItem>
              <SelectItem value="image">图片</SelectItem>
              <SelectItem value="html5">H5</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* 操作按钮 */}
      <div className="flex justify-end items-center">
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleResetFilters}>
            <RotateCcw className="mr-2 h-4 w-4" />
            重置
          </Button>
          <Button onClick={handleQuery}>查询</Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* 返回按钮 */}
      <Button variant="outline" onClick={onBack}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        返回设计师看板
      </Button>

      {/* 素材包基本信息 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-lg font-semibold mb-4">素材包信息</h2>
        <div className="grid grid-cols-4 gap-4">
          <div>
            <div className="text-sm text-gray-600">素材包编号</div>
            <div className="font-medium">{packageData.packageNumber}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">素材包名称</div>
            <div className="font-medium">{packageData.packageName}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">产品</div>
            <div className="font-medium">{packageData.product}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">制作类型</div>
            <div className="font-medium">{packageData.productionType}</div>
          </div>
        </div>
        <div className="mt-4">
          <div className="text-sm text-gray-600 mb-2">包标签</div>
          <div className="flex gap-2">
            {packageData.tags.map((tag, index) => (
              <Badge key={index} variant="outline">{tag}</Badge>
            ))}
          </div>
        </div>
      </div>

      {/* 筛选条件 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        {renderFilters()}
      </div>

      {/* 素材包数据（花费最高的素材） */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-lg font-semibold mb-4">素材包数据（消耗最高素材）</h2>
        {topMaterial ? (
          <div className="grid grid-cols-6 gap-4">
            <div>
              <div className="text-sm text-gray-600">素材名称</div>
              <div className="font-medium flex items-center gap-2">
                {topMaterial.type === 'video' ? <Video className="h-4 w-4 text-purple-600" /> : <ImageIcon className="h-4 w-4 text-blue-600" />}
                {topMaterial.name}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600">花费($)</div>
              <div className="font-medium text-orange-600">${topMaterial.cost.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Act</div>
              <div className="font-medium">{topMaterial.act.toLocaleString()}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">D0_ROI</div>
              <div className="font-medium text-green-600">{topMaterial.d0Roi.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">激活次留</div>
              <div className="font-medium">{topMaterial.retention2.toFixed(1)}%</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">激活7留</div>
              <div className="font-medium">{topMaterial.retention7.toFixed(1)}%</div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <div className="text-4xl mb-2">🔍</div>
            <div>根据当前筛选条件，没有找到符合条件的素材</div>
          </div>
        )}
      </div>

      {/* 素材数据列表 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">素材数据明细</h2>
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead>素材名称</TableHead>
                  <TableHead>类型</TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setCostSort(costSort === 'asc' ? 'desc' : costSort === 'desc' ? null : 'asc');
                      setActSort(null);
                      setD0RoiSort(null);
                      setRetention2Sort(null);
                      setRetention7Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      Cost($)
                      {costSort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {costSort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {costSort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead className="text-right">IM</TableHead>
                  <TableHead className="text-right">CLK</TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setActSort(actSort === 'asc' ? 'desc' : actSort === 'desc' ? null : 'asc');
                      setCostSort(null);
                      setD0RoiSort(null);
                      setRetention2Sort(null);
                      setRetention7Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      Act
                      {actSort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {actSort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {actSort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead className="text-right">CPI($)</TableHead>
                  <TableHead className="text-right">CTR(%)</TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setD0RoiSort(d0RoiSort === 'asc' ? 'desc' : d0RoiSort === 'desc' ? null : 'asc');
                      setCostSort(null);
                      setActSort(null);
                      setRetention2Sort(null);
                      setRetention7Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      D0_ROI
                      {d0RoiSort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {d0RoiSort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {d0RoiSort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setRetention2Sort(retention2Sort === 'asc' ? 'desc' : retention2Sort === 'desc' ? null : 'asc');
                      setCostSort(null);
                      setActSort(null);
                      setD0RoiSort(null);
                      setRetention7Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      激活次留(%)
                      {retention2Sort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {retention2Sort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {retention2Sort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setRetention7Sort(retention7Sort === 'asc' ? 'desc' : retention7Sort === 'desc' ? null : 'asc');
                      setCostSort(null);
                      setActSort(null);
                      setD0RoiSort(null);
                      setRetention2Sort(null);
                      setRetention14Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      激活7留(%)
                      {retention7Sort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {retention7Sort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {retention7Sort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="text-right cursor-pointer select-none hover:bg-gray-100"
                    onClick={() => {
                      setRetention14Sort(retention14Sort === 'asc' ? 'desc' : retention14Sort === 'desc' ? null : 'asc');
                      setCostSort(null);
                      setActSort(null);
                      setD0RoiSort(null);
                      setRetention2Sort(null);
                      setRetention7Sort(null);
                    }}
                  >
                    <div className="flex items-center justify-end">
                      激活14留(%)
                      {retention14Sort === null && <ArrowUpDown className="ml-2 h-4 w-4 inline-block" />}
                      {retention14Sort === 'asc' && <ArrowUp className="ml-2 h-4 w-4 inline-block" />}
                      {retention14Sort === 'desc' && <ArrowDown className="ml-2 h-4 w-4 inline-block" />}
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedMaterials.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={12} className="text-center py-12 text-gray-500">
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-4xl">🎨</div>
                        <div>暂无素材数据</div>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedMaterials.map((material) => (
                    <TableRow key={material.id} className="hover:bg-gray-50">
                      <TableCell className="font-medium">{material.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {material.type === 'video' && <Video className="h-4 w-4 text-purple-600" />}
                          {material.type === 'image' && <ImageIcon className="h-4 w-4 text-blue-600" />}
                          {material.type === 'html5' && <span className="text-green-600">H5</span>}
                          <span className="text-sm">{material.type === 'video' ? '视频' : material.type === 'image' ? '图片' : 'H5'}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">${material.cost.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{material.im.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{material.clk.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{material.act.toLocaleString()}</TableCell>
                      <TableCell className="text-right">${material.cpi.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{material.ctr.toFixed(2)}%</TableCell>
                      <TableCell className="text-right text-green-600 font-medium">{material.d0Roi.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{material.retention2.toFixed(1)}%</TableCell>
                      <TableCell className="text-right">{material.retention7.toFixed(1)}%</TableCell>
                      <TableCell className="text-right">{material.retention14.toFixed(1)}%</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* 分页 */}
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              第 {(currentPage - 1) * itemsPerPage + 1} - {Math.min(currentPage * itemsPerPage, filteredMaterials.length)} 条，
              共 {filteredMaterials.length} 条
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                上一页
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                下一页
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}