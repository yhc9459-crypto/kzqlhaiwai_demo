import { useState } from 'react';
import { ArrowLeft, Package } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { PackageTagSelector } from './PackageTagSelector';

interface CreateMaterialPackagePageProps {
  onBack: () => void;
  onSuccess: (packageId: string) => void;
}

// 产品列表
const PRODUCTS = [
  'Bingo Bonus',
  'Yazzy GO!',
  'Fishberry Story',
  'CabCare',
  'Mahjong Go',
];

// 创意人列表
const CREATIVE_STAFF = [
  '设计师本人',
  '薛聪',
  '范依依',
  '于慧琛',
  '增长小助手3',
  '曹婉婷',
  '马倩茹',
  '孟豪',
  '郭禧辰',
  '李楠',
];

export function CreateMaterialPackagePage({ onBack, onSuccess }: CreateMaterialPackagePageProps) {
  const [packageName, setPackageName] = useState('');
  const [product, setProduct] = useState('');
  const [productionType, setProductionType] = useState<'0-1制作' | '1-N制作' | ''>('');
  const [creativePerson, setCreativePerson] = useState('');
  const [materialTags, setMaterialTags] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 自动生成素材包编号（按照规则：MP-YYYYMMDD-0001）
  const generatePackageNumber = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const serial = '0001'; // 实际应该从后端获取当天的流水号
    return `MP-${year}${month}${day}-${serial}`;
  };

  const previewNumber = generatePackageNumber();

  const handleSubmit = () => {
    // 验证素材包名称
    if (!packageName.trim()) {
      toast.error('请输入素材包名称');
      return;
    }

    // 验证产品
    if (!product) {
      toast.error('请选择产品');
      return;
    }

    // 验证生产类型
    if (!productionType) {
      toast.error('请选择生产类型');
      return;
    }

    // 验证创意人
    if (!creativePerson) {
      toast.error('请选择创意人');
      return;
    }

    // 验证素材标签
    if (materialTags.length === 0) {
      toast.error('请选择素材包标签');
      return;
    }

    setIsSubmitting(true);
    // 模拟API调用
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success('素材包创建成功');
      // 生成一个新的素材包ID
      const newPackageId = `pkg-${Date.now()}`;
      onSuccess(newPackageId);
    }, 1000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* 返回按钮 */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 text-sm"
      >
        <ArrowLeft className="w-4 h-4" />
        返回素材包列表
      </button>

      {/* 创建表单 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
            <Package className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">创建素材包</h2>
            <p className="text-sm text-gray-500">创建一个新的素材包用于管理同一创意的不同版本素材</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* 素材包编号预览 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              素材包编号
            </label>
            <div className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-gray-900 font-mono">{previewNumber}</span>
                <span className="text-xs text-gray-500">系统自动生成</span>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              编号规则：MP-年月日-流水号
            </p>
          </div>

          {/* 素材包名称 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              素材包名称 <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={packageName}
              onChange={(e) => setPackageName(e.target.value)}
              placeholder="请输入素材包名称，如：Bingo Bonus 新年活动素材包"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              maxLength={100}
            />
            <div className="flex items-center justify-between mt-1">
              <p className="text-xs text-gray-500">
                为素材包起一个有意义的名称，方便后续查找和管理
              </p>
              <span className="text-xs text-gray-400">
                {packageName.length}/100
              </span>
            </div>
          </div>

          {/* 产品 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              产品 <span className="text-red-500">*</span>
            </label>
            <Select
              value={product}
              onValueChange={(value) => setProduct(value)}
            >
              <SelectTrigger className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <SelectValue placeholder="请选择产品" />
              </SelectTrigger>
              <SelectContent>
                {PRODUCTS.map((item) => (
                  <SelectItem key={item} value={item}>
                    {item}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 生产类型 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              生产类型 <span className="text-red-500">*</span>
            </label>
            <Select
              value={productionType}
              onValueChange={(value) => setProductionType(value as '0-1制作' | '1-N制作' | '')}
            >
              <SelectTrigger className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <SelectValue placeholder="请选择生产类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0-1制作">0-1制作</SelectItem>
                <SelectItem value="1-N制作">1-N制作</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 创意人 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              创意人 <span className="text-red-500">*</span>
            </label>
            <Select
              value={creativePerson}
              onValueChange={(value) => setCreativePerson(value)}
            >
              <SelectTrigger className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <SelectValue placeholder="请选择创意人" />
              </SelectTrigger>
              <SelectContent>
                {CREATIVE_STAFF.map((item) => (
                  <SelectItem key={item} value={item}>
                    {item}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 素材包标签 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              素材包标签 <span className="text-red-500">*</span>
            </label>
            <PackageTagSelector
              selectedTags={materialTags}
              onChange={setMaterialTags}
            />
            <p className="text-xs text-gray-500 mt-1">
              可以选择多个标签，素材包内的素材将继承这些标签
            </p>
          </div>

          {/* 说明信息 */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-sm font-medium text-blue-900 mb-2">素材包使用说明</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• 素材包用于管理同一创意的不同语言、不同尺寸版本的素材</li>
              <li>• 必须先创建素材包，才能上传素材</li>
              <li>• 素材包编号一旦生成不可修改</li>
              <li>• <strong>该素材包内的所有素材将统一使用所选的产品、生产类型、创意人和素材标签</strong></li>
              <li>• 素材包的数据取包内质量分最高的素材数据</li>
            </ul>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="flex items-center justify-end gap-3 mt-6 pt-6 border-t border-gray-200">
          <button
            onClick={onBack}
            disabled={isSubmitting}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50"
          >
            取消
          </button>
          <button
            onClick={handleSubmit}
            disabled={!packageName.trim() || isSubmitting}
            className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? '创建中...' : '创建素材包'}
          </button>
        </div>
      </div>
    </div>
  );
}