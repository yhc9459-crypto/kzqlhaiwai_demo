import { Material, MaterialType, PushProgress } from '../types/material';

// Material type mapping for XMP API
export const getMaterialTypeCode = (type: MaterialType): number => {
  switch (type) {
    case 'image':
      return 1;
    case 'video':
      return 2;
    case 'html5':
      return 10;
    default:
      return 1;
  }
};

// Get batch size limit based on material type
export const getBatchLimit = (type: MaterialType): number => {
  return type === 'video' ? 30 : 100;
};

// Get material type name in Chinese
export const getMaterialTypeName = (type: MaterialType): string => {
  switch (type) {
    case 'image':
      return '图片';
    case 'video':
      return '视频';
    case 'html5':
      return 'HTML5';
    default:
      return type;
  }
};

// Generate folder path for XMP platform
export const generateFolderPath = (
  productType: string,
  product: string,
  materialType: MaterialType,
  designer: string
): string => {
  const date = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
  const typeFolder = getMaterialTypeName(materialType);
  return `${productType}/${product}/${typeFolder}/${date}/${designer}`;
};

// Simulate XMP API authentication
const generateXMPAuth = (clientId: string, timestamp: number): string => {
  // In real implementation, this would generate a proper signature
  return `mock_signature_${clientId}_${timestamp}`;
};

// Simulate XMP folder check/creation
export const ensureXMPFolder = async (
  folderPath: string,
  apiUrl: string,
  clientId: string
): Promise<{ folderId: string; created: boolean }> => {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 300));

  // Mock folder ID generation
  const folderId = `folder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  console.log(`[XMP Folder] Checking folder: ${folderPath}`);
  console.log(`[XMP Folder] Folder created with ID: ${folderId}`);

  return {
    folderId,
    created: true,
  };
};

// Simulate XMP material upload
export const uploadMaterialToXMP = async (
  material: Material,
  folderId: string,
  apiUrl: string,
  clientId: string,
  designerMapping?: string,
  productMapping?: string,
  onProgress?: (progress: number) => void
): Promise<{ xmpMaterialId: string; xmpUserMaterialId: string }> => {
  const timestamp = Date.now();
  const sign = generateXMPAuth(clientId, timestamp);

  console.log(`[XMP Upload] Starting upload for material: ${material.name}`);
  console.log(`[XMP Upload] Material Type: ${material.type} (code: ${getMaterialTypeCode(material.type)})`);
  console.log(`[XMP Upload] File URL: ${material.fileUrl}`);
  console.log(`[XMP Upload] File MD5: ${material.fileMd5}`);
  console.log(`[XMP Upload] Folder ID: ${folderId}`);
  console.log(`[XMP Upload] Designer Mapping: ${designerMapping || 'Not configured'}`);
  console.log(`[XMP Upload] Product Mapping: ${productMapping || 'Not configured'}`);

  // Simulate upload progress
  for (let progress = 0; progress <= 100; progress += 20) {
    await new Promise((resolve) => setTimeout(resolve, 200));
    onProgress?.(progress);
  }

  // Simulate API response
  const xmpMaterialId = `xmp_mat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const xmpUserMaterialId = `xmp_user_mat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  console.log(`[XMP Upload] Upload successful`);
  console.log(`[XMP Upload] XMP Material ID: ${xmpMaterialId}`);
  console.log(`[XMP Upload] XMP User Material ID: ${xmpUserMaterialId}`);

  return {
    xmpMaterialId,
    xmpUserMaterialId,
  };
};

// Simulate batch upload with retry logic
export const batchUploadToXMP = async (
  materials: Material[],
  apiUrl: string,
  clientId: string,
  designerMappings: Map<string, string>,
  productMappings: Map<string, string>,
  onProgressUpdate: (materialId: string, progress: PushProgress) => void
): Promise<{ success: number; failed: number; errors: Array<{ materialId: string; error: string }> }> => {
  let success = 0;
  let failed = 0;
  const errors: Array<{ materialId: string; error: string }> = [];

  // Validate all materials are the same type
  const types = new Set(materials.map((m) => m.type));
  if (types.size > 1) {
    throw new Error('只能选择同一类型的素材进行推送');
  }

  const materialType = materials[0].type;
  const batchLimit = getBatchLimit(materialType);

  console.log(`[Batch Upload] Starting batch upload for ${materials.length} materials`);
  console.log(`[Batch Upload] Material type: ${materialType}, Batch limit: ${batchLimit}`);

  // Process in batches
  for (let i = 0; i < materials.length; i += batchLimit) {
    const batch = materials.slice(i, Math.min(i + batchLimit, materials.length));
    console.log(`[Batch Upload] Processing batch ${Math.floor(i / batchLimit) + 1}, materials: ${batch.length}`);

    // Create folder for the batch (assuming all materials go to the same folder structure)
    const firstMaterial = batch[0];
    const folderPath = generateFolderPath(
      firstMaterial.productType,
      firstMaterial.product,
      firstMaterial.type,
      firstMaterial.designer
    );

    let folderId: string;
    try {
      const folderResult = await ensureXMPFolder(folderPath, apiUrl, clientId);
      folderId = folderResult.folderId;
    } catch (error) {
      // If folder creation fails, mark all materials in batch as failed
      batch.forEach((material) => {
        onProgressUpdate(material.id, {
          materialId: material.id,
          status: 'failed',
          error: '文件夹创建失败',
          progress: 0,
        });
        failed++;
        errors.push({ materialId: material.id, error: '文件夹创建失败' });
      });
      continue;
    }

    // Upload each material in the batch
    for (const material of batch) {
      onProgressUpdate(material.id, {
        materialId: material.id,
        status: 'uploading',
        progress: 0,
      });

      try {
        // Simulate random failures for demo purposes
        const shouldFail = Math.random() < 0.1; // 10% chance of failure

        if (shouldFail) {
          throw new Error('网络连接超时');
        }

        const designerMapping = designerMappings.get(material.designerId);
        const productMapping = productMappings.get(material.product);

        const result = await uploadMaterialToXMP(
          material,
          folderId,
          apiUrl,
          clientId,
          designerMapping,
          productMapping,
          (progress) => {
            onProgressUpdate(material.id, {
              materialId: material.id,
              status: 'uploading',
              progress,
            });
          }
        );

        onProgressUpdate(material.id, {
          materialId: material.id,
          status: 'success',
          progress: 100,
        });

        success++;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : '未知错误';
        onProgressUpdate(material.id, {
          materialId: material.id,
          status: 'failed',
          error: errorMessage,
          progress: 0,
        });

        failed++;
        errors.push({ materialId: material.id, error: errorMessage });
      }

      // Add small delay between uploads to respect QPM limits
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  }

  console.log(`[Batch Upload] Complete. Success: ${success}, Failed: ${failed}`);

  return { success, failed, errors };
};
