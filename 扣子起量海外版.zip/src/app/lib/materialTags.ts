// 素材标签数据源
export type MaterialTagCategory = '前贴部分' | '主题' | '内容' | '节奏氛围' | '其他';

export interface MaterialTag {
  id: string;
  name: string;
  description: string;
  category: MaterialTagCategory;
  status: 'active' | 'inactive';
}

// 素材标签分类
export const materialTagCategories: MaterialTagCategory[] = ['前贴部分', '主题', '内容', '节奏氛围', '其他'];

// 素材标签数据（与MaterialTagManagementPage保持一致）
export const materialTags: MaterialTag[] = (() => {
  const tags: MaterialTag[] = [];
  let id = 1;
  
  // 前贴部分标签
  const qiantieBufen = [
    { name: '前贴-材质展示', desc: '展示材质效果的前贴' },
    { name: '前贴-特效展示', desc: '展示特效的前贴' },
    { name: '前贴-剧情提现', desc: '剧情提现类前贴' },
    { name: '前贴-剧情', desc: '剧情类前贴' },
    { name: '前贴-情绪展示', desc: '展示情绪的前贴' },
    { name: '前贴-核心文案', desc: '核心文案类前贴' },
    { name: '前贴-叙事文案', desc: '叙事文案类前贴' },
    { name: '前贴-食物对比', desc: '食物对比类前贴' },
    { name: '前贴-抽像元素', desc: '抽象元素类前贴' },
    { name: '前贴-AI小人', desc: 'AI小人类前贴' },
    { name: '前贴-运动', desc: '运动类前贴' },
    { name: '前贴-身材对比', desc: '身材对比类前贴' },
  ];
  
  // 主题标签
  const zhuti = [
    { name: '主题-绿色', desc: '绿色主题' },
    { name: '主题-红色', desc: '红色主题' },
    { name: '主题-冷色调', desc: '冷色调主题' },
    { name: '主题-暖色调', desc: '暖色调主题' },
    { name: '主题-植物', desc: '植物主题' },
    { name: '主题-季节', desc: '季节主题' },
    { name: '主题-机车', desc: '机车主题' },
    { name: '主题-多人', desc: '多人场景主题' },
    { name: '主题-字母', desc: '字母元素主题' },
    { name: '主题-建筑', desc: '建筑主题' },
    { name: '主题-高卡', desc: '高卡路里主题' },
    { name: '主题-粉色', desc: '粉色主题' },
    { name: '主题-紫色', desc: '紫色主题' },
    { name: '主题-黑色', desc: '黑色主题' },
    { name: '主题-金色', desc: '金色主题' },
    { name: '主题-科技', desc: '科技风格主题' },
    { name: '主题-动物', desc: '动物主题' },
    { name: '主题-室内', desc: '室内场景主题' },
    { name: '主题-室外', desc: '室外场景主题' },
    { name: '主题-单人', desc: '单人场景主题' },
    { name: '主题-美妆', desc: '美妆主题' },
    { name: '主题-低卡', desc: '低卡路里主题' },
    { name: '主题-动画', desc: '动画风格主题' },
  ];
  
  // 内容标签
  const neirong = [
    { name: '内容-点击', desc: '点击类玩法' },
    { name: '内容-推动', desc: '推动类玩法' },
    { name: '内容-拖动', desc: '拖动类玩法' },
    { name: '内容-连线', desc: '连线类玩法' },
    { name: '内容-长连线', desc: '长连线类玩法' },
    { name: '内容-三消', desc: '三消类玩法' },
    { name: '内容-扫雷', desc: '扫雷类玩法' },
    { name: '内容-障碍物', desc: '障碍物类玩法' },
    { name: '内容-迷宫', desc: '迷宫类玩法' },
    { name: '内容-点击屏幕', desc: '点击屏幕类玩法' },
    { name: '内容-翻页', desc: '翻页类玩法' },
    { name: '内容-翻牌', desc: '翻牌类玩法' },
    { name: '内容-扫描', desc: '扫描类玩法' },
  ];
  
  // 节奏氛围标签
  const jiezou = [
    { name: '埃及', desc: '埃及风格氛围' },
  ];
  
  // 其他标签
  const qita = [
    { name: '碎裂', desc: '碎裂效果' },
    { name: '拖尾', desc: '拖尾效果' },
    { name: '女性', desc: '女性角色' },
    { name: '男性', desc: '男性角色' },
    { name: '老人', desc: '老人角色' },
    { name: '中年', desc: '中年角色' },
    { name: '青年', desc: '青年角色' },
    { name: '小孩', desc: '小孩角色' },
    { name: '多层阵型', desc: '多层阵型展示' },
    { name: '国风', desc: '国风风格' },
  ];
  
  const addTags = (labels: Array<{name: string, desc: string}>, category: MaterialTagCategory) => {
    labels.forEach(label => {
      tags.push({
        id: `mat-tag-${id++}`,
        name: label.name,
        description: label.desc,
        category,
        status: 'active',
      });
    });
  };
  
  addTags(qiantieBufen, '前贴部分');
  addTags(zhuti, '主题');
  addTags(neirong, '内容');
  addTags(jiezou, '节奏氛围');
  addTags(qita, '其他');
  
  return tags;
})();

// 获取指定分类的标签
export function getTagsByCategory(category: MaterialTagCategory): MaterialTag[] {
  return materialTags.filter(tag => tag.category === category && tag.status === 'active');
}

// 获取所有启用的标签
export function getActiveTags(): MaterialTag[] {
  return materialTags.filter(tag => tag.status === 'active');
}
