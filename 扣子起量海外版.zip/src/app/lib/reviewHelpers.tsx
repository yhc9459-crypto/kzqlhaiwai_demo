import { Badge } from '../components/ui/badge';
import { CheckCircle, XCircle, Clock } from 'lucide-react';
import { ReviewStatus, UsageStatus } from '../types/material';

// 获取审核状态Badge
export function getReviewStatusBadge(status?: ReviewStatus) {
  if (!status) {
    return (
      <Badge variant="secondary" className="bg-blue-100 text-blue-700">
        <Clock className="mr-1 h-3 w-3" />
        待审核
      </Badge>
    );
  }
  
  switch (status) {
    case 'pending':
      return (
        <Badge variant="secondary" className="bg-blue-100 text-blue-700">
          <Clock className="mr-1 h-3 w-3" />
          待审核
        </Badge>
      );
    case 'approved':
      return (
        <Badge className="bg-green-600 text-white">
          <CheckCircle className="mr-1 h-3 w-3" />
          已通过
        </Badge>
      );
    case 'rejected':
      return (
        <Badge variant="destructive">
          <XCircle className="mr-1 h-3 w-3" />
          未通过
        </Badge>
      );
    default:
      return (
        <Badge variant="secondary" className="bg-blue-100 text-blue-700">
          <Clock className="mr-1 h-3 w-3" />
          待审核
        </Badge>
      );
  }
}

// 获取使用状态Badge
export function getUsageStatusBadge(status?: UsageStatus) {
  if (!status) {
    return <Badge variant="secondary">未使用</Badge>;
  }
  
  switch (status) {
    case 'unused':
      return <Badge variant="secondary">未使用</Badge>;
    case 'used':
      return <Badge className="bg-green-600 text-white">已使用</Badge>;
    default:
      return <Badge variant="secondary">未使用</Badge>;
  }
}