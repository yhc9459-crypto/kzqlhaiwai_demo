// 素材包标签数据源
export type PackageTagCategory = '前贴' | '主题' | '内容' | '节奏氛围' | '其他';

export interface PackageTag {
  id: string;
  name: string;
  description: string;
  category: PackageTagCategory;
  status: 'active' | 'inactive';
}

// 素材包标签分类
export const packageTagCategories: PackageTagCategory[] = ['前贴', '主题', '内容', '节奏氛围', '其他'];

// 素材包标签数据（与PackageTagManagementPage保持一致）
export const packageTags: PackageTag[] = (() => {
  const tags: PackageTag[] = [];
  let id = 1;
  
  // 前贴标签
  const qiantieLabels = [
    { name: '前贴-真人', desc: '使用真人出镜的前贴' },
    { name: '前贴-动画', desc: '使用动画形式的前贴' },
    { name: '前贴-大字报', desc: '使用大字报风格的前贴' },
    { name: '前贴-AI', desc: '使用AI生成的前贴' },
    { name: '前贴-风景', desc: '使用风景画面的前贴' },
    { name: '前贴-诱导', desc: '具有诱导性质的前贴' },
    { name: '前贴-展示', desc: '展示型前贴' },
    { name: '前贴-实拍', desc: '实拍素材的前贴' },
    { name: '前贴-ASMR', desc: 'ASMR风格的前贴' },
    { name: '前贴-猎奇', desc: '猎奇风格的前贴' },
    { name: '前贴-阵型展示', desc: '展示阵型的前贴' },
  ];
  
  // 主题标签
  const zhuti = [
    { name: '主题-纯色', desc: '纯色背景主题' },
    { name: '主题-设计包装', desc: '设计包装风格主题' },
    { name: '主题-材质纹理', desc: '材质纹理风格主题' },
    { name: '主题-风景', desc: '风景主题' },
    { name: '主题-AI', desc: 'AI生成风格主题' },
    { name: '主题-小清新', desc: '小清新风格主题' },
    { name: '主题-体育竞技', desc: '体育竞技主题' },
    { name: '主题-真人', desc: '真人出镜主题' },
    { name: '主题-霓虹', desc: '霓虹风格主题' },
    { name: '主题-复古', desc: '复古风格主题' },
    { name: '主题-木纹', desc: '木纹风格主题' },
    { name: '主题-手绘', desc: '手绘风格主题' },
    { name: '主题-车内', desc: '车内场景主题' },
    { name: '主题-食物', desc: '食物主题' },
    { name: '主题-曼陀罗', desc: '曼陀罗图案主题' },
    { name: '主题-博彩', desc: '博彩风格主题' },
  ];
  
  // 内容标签
  const neirong = [
    { name: '内容-核心玩法', desc: '展示产品核心玩法' },
    { name: '内容-竞品玩法', desc: '展示竞品玩法' },
    { name: '内容-跨品类', desc: '跨品类内容' },
    { name: '内容-展示', desc: '展示型内容' },
    { name: '内容-诱导', desc: '诱导型内容' },
    { name: '内容-情绪', desc: '情绪化内容' },
    { name: '内容-科普', desc: '科普型内容' },
    { name: '内容-收集', desc: '收集玩法内容' },
    { name: '内容-闯关', desc: '闯关玩法内容' },
    { name: '内容-多骰子', desc: '多骰子玩法内容' },
  ];
  
  // 节奏氛围标签
  const jiezou = [
    { name: '无BGM', desc: '无背景音乐' },
    { name: '纯音乐', desc: '纯音乐背景' },
    { name: '歌曲', desc: '使用歌曲作为背景音乐' },
    { name: '白噪音', desc: '白噪音背景' },
    { name: '慢节奏', desc: '慢节奏风格' },
    { name: '快节奏', desc: '快节奏风格' },
    { name: 'BGM卡点', desc: 'BGM卡点设计' },
    { name: '神秘', desc: '神秘氛围' },
  ];
  
  // 其他标签
  const qita = [
    { name: '3D', desc: '3D效果素材' },
    { name: '扁平极简', desc: '扁平极简风格' },
    { name: '文案口播', desc: '文案口播形式' },
    { name: '纯文案', desc: '纯文案展示' },
    { name: '文案真人口播', desc: '真人口播文案' },
    { name: '节日元素', desc: '包含节日元素' },
    { name: '卡通', desc: '卡通风格' },
    { name: '实拍', desc: '实拍素材' },
    { name: 'top集合', desc: '优质素材集合' },
    { name: '线稿', desc: '线稿风格' },
    { name: '成功', desc: '成功场景' },
    { name: '失败', desc: '失败场景' },
    { name: '条件限制', desc: '有条件限制的玩法' },
    { name: '对称阵型', desc: '对称阵型展示' },
    { name: '异形阵型', desc: '异形阵型展示' },
    { name: '满屏平铺', desc: '满屏平铺效果' },
  ];
  
  const addTags = (labels: Array<{name: string, desc: string}>, category: PackageTagCategory) => {
    labels.forEach(label => {
      tags.push({
        id: `pkg-tag-${id++}`,
        name: label.name,
        description: label.desc,
        category,
        status: 'active',
      });
    });
  };
  
  addTags(qiantieLabels, '前贴');
  addTags(zhuti, '主题');
  addTags(neirong, '内容');
  addTags(jiezou, '节奏氛围');
  addTags(qita, '其他');
  
  return tags;
})();

// 获取指定分类的标签
export function getTagsByCategory(category: PackageTagCategory): PackageTag[] {
  return packageTags.filter(tag => tag.category === category && tag.status === 'active');
}

// 获取所有启用的标签
export function getActiveTags(): PackageTag[] {
  return packageTags.filter(tag => tag.status === 'active');
}
