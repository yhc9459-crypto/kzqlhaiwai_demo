import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { MaterialLibraryPage } from './components/MaterialLibraryPage';
import { MyTasksPage } from './components/MyTasksPage';
import { AllTasksPage } from './components/AllTasksPage';
import { TaskDetailPage } from './components/TaskDetailPage';
import { CreateTaskPage } from './components/CreateTaskPage';
import { UploadMaterialPage } from './components/UploadMaterialPage';
import { MaterialDashboardPage } from './components/MaterialDashboardPage';
import { EfficiencyDashboardPage } from './components/EfficiencyDashboardPage';
import { MaterialPackagePage } from './components/MaterialPackagePage';
import { AllMaterialPackagePage } from './components/AllMaterialPackagePage';
import { MaterialPackageDetailPage } from './components/MaterialPackageDetailPage';
import { AllMaterialPackageDetailPage } from './components/AllMaterialPackageDetailPage';
import { CreateMaterialPackagePage } from './components/CreateMaterialPackagePage';
import { UploadMaterialInPackagePage } from './components/UploadMaterialInPackagePage';
import { MaterialDetailPage } from './components/MaterialDetailPage';
import { DesignerDashboardPage, DesignerDashboardFilters } from './components/DesignerDashboardPage';
import { DesignerPackageDetailPage } from './components/DesignerPackageDetailPage';
import { TagManagementPage } from './components/TagManagementPage';
import { PackageTagManagementPage } from './components/PackageTagManagementPage';
import { MaterialTagManagementPage } from './components/MaterialTagManagementPage';
import { Toaster } from './components/ui/sonner';
import { MaterialType } from './types/material';

type Page = 'video' | 'image' | 'html5' | 'my-tasks' | 'all-tasks' | 'create-task' | 'task-detail' | 'upload-video' | 'upload-image' | 'upload-html5' | 'material-dashboard' | 'designer-dashboard' | 'designer-package-detail' | 'efficiency-dashboard' | 'material-package' | 'all-material-package' | 'material-package-detail' | 'all-material-package-detail' | 'create-material-package' | 'upload-material-in-package' | 'material-detail' | 'tag-management' | 'package-tag-management' | 'material-tag-management';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('video');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [selectedPackageId, setSelectedPackageId] = useState<string | null>(null);
  const [selectedPackageName, setSelectedPackageName] = useState<string>('');
  const [selectedMaterialId, setSelectedMaterialId] = useState<string | null>(null);
  const [defaultMaterialType, setDefaultMaterialType] = useState<MaterialType | null>(null);
  const [designerDashboardFilters, setDesignerDashboardFilters] = useState<DesignerDashboardFilters | null>(null);

  const handleNavigateToTaskDetail = (taskId: string) => {
    setSelectedTaskId(taskId);
    setCurrentPage('task-detail');
  };

  const handleNavigateToCreateTask = (materialType?: MaterialType) => {
    setDefaultMaterialType(materialType || null);
    setSelectedPackageId(null);
    setCurrentPage('create-task');
  };

  const handleNavigateToCreateTaskFromPackage = (packageId: string) => {
    setSelectedPackageId(packageId);
    setDefaultMaterialType(null);
    setCurrentPage('create-task');
  };

  const handleNavigateToUpload = (materialType: MaterialType) => {
    if (materialType === 'video') {
      setCurrentPage('upload-video');
    } else if (materialType === 'image') {
      setCurrentPage('upload-image');
    } else if (materialType === 'html5') {
      setCurrentPage('upload-html5');
    }
  };

  const handleBackFromUpload = (materialType: MaterialType) => {
    if (materialType === 'video') {
      setCurrentPage('video');
    } else if (materialType === 'image') {
      setCurrentPage('image');
    } else if (materialType === 'html5') {
      setCurrentPage('html5');
    }
  };

  const getBreadcrumbs = () => {
    const materialBaseItems = [{ label: '素材', href: '#' }];
    const tagBaseItems = [{ label: '标签管理', href: '#' }];
    const dataBaseItems = [{ label: '数据', href: '#' }];
    
    switch (currentPage) {
      case 'video':
        return [...materialBaseItems, { label: '素材管理', href: '#' }, { label: '视频库', href: '#' }];
      case 'image':
        return [...materialBaseItems, { label: '素材管理', href: '#' }, { label: '图片库', href: '#' }];
      case 'html5':
        return [...materialBaseItems, { label: '素材管理', href: '#' }, { label: 'H5页面', href: '#' }];
      case 'upload-video':
        return [...materialBaseItems, { label: '素材管理', href: '#' }, { label: '视频库', href: '#' }, { label: '上传素材', href: '#' }];
      case 'upload-image':
        return [...materialBaseItems, { label: '素材管理', href: '#' }, { label: '图片库', href: '#' }, { label: '上传素材', href: '#' }];
      case 'upload-html5':
        return [...materialBaseItems, { label: '素材管理', href: '#' }, { label: 'H5页面', href: '#' }, { label: '上传素材', href: '#' }];
      case 'my-tasks':
        return [...materialBaseItems, { label: '推送任务', href: '#' }, { label: '本人任务', href: '#' }];
      case 'all-tasks':
        return [...materialBaseItems, { label: '推送任务', href: '#' }, { label: '全部任务', href: '#' }];
      case 'create-task':
        return [...materialBaseItems, { label: '推送任务', href: '#' }, { label: '创建任务', href: '#' }];
      case 'task-detail':
        return [...materialBaseItems, { label: '推送任务', href: '#' }, { label: '任务详情', href: '#' }];
      case 'material-dashboard':
        return [...dataBaseItems, { label: '素材看板', href: '#' }];
      case 'designer-dashboard':
        return [...dataBaseItems, { label: '设计师看板', href: '#' }];
      case 'designer-package-detail':
        return [...dataBaseItems, { label: '设计师看板', href: '#' }, { label: '素材包详情', href: '#' }];
      case 'efficiency-dashboard':
        return [...dataBaseItems, { label: '人效看板', href: '#' }];
      case 'material-package':
        return [...materialBaseItems, { label: '本人素材包', href: '#' }];
      case 'all-material-package':
        return [...materialBaseItems, { label: '全部素材包', href: '#' }];
      case 'material-package-detail':
        return [...materialBaseItems, { label: '本人素材包', href: '#' }, { label: '素材包详情', href: '#' }];
      case 'all-material-package-detail':
        return [...materialBaseItems, { label: '全部素材包', href: '#' }, { label: '素材包详情', href: '#' }];
      case 'create-material-package':
        return [...materialBaseItems, { label: '本人素材包', href: '#' }, { label: '创建素材包', href: '#' }];
      case 'upload-material-in-package':
        return [...materialBaseItems, { label: '本人素材包', href: '#' }, { label: '素材包详情', href: '#' }, { label: '上传素材', href: '#' }];
      case 'material-detail':
        return [...materialBaseItems, { label: '素材管理', href: '#' }, { label: '素材详情', href: '#' }];
      case 'tag-management':
        return [...materialBaseItems, { label: '标签管理', href: '#' }];
      case 'package-tag-management':
        return [...tagBaseItems, { label: '素材包标签管理', href: '#' }];
      case 'material-tag-management':
        return [...tagBaseItems, { label: '素材标签管理', href: '#' }];
      default:
        return materialBaseItems;
    }
  };

  const handleBackToTasks = () => {
    setCurrentPage('my-tasks');
  };

  const handleBackFromCreateTask = () => {
    if (selectedPackageId) {
      setCurrentPage('material-package-detail');
    } else {
      setCurrentPage('my-tasks');
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        <Header breadcrumbs={getBreadcrumbs()} />

        <main className="flex-1 overflow-y-auto p-6">
          {currentPage === 'video' && (
            <MaterialLibraryPage 
              materialType="video" 
              onNavigateToUpload={() => handleNavigateToUpload('video')}
              onNavigateToCreateTask={() => handleNavigateToCreateTask('video')}
            />
          )}
          {currentPage === 'image' && (
            <MaterialLibraryPage 
              materialType="image" 
              onNavigateToUpload={() => handleNavigateToUpload('image')}
              onNavigateToCreateTask={() => handleNavigateToCreateTask('image')}
            />
          )}
          {currentPage === 'html5' && (
            <MaterialLibraryPage 
              materialType="html5" 
              onNavigateToUpload={() => handleNavigateToUpload('html5')}
              onNavigateToCreateTask={() => handleNavigateToCreateTask('html5')}
            />
          )}
          {currentPage === 'upload-video' && (
            <UploadMaterialPage 
              materialType="video" 
              onBack={() => handleBackFromUpload('video')}
            />
          )}
          {currentPage === 'upload-image' && (
            <UploadMaterialPage 
              materialType="image" 
              onBack={() => handleBackFromUpload('image')}
            />
          )}
          {currentPage === 'upload-html5' && (
            <UploadMaterialPage 
              materialType="html5" 
              onBack={() => handleBackFromUpload('html5')}
            />
          )}
          {currentPage === 'my-tasks' && (
            <MyTasksPage 
              onNavigateToDetail={handleNavigateToTaskDetail} 
              onNavigateToCreate={handleNavigateToCreateTask} 
            />
          )}
          {currentPage === 'all-tasks' && (
            <AllTasksPage 
              onNavigateToDetail={handleNavigateToTaskDetail} 
              onNavigateToCreate={handleNavigateToCreateTask} 
            />
          )}
          {currentPage === 'create-task' && (
            <CreateTaskPage 
              onBack={handleBackFromCreateTask} 
              defaultMaterialType={defaultMaterialType} 
              packageId={selectedPackageId} 
            />
          )}
          {currentPage === 'task-detail' && selectedTaskId && (
            <TaskDetailPage taskId={selectedTaskId} onBack={handleBackToTasks} />
          )}
          {currentPage === 'material-dashboard' && <MaterialDashboardPage />}
          {currentPage === 'designer-dashboard' && (
            <DesignerDashboardPage 
              onNavigateToPackageDetail={(packageId, filters) => {
                setSelectedPackageId(packageId);
                setDesignerDashboardFilters(filters);
                setCurrentPage('designer-package-detail');
              }}
            />
          )}
          {currentPage === 'designer-package-detail' && selectedPackageId && designerDashboardFilters && (
            <DesignerPackageDetailPage 
              packageId={selectedPackageId}
              initialFilters={designerDashboardFilters}
              onBack={() => setCurrentPage('designer-dashboard')}
            />
          )}
          {currentPage === 'efficiency-dashboard' && <EfficiencyDashboardPage />}
          {currentPage === 'material-package' && (
            <MaterialPackagePage 
              onNavigateToDetail={(packageId) => {
                setSelectedPackageId(packageId);
                setCurrentPage('material-package-detail');
              }}
              onNavigateToCreate={() => setCurrentPage('create-material-package')}
              onNavigateToUpload={(packageId, packageName) => {
                setSelectedPackageId(packageId);
                setSelectedPackageName(packageName);
                setCurrentPage('upload-material-in-package');
              }}
              onNavigateToCreateTask={(packageId) => handleNavigateToCreateTaskFromPackage(packageId)}
            />
          )}
          {currentPage === 'all-material-package' && (
            <AllMaterialPackagePage 
              onNavigateToDetail={(packageId) => {
                setSelectedPackageId(packageId);
                setCurrentPage('all-material-package-detail');
              }}
              onNavigateToCreate={() => setCurrentPage('create-material-package')}
              onNavigateToUpload={(packageId, packageName) => {
                setSelectedPackageId(packageId);
                setSelectedPackageName(packageName);
                setCurrentPage('upload-material-in-package');
              }}
              onNavigateToCreateTask={(packageId) => handleNavigateToCreateTaskFromPackage(packageId)}
            />
          )}
          {currentPage === 'material-package-detail' && selectedPackageId && (
            <MaterialPackageDetailPage 
              packageId={selectedPackageId}
              onBack={() => setCurrentPage('material-package')}
              onNavigateToUpload={(packageName) => {
                setSelectedPackageName(packageName);
                setCurrentPage('upload-material-in-package');
              }}
              onNavigateToCreateTask={() => handleNavigateToCreateTaskFromPackage(selectedPackageId)}
            />
          )}
          {currentPage === 'all-material-package-detail' && selectedPackageId && (
            <AllMaterialPackageDetailPage 
              packageId={selectedPackageId}
              onBack={() => setCurrentPage('all-material-package')}
              onNavigateToUpload={(packageName) => {
                setSelectedPackageName(packageName);
                setCurrentPage('upload-material-in-package');
              }}
              onNavigateToCreateTask={() => handleNavigateToCreateTaskFromPackage(selectedPackageId)}
            />
          )}
          {currentPage === 'create-material-package' && (
            <CreateMaterialPackagePage 
              onBack={() => setCurrentPage('material-package')}
              onSuccess={(packageId) => {
                setSelectedPackageId(packageId);
                setCurrentPage('material-package-detail');
              }}
            />
          )}
          {currentPage === 'upload-material-in-package' && selectedPackageId && (
            <UploadMaterialInPackagePage 
              packageId={selectedPackageId}
              packageName={selectedPackageName}
              onBack={() => setCurrentPage('material-package-detail')}
              onSuccess={() => setCurrentPage('material-package-detail')}
            />
          )}
          {currentPage === 'material-detail' && selectedMaterialId && (
            <MaterialDetailPage 
              materialId={selectedMaterialId}
              onBack={() => setCurrentPage('video')}
            />
          )}
          {currentPage === 'tag-management' && <TagManagementPage />}
          {currentPage === 'package-tag-management' && <PackageTagManagementPage />}
          {currentPage === 'material-tag-management' && <MaterialTagManagementPage />}
        </main>
      </div>

      <Toaster />
    </div>
  );
}