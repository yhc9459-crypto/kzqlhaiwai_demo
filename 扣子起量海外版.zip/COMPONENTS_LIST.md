# 📦 组件清单 - V115

## 页面组件 (Page Components)

### 素材管理

| 组件名 | 文件路径 | 功能说明 | 依赖组件 |
|--------|----------|----------|----------|
| MaterialLibraryPage | `/src/app/components/MaterialLibraryPage.tsx` | 素材库主页（视频/图片/H5），双标签页 | Table, Select, Input, Calendar, Badge |
| MaterialDetailPage | `/src/app/components/MaterialDetailPage.tsx` | 素材详情页 | Badge, Button |
| UploadMaterialPage | `/src/app/components/UploadMaterialPage.tsx` | 上传素材页 | Button, Input |

### 素材包管理

| 组件名 | 文件路径 | 功能说明 | 依赖组件 |
|--------|----------|----------|----------|
| **MaterialPackagePage** | `/src/app/components/MaterialPackagePage.tsx` | **素材包列表（当前页面）** | Table, Select, Input, Calendar, Popover |
| MaterialPackageDetailPage | `/src/app/components/MaterialPackageDetailPage.tsx` | 素材包详情页 | Button, Badge, Table |
| CreateMaterialPackagePage | `/src/app/components/CreateMaterialPackagePage.tsx` | 创建素材包页 | Input, Select, Button |
| UploadMaterialInPackagePage | `/src/app/components/UploadMaterialInPackagePage.tsx` | 在素材包中上传素材 | Button, Input |

### 推送任务

| 组件名 | 文件路径 | 功能说明 | 依赖组件 |
|--------|----------|----------|----------|
| MyTasksPage | `/src/app/components/MyTasksPage.tsx` | 本人任务列表 | Table, Badge, Button |
| AllTasksPage | `/src/app/components/AllTasksPage.tsx` | 全部任务列表 | Table, Badge, Button, Select, Calendar |
| PushTaskListPage | `/src/app/components/PushTaskListPage.tsx` | 推送任务列表（通用） | Table, Badge |
| TaskDetailPage | `/src/app/components/TaskDetailPage.tsx` | 任务详情页 | Badge, Button, Progress |
| CreateTaskPage | `/src/app/components/CreateTaskPage.tsx` | 创建推送任务 | Input, Select, Button, Checkbox |

### 数据看板

| 组件名 | 文件路径 | 功能说明 | 依赖组件 |
|--------|----------|----------|----------|
| MaterialDashboardPage | `/src/app/components/MaterialDashboardPage.tsx` | 素材看板（占位） | - |
| EfficiencyDashboardPage | `/src/app/components/EfficiencyDashboardPage.tsx` | 人效看板（占位） | - |

### 布局组件

| 组件名 | 文件路径 | 功能说明 | 依赖组件 |
|--------|----------|----------|----------|
| **Header** | `/src/app/components/Header.tsx` | 顶部导航栏 | Breadcrumb, Button |
| **Sidebar** | `/src/app/components/Sidebar.tsx` | 左侧菜单栏 | Button, Collapsible |

## UI基础组件 (UI Components)

### 表单组件

| 组件名 | 文件路径 | 用途 |
|--------|----------|------|
| Button | `/src/app/components/ui/button.tsx` | 按钮 |
| Input | `/src/app/components/ui/input.tsx` | 输入框 |
| Select | `/src/app/components/ui/select.tsx` | 下拉选择 |
| Checkbox | `/src/app/components/ui/checkbox.tsx` | 复选框 |
| Radio | `/src/app/components/ui/radio-group.tsx` | 单选框 |
| Switch | `/src/app/components/ui/switch.tsx` | 开关 |
| Textarea | `/src/app/components/ui/textarea.tsx` | 多行文本 |
| Calendar | `/src/app/components/ui/calendar.tsx` | 日历选择器 |

### 数据展示

| 组件名 | 文件路径 | 用途 |
|--------|----------|------|
| **Table** | `/src/app/components/ui/table.tsx` | **表格** |
| Badge | `/src/app/components/ui/badge.tsx` | 徽章 |
| Card | `/src/app/components/ui/card.tsx` | 卡片 |
| Avatar | `/src/app/components/ui/avatar.tsx` | 头像 |
| Progress | `/src/app/components/ui/progress.tsx` | 进度条 |

### 反馈组件

| 组件名 | 文件路径 | 用途 |
|--------|----------|------|
| Dialog | `/src/app/components/ui/dialog.tsx` | 对话框 |
| Alert | `/src/app/components/ui/alert.tsx` | 警告提示 |
| AlertDialog | `/src/app/components/ui/alert-dialog.tsx` | 确认对话框 |
| Sonner | `/src/app/components/ui/sonner.tsx` | Toast通知 |
| Tooltip | `/src/app/components/ui/tooltip.tsx` | 工具提示 |

### 导航组件

| 组件名 | 文件路径 | 用途 |
|--------|----------|------|
| Tabs | `/src/app/components/ui/tabs.tsx` | 标签页 |
| Breadcrumb | `/src/app/components/ui/breadcrumb.tsx` | 面包屑 |
| Pagination | `/src/app/components/ui/pagination.tsx` | 分页 |

### 弹出组件

| 组件名 | 文件路径 | 用途 |
|--------|----------|------|
| Popover | `/src/app/components/ui/popover.tsx` | 气泡弹出 |
| DropdownMenu | `/src/app/components/ui/dropdown-menu.tsx` | 下拉菜单 |
| HoverCard | `/src/app/components/ui/hover-card.tsx` | 悬停卡片 |
| ContextMenu | `/src/app/components/ui/context-menu.tsx` | 右键菜单 |

### 其他组件

| 组件名 | 文件路径 | 用途 |
|--------|----------|------|
| Separator | `/src/app/components/ui/separator.tsx` | 分隔线 |
| ScrollArea | `/src/app/components/ui/scroll-area.tsx` | 滚动区域 |
| Collapsible | `/src/app/components/ui/collapsible.tsx` | 折叠面板 |
| Accordion | `/src/app/components/ui/accordion.tsx` | 手风琴 |

## 工具模块 (Utils)

| 文件 | 路径 | 功能 |
|------|------|------|
| mockData.ts | `/src/app/lib/mockData.ts` | Mock数据（素材、素材包、任务等） |
| xmpService.ts | `/src/app/lib/xmpService.ts` | XMP平台服务接口 |
| material.ts | `/src/app/types/material.ts` | TypeScript类型定义 |
| utils.ts | `/src/app/components/ui/utils.ts` | 工具函数（cn等） |

## 核心功能组件详解

### 1. MaterialPackagePage（当前页面）

**核心功能：**
```typescript
✅ 8个筛选维度
✅ 4列可排序（创建时间、花费、CTR、ROI）
✅ 缩略图预览（点击放大）
✅ 素材数量统计（视频/图片/H5图标）
✅ 分页（每页10条）
✅ 点击行跳转详情
```

**主要State：**
```typescript
// 筛选条件
packageNameQuery, packageNumberQuery, productFilter, 
productionTypeFilter, creatorFilter, creativePersonFilter,
dateFrom, dateTo

// 排序状态
createdAtSort, costSort, ctrSort, roiSort

// 分页
currentPage, itemsPerPage

// 预览
isPreviewOpen, previewMaterial
```

**使用示例：**
```tsx
<MaterialPackagePage 
  onNavigateToDetail={(packageId) => {
    // 跳转到详情页
  }}
  onNavigateToCreate={() => {
    // 跳转到创建页
  }}
/>
```

### 2. MaterialLibraryPage

**核心功能：**
```typescript
✅ 双标签页（本人素材/全部素材）
✅ 多维度筛选（素材名称、所属素材包、产品等）
✅ 质量分、花费、CTR、ROI展示
✅ 批量选择和操作
✅ 上传素材
✅ 创建推送任务
```

**Props：**
```typescript
interface Props {
  materialType: 'video' | 'image' | 'html5';
  onNavigateToUpload: () => void;
  onNavigateToCreateTask: () => void;
}
```

### 3. MyTasksPage / AllTasksPage

**核心功能：**
```typescript
✅ 任务列表展示
✅ 状态徽章（已完成、处理中、待处理、失败）
✅ 成功/失败/待处理数统计
✅ 点击查看详情
✅ 创建新任务
```

**数据格式：**
```typescript
interface PushTask {
  id: string;
  product: string;
  materialType: 'video' | 'image' | 'html5';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  totalCount: number;
  successCount: number;
  failedCount: number;
  pendingCount: number;
  createdBy: string;
  createdAt: string;
  completedAt?: string;
}
```

## 组件依赖关系图

```
App.tsx
├── Sidebar
│   └── Button, Collapsible
├── Header
│   └── Breadcrumb
└── Pages
    ├── MaterialPackagePage ⭐
    │   ├── Table
    │   ├── Select
    │   ├── Input
    │   ├── Calendar
    │   ├── Popover
    │   ├── Button
    │   └── Dialog (预览)
    ├── MaterialLibraryPage
    │   ├── Tabs
    │   ├── Table
    │   ├── Select
    │   ├── Input
    │   ├── Calendar
    │   └── Badge
    └── TaskPages
        ├── Table
        ├── Badge
        └── Button
```

## 样式系统

### Theme Colors (theme.css)
```css
@theme {
  --color-primary: #2563eb;
  --color-success: #10b981;
  --color-warning: #f59e0b;
  --color-error: #ef4444;
}
```

### Tailwind Classes
```
布局: flex, grid, space-y-*, gap-*
间距: p-*, m-*, px-*, py-*
颜色: text-*, bg-*, border-*
尺寸: w-*, h-*, max-w-*
圆角: rounded-*, rounded-lg
阴影: shadow-*, shadow-lg
```

## 图标库 (Lucide React)

常用图标：
```typescript
import { 
  Package,        // 素材包
  FileVideo,      // 视频
  FileImage,      // 图片
  FileCode,       // H5
  Upload,         // 上传
  RotateCcw,      // 重置
  CalendarIcon,   // 日历
  ArrowUpDown,    // 排序
  ArrowUp,        // 升序
  ArrowDown,      // 降序
  Video,          // 视频播放
  Image,          // 图片预览
  X,              // 关闭
} from 'lucide-react';
```

## 数据流

```
Mock Data (mockData.ts)
    ↓
State Management (useState)
    ↓
Filter & Sort Logic
    ↓
Pagination
    ↓
Table Rendering
    ↓
User Interaction
```

## 关键Hooks

| Hook | 用途 | 文件 |
|------|------|------|
| useState | 状态管理 | 所有组件 |
| useEffect | 副作用处理 | 部分组件 |
| useMemo | 性能优化（未使用） | - |
| useCallback | 性能优化（未使用） | - |

## 已安装的关键包

```json
{
  "date-fns": "3.6.0",           // 日期处理
  "lucide-react": "0.487.0",     // 图标
  "sonner": "2.0.3",             // Toast
  "react-hook-form": "7.55.0",   // 表单
  "recharts": "2.15.2"           // 图表
}
```

## 待开发功能

- [ ] 真实API接口集成
- [ ] 素材看板图表
- [ ] 人效看板统计
- [ ] 文件上传功能
- [ ] 权限系统集成
- [ ] 国际化支持

## 版本信息

- **模板版本**: V115
- **组件数量**: 60+
- **页面组件**: 15个
- **UI组件**: 45+个
- **最后更新**: 2026-01-29

---

**当前页面**: MaterialPackagePage（素材包管理）  
**状态**: ✅ 功能完整
